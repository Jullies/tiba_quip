<?php
require_once __DIR__ . '/overall/bootstrap.php';
$bodyClass = '';
$pageScripts = [];
require __DIR__ . '/overall/head.php';
require __DIR__ . '/overall/header.php';
?>
<main class="main">

        <!-- breadcrumb -->
        <div class="site-breadcrumb">
            <div class="site-breadcrumb-bg" style="background: url(assets/img/breadcrumb/01.jpg)"></div>
            <div class="container">
                <div class="site-breadcrumb-wrap">
                    <h4 class="breadcrumb-title">Support Tickets</h4>
                    <ul class="breadcrumb-menu">
                        <li><a href="index.php"><i class="far fa-home"></i> Home</a></li>
                        <li class="active">Support Tickets</li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- breadcrumb end -->


        <!-- user dashboard -->
        <div class="user-area bg pt-100 pb-80">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3">
                        <?php require __DIR__ . '/overall/sidenav.php'; ?>
                    </div>
                    <div class="col-lg-9">
                        <div class="user-wrapper">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="user-card">
                                        <div class="user-card-header">
                                            <h4 class="user-card-title">Support Tickets</h4>
                                            <div class="user-card-header-right">
                                                <div class="user-card-filter">
                                                    <select class="select">
                                                        <option value="">Default</option>
                                                        <option value="1">Open</option>
                                                        <option value="2">Urgent</option>
                                                        <option value="3">Normal</option>
                                                        <option value="4">Closed</option>
                                                    </select>
                                                </div>
                                                <div class="user-card-search">
                                                    <div class="form-group">
                                                        <input type="text" class="form-control" placeholder="Search...">
                                                        <i class="far fa-search"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="table-responsive">
                                            <table class="table table-borderless text-nowrap">
                                                <thead>
                                                    <tr>
                                                        <th>#Ticket</th>
                                                        <th>Date</th>
                                                        <th>Subject</th>
                                                        <th>Status</th>
                                                        <th>Priority</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td><span class="table-list-code">#28VR5K59</span></td>
                                                        <td>August 20, 2024</td>
                                                        <td><p>There is a problem with the product.</p></td>
                                                        <td><span class="badge badge-success">Open</span></td>
                                                        <td><span class="badge badge-info">Urgent</span></td>
                                                        <td>
                                                            <a href="ticket-detail.php" class="btn btn-outline-secondary btn-sm rounded-2" data-tooltip="tooltip" title="Details"><i class="far fa-eye"></i></a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><span class="table-list-code">#28VR5K59</span></td>
                                                        <td>August 20, 2024</td>
                                                        <td><p>There is a problem with the product.</p></td>
                                                        <td><span class="badge badge-success">Open</span></td>
                                                        <td><span class="badge badge-info">Urgent</span></td>
                                                        <td>
                                                            <a href="ticket-detail.php" class="btn btn-outline-secondary btn-sm rounded-2" data-tooltip="tooltip" title="Details"><i class="far fa-eye"></i></a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><span class="table-list-code">#28VR5K59</span></td>
                                                        <td>August 20, 2024</td>
                                                        <td><p>There is a problem with the product.</p></td>
                                                        <td><span class="badge badge-danger">Closed</span></td>
                                                        <td><span class="badge badge-primary">Normal</span></td>
                                                        <td>
                                                            <a href="ticket-detail.php" class="btn btn-outline-secondary btn-sm rounded-2" data-tooltip="tooltip" title="Details"><i class="far fa-eye"></i></a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><span class="table-list-code">#28VR5K59</span></td>
                                                        <td>August 20, 2024</td>
                                                        <td><p>There is a problem with the product.</p></td>
                                                        <td><span class="badge badge-success">Open</span></td>
                                                        <td><span class="badge badge-info">Urgent</span></td>
                                                        <td>
                                                            <a href="ticket-detail.php" class="btn btn-outline-secondary btn-sm rounded-2" data-tooltip="tooltip" title="Details"><i class="far fa-eye"></i></a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><span class="table-list-code">#28VR5K59</span></td>
                                                        <td>August 20, 2024</td>
                                                        <td><p>There is a problem with the product.</p></td>
                                                        <td><span class="badge badge-danger">Closed</span></td>
                                                        <td><span class="badge badge-primary">Normal</span></td>
                                                        <td>
                                                            <a href="ticket-detail.php" class="btn btn-outline-secondary btn-sm rounded-2" data-tooltip="tooltip" title="Details"><i class="far fa-eye"></i></a>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <!-- pagination -->
                                        <div class="pagination-area mt-4 mb-3">
                                            <div aria-label="Page navigation example">
                                                <ul class="pagination">
                                                    <li class="page-item">
                                                        <a class="page-link" href="#" aria-label="Previous">
                                                            <span aria-hidden="true"><i class="far fa-angle-double-left"></i></span>
                                                        </a>
                                                    </li>
                                                    <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                                                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                                                    <li class="page-item">
                                                        <a class="page-link" href="#" aria-label="Next">
                                                            <span aria-hidden="true"><i class="far fa-angle-double-right"></i></span>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <!-- pagination end -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- user dashboard end -->

    </main>


    <?php require __DIR__ . '/overall/footer.php'; ?>
<?php require __DIR__ . '/overall/scripts.php'; ?>
