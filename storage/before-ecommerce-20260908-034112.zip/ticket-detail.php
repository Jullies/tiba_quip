<?php
require_once __DIR__ . '/overall/bootstrap.php';
$bodyClass = '';
$pageScripts = [];
require __DIR__ . '/overall/head.php';
require __DIR__ . '/overall/header.php';
?>
<main class="main">

        <!-- breadcrumb -->
        <div class="site-breadcrumb">
            <div class="site-breadcrumb-bg" style="background: url(assets/img/breadcrumb/01.jpg)"></div>
            <div class="container">
                <div class="site-breadcrumb-wrap">
                    <h4 class="breadcrumb-title">Ticket Details</h4>
                    <ul class="breadcrumb-menu">
                        <li><a href="index.php"><i class="far fa-home"></i> Home</a></li>
                        <li class="active">Ticket Details</li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- breadcrumb end -->


        <!-- user dashboard -->
        <div class="user-area bg pt-100 pb-80">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3">
                        <?php require __DIR__ . '/overall/sidenav.php'; ?>
                    </div>
                    <div class="col-lg-9">
                        <div class="user-wrapper">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="user-card user-ticket-detail">
                                        <div class="user-card-header">
                                            <h4 class="user-card-title">Ticket Details (#28VR5K59)</h4>
                                            <div class="user-card-header-right">
                                                <a href="support-ticket.php" class="theme-btn"><span class="fas fa-arrow-left"></span>Support Ticket</a>
                                            </div>
                                        </div>
                                        <div class="ticket-detail-content">
                                            <div class="ticket-chat-item">
                                                <div class="ticket-img">
                                                    <img src="assets/img/account/01.jpg" alt="">
                                                </div>
                                                <div class="ticket-info">
                                                    <h5>Antoni Jonson</h5>
                                                    <span>10:20 PM | August 12, 2024</span>
                                                    <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.</p>
                                                </div>
                                            </div>
                                            <div class="ticket-chat-item ms-lg-5">
                                                <div class="ticket-img">
                                                    <img src="assets/img/account/02.jpg" alt="">
                                                </div>
                                                <div class="ticket-info">
                                                    <h5>Nikol Habitex</h5>
                                                    <span>10:20 PM | August 12, 2024</span>
                                                    <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.</p>
                                                </div>
                                            </div>
                                            <div class="ticket-chat-item">
                                                <div class="ticket-img">
                                                    <img src="assets/img/account/01.jpg" alt="">
                                                </div>
                                                <div class="ticket-info">
                                                    <h5>Antoni Jonson</h5>
                                                    <span>10:20 PM | August 12, 2024</span>
                                                    <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="ticket-chat-box">
                                            <div class="ticket-chat-form user-form">
                                               <form action="#">
                                                    <div class="form-group">
                                                        <textarea class="form-control" cols="30" rows="6" placeholder="Type Your Message"></textarea>
                                                    </div>
                                                    <button type="submit" class="theme-btn"><span class="far fa-paper-plane"></span> Send Message</button>
                                               </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- user dashboard end -->

    </main>


    <?php require __DIR__ . '/overall/footer.php'; ?>
<?php require __DIR__ . '/overall/scripts.php'; ?>
