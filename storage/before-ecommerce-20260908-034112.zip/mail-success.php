<?php
require_once __DIR__ . '/overall/bootstrap.php';
$bodyClass = '';
$pageScripts = [];
require __DIR__ . '/overall/head.php';
require __DIR__ . '/overall/header.php';
?>
<main class="main">

        <!-- breadcrumb -->
        <div class="site-breadcrumb">
            <div class="site-breadcrumb-bg" style="background: url(assets/img/breadcrumb/01.jpg)"></div>
            <div class="container">
                <div class="site-breadcrumb-wrap">
                    <h4 class="breadcrumb-title">Mail Success</h4>
                    <ul class="breadcrumb-menu">
                        <li><a href="index.php"><i class="far fa-home"></i> Home</a></li>
                        <li class="active">Mail Success</li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- breadcrumb end -->


        <!-- mail success -->
        <div class="mail-success py-100">
            <div class="container">
                <div class="row">
                    <div class="col-md-7 mx-auto">
                        <div class="mail-success-content">
                            <div class="mail-success-icon"><i class="fal fa-envelope-circle-check"></i></div>
                            <h3>Your Mail Sent Successfully!.</h3>
                            <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.</p>
                            <a href="#" class="theme-btn">Go Back Home<i class="far fa-home"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- mail success end -->

    </main>


    <?php require __DIR__ . '/overall/footer.php'; ?>
<?php require __DIR__ . '/overall/scripts.php'; ?>
