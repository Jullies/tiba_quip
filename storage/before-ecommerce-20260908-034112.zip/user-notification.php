<?php
require_once __DIR__ . '/overall/bootstrap.php';
$bodyClass = '';
$pageScripts = [];
require __DIR__ . '/overall/head.php';
require __DIR__ . '/overall/header.php';
?>
<main class="main">

        <!-- breadcrumb -->
        <div class="site-breadcrumb">
            <div class="site-breadcrumb-bg" style="background: url(assets/img/breadcrumb/01.jpg)"></div>
            <div class="container">
                <div class="site-breadcrumb-wrap">
                    <h4 class="breadcrumb-title">Notification</h4>
                    <ul class="breadcrumb-menu">
                        <li><a href="index.php"><i class="far fa-home"></i> Home</a></li>
                        <li class="active">Notification</li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- breadcrumb end -->


        <!-- user dashboard -->
        <div class="user-area bg pt-100 pb-80">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3">
                        <?php require __DIR__ . '/overall/sidenav.php'; ?>
                    </div>
                    <div class="col-lg-9">
                        <div class="user-wrapper">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="user-card">
                                        <h4 class="user-card-title">Notification</h4>
                                        <div class="table-responsive">
                                            <table class="table table-borderless text-nowrap">
                                                <thead>
                                                    <tr>
                                                        <th>No</th>
                                                        <th>Notification</th>
                                                        <th>Date</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td><span class="table-list-code">01.</span></td>
                                                        <td><p>There are many variations of passages available</p></td>
                                                        <td>Aug 12, 2024</td>
                                                        <td><span class="badge badge-info">Unread</span></td>
                                                        <td>
                                                            <a href="#" class="btn btn-outline-secondary btn-sm rounded-2"><i class="far fa-eye me-1"></i> Mark As Read</a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><span class="table-list-code">02.</span></td>
                                                        <td><p>There are many variations of passages available</p></td>
                                                        <td>Aug 12, 2024</td>
                                                        <td><span class="badge badge-info">Unread</span></td>
                                                        <td>
                                                            <a href="#" class="btn btn-outline-secondary btn-sm rounded-2"><i class="far fa-eye me-1"></i> Mark As Read</a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><span class="table-list-code">03.</span></td>
                                                        <td><p>There are many variations of passages available</p></td>
                                                        <td>Aug 12, 2024</td>
                                                        <td><span class="badge badge-success">Read</span></td>
                                                        <td>
                                                            <a href="#" class="btn btn-outline-secondary btn-sm rounded-2"><i class="far fa-eye-slash me-1"></i> Mark As Unread</a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><span class="table-list-code">04.</span></td>
                                                        <td><p>There are many variations of passages available</p></td>
                                                        <td>Aug 12, 2024</td>
                                                        <td><span class="badge badge-info">Unread</span></td>
                                                        <td>
                                                            <a href="#" class="btn btn-outline-secondary btn-sm rounded-2"><i class="far fa-eye me-1"></i> Mark As Read</a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><span class="table-list-code">05.</span></td>
                                                        <td><p>There are many variations of passages available</p></td>
                                                        <td>Aug 12, 2024</td>
                                                        <td><span class="badge badge-success">Read</span></td>
                                                        <td>
                                                            <a href="#" class="btn btn-outline-secondary btn-sm rounded-2"><i class="far fa-eye-slash me-1"></i> Mark As Unread</a>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                            <!-- pagination -->
                                            <div class="pagination-area mt-4 mb-3">
                                                <div aria-label="Page navigation example">
                                                    <ul class="pagination">
                                                        <li class="page-item">
                                                            <a class="page-link" href="#" aria-label="Previous">
                                                                <span aria-hidden="true"><i class="far fa-angle-double-left"></i></span>
                                                            </a>
                                                        </li>
                                                        <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                                                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                                                        <li class="page-item">
                                                            <a class="page-link" href="#" aria-label="Next">
                                                                <span aria-hidden="true"><i class="far fa-angle-double-right"></i></span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- pagination end -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- user dashboard end -->

    </main>


    <?php require __DIR__ . '/overall/footer.php'; ?>
<?php require __DIR__ . '/overall/scripts.php'; ?>
