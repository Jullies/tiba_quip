<?php
require_once __DIR__ . '/overall/bootstrap.php';
$bodyClass = '';
$pageScripts = [];
require __DIR__ . '/overall/head.php';
require __DIR__ . '/overall/header.php';
?>
<!-- invoice area -->
    <div class="invoice-area bg pt-40 pb-90">
        <div class="invoice-container not-print">
            <div class="row">
                <div class="col-lg-12">
                    <div class="invoice-print">
                        <a href="#" class="invoice-print-btn theme-btn">Print Invoice</a>
                    </div>
                    <div class="invoice-wrapper">
                        <div class="invoice-header">
                            <div class="invoice-logo">
                                <img src="assets/img/logo/logo.png" alt="">
                            </div>
                            <div class="invoice-number invoice-width">
                                <h3>Invoice</h3>
                                <p>#1234567</p>
                            </div>
                        </div>
                        <div class="invoice-date-box">
                            <div class="invoice-date">
                                <h6>Invoice Date</h6>
                                <p>09/13/2024</p>
                            </div>
                            <div class="invoice-date invoice-width">
                                <h6>Due Date</h6>
                                <p>09/13/2024</p>
                            </div>
                        </div>
                        <div class="invoice-address-box">
                            <div class="invoice-address">
                                <h5>Supplier</h5>
                                <ul>
                                    <li>Electo</li>
                                    <li>(+02) 123456789</li>
                                    <li>711 W Kearney St, Springfield, USA</li>
                                </ul>
                            </div>
                            <div class="invoice-address invoice-width">
                                <h5>Customer</h5>
                                <ul>
                                    <li>Jeremy Connelly</li>
                                    <li>(+02) 123456789</li>
                                    <li>711 W Kearney St, Springfield, USA</li>
                                </ul>
                            </div>
                        </div>
                        <div class="invoice-table">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th>Qty</th>
                                        <th>Price</th>
                                        <th>Discount(5%)</th>
                                        <th>Tax(10%)</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Product One</td>
                                        <td>01</td>
                                        <td>$150</td>
                                        <td>$20</td>
                                        <td>$30</td>
                                        <td>$130</td>
                                    </tr>
                                    <tr>
                                        <td>Product Two</td>
                                        <td>01</td>
                                        <td>$150</td>
                                        <td>$20</td>
                                        <td>$30</td>
                                        <td>$130</td>
                                    </tr>
                                    <tr>
                                        <td>Product Three</td>
                                        <td>01</td>
                                        <td>$150</td>
                                        <td>$20</td>
                                        <td>$30</td>
                                        <td>$130</td>
                                    </tr>
                                    <tr>
                                        <th colspan="5">Total</th>
                                        <th>$390</th>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="invoice-bottom">
                            <a href="#">www.example.com</a>
                            <a href="#">invoice@example.com</a>
                            <a href="#">(+02) 0123 456 745</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- invoice area end -->


    


    
<?php require __DIR__ . '/overall/footer.php'; ?>
<?php require __DIR__ . '/overall/scripts.php'; ?>
