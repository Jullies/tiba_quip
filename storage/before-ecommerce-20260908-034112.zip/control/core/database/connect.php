<?php
    session_start();

    $servername = "localhost" ;
    $user = "root";
    $passcode = "toor" ;
    $dbname = "tiba_new";

    $connect_error = 'Sorry, we\'re experiencing connecection issues at the moment';
    error_reporting(0);

    $conn= mysqli_connect($servername,$user,$passcode,$dbname) or die ($connect_error);
?>