<?php
require_once __DIR__ . '/overall/bootstrap.php';
$bodyClass = '';
$pageScripts = [];
require __DIR__ . '/overall/head.php';
require __DIR__ . '/overall/header.php';
?>
<main class="main">

        <!-- breadcrumb -->
        <div class="site-breadcrumb">
            <div class="site-breadcrumb-bg" style="background: url(assets/img/breadcrumb/01.jpg)"></div>
            <div class="container">
                <div class="site-breadcrumb-wrap">
                    <h4 class="breadcrumb-title">Payment Methods</h4>
                    <ul class="breadcrumb-menu">
                        <li><a href="index.php"><i class="far fa-home"></i> Home</a></li>
                        <li class="active">Payment Methods</li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- breadcrumb end -->


        <!-- user dashboard -->
        <div class="user-area bg pt-100 pb-80">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3">
                        <?php require __DIR__ . '/overall/sidenav.php'; ?>
                    </div>
                    <div class="col-lg-9">
                        <div class="user-wrapper">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="user-card">
                                        <div class="user-card-header">
                                            <h4 class="user-card-title">Payment Methods</h4>
                                            <div class="user-card-header-right">
                                                <a href="add-payment.php" class="theme-btn"><span class="far fa-plus-circle"></span>Add Payment</a>
                                            </div>
                                        </div>
                                        <div class="table-responsive">
                                            <table class="table table-borderless text-nowrap">
                                                <thead>
                                                    <tr>
                                                        <th>Card Info</th>
                                                        <th>Card Holder Name</th>
                                                        <th>Card Number</th>
                                                        <th>Expire Date</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>
                                                            <div class="table-list-img w-25">
                                                                <img class="rounded-3" src="assets/img/payment/amex.svg" alt="">
                                                            </div>
                                                        </td>
                                                        <td><span class="table-list-code">Antoni Jonson</span></td>
                                                        <td>1234***********</td>
                                                        <td>10/2024</td>
                                                        <td>
                                                            <a href="#" class="btn btn-outline-secondary btn-sm rounded-2" data-tooltip="tooltip" title="Edit"><i class="far fa-pen"></i></a>
                                                            <a href="#" class="btn btn-outline-danger btn-sm rounded-2" data-tooltip="tooltip" title="Delete"><i class="far fa-trash-can"></i></a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <div class="table-list-img w-25">
                                                                <img class="rounded-3" src="assets/img/payment/mastercard.svg" alt="">
                                                            </div>
                                                        </td>
                                                        <td><span class="table-list-code">Antoni Jonson</span></td>
                                                        <td>1234***********</td>
                                                        <td>10/2024</td>
                                                        <td>
                                                            <a href="#" class="btn btn-outline-secondary btn-sm rounded-2" data-tooltip="tooltip" title="Edit"><i class="far fa-pen"></i></a>
                                                            <a href="#" class="btn btn-outline-danger btn-sm rounded-2" data-tooltip="tooltip" title="Delete"><i class="far fa-trash-can"></i></a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <div class="table-list-img w-25">
                                                                <img class="rounded-3" src="assets/img/payment/visa.svg" alt="">
                                                            </div>
                                                        </td>
                                                        <td><span class="table-list-code">Antoni Jonson</span></td>
                                                        <td>1234***********</td>
                                                        <td>10/2024</td>
                                                        <td>
                                                            <a href="#" class="btn btn-outline-secondary btn-sm rounded-2" data-tooltip="tooltip" title="Edit"><i class="far fa-pen"></i></a>
                                                            <a href="#" class="btn btn-outline-danger btn-sm rounded-2" data-tooltip="tooltip" title="Delete"><i class="far fa-trash-can"></i></a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <div class="table-list-img w-25">
                                                                <img class="rounded-3" src="assets/img/payment/paypal.svg" alt="">
                                                            </div>
                                                        </td>
                                                        <td><span class="table-list-code">Antoni Jonson</span></td>
                                                        <td>1234***********</td>
                                                        <td>10/2024</td>
                                                        <td>
                                                            <a href="#" class="btn btn-outline-secondary btn-sm rounded-2" data-tooltip="tooltip" title="Edit"><i class="far fa-pen"></i></a>
                                                            <a href="#" class="btn btn-outline-danger btn-sm rounded-2" data-tooltip="tooltip" title="Delete"><i class="far fa-trash-can"></i></a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <div class="table-list-img w-25">
                                                                <img class="rounded-3" src="assets/img/payment/discover.svg" alt="">
                                                            </div>
                                                        </td>
                                                        <td><span class="table-list-code">Antoni Jonson</span></td>
                                                        <td>1234***********</td>
                                                        <td>10/2024</td>
                                                        <td>
                                                            <a href="#" class="btn btn-outline-secondary btn-sm rounded-2" data-tooltip="tooltip" title="Edit"><i class="far fa-pen"></i></a>
                                                            <a href="#" class="btn btn-outline-danger btn-sm rounded-2" data-tooltip="tooltip" title="Delete"><i class="far fa-trash-can"></i></a>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- user dashboard end -->

    </main>


    <?php require __DIR__ . '/overall/footer.php'; ?>
<?php require __DIR__ . '/overall/scripts.php'; ?>
