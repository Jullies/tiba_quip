<?php
require_once __DIR__ . '/../control/core/database/connect.php';
$currentPage = basename($_SERVER['SCRIPT_NAME'] ?? '');
