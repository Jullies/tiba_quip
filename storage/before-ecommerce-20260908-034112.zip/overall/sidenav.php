<div class="sidebar">
                            <div class="sidebar-top">
                                <div class="sidebar-profile-img">
                                    <img src="assets/img/account/03.jpg" alt="">
                                    <button type="button" class="profile-img-btn"><i class="far fa-camera"></i></button>
                                    <input type="file" class="profile-img-file">
                                </div>
                                <h5>Antoni Jonson</h5>
                                <p>antoni@example.com</p>
                            </div>
                            <ul class="sidebar-list">
                                <li><a class="<?= $currentPage === 'user-dashboard.php' ? 'active' : '' ?>" href="user-dashboard.php"><i class="far fa-gauge-high"></i> Dashboard</a></li>
                                <li><a class="<?= $currentPage === 'user-profile.php' ? 'active' : '' ?>" href="user-profile.php"><i class="far fa-user"></i> My Profile</a></li>
                                <li><a class="<?= $currentPage === 'order-list.php' ? 'active' : '' ?>" href="order-list.php"><i class="far fa-shopping-bag"></i> My Order List <span class="badge badge-danger">02</span></a></li>
                                <li><a class="<?= $currentPage === 'wishlist.php' ? 'active' : '' ?>" href="wishlist.php"><i class="far fa-heart"></i> My Wishlist <span class="badge badge-danger">02</span></a></li>
                                <li><a class="<?= $currentPage === 'address-list.php' ? 'active' : '' ?>" href="address-list.php"><i class="far fa-location-dot"></i> Address List</a></li>
                                <li><a class="<?= $currentPage === 'support-ticket.php' ? 'active' : '' ?>" href="support-ticket.php"><i class="far fa-headset"></i> Support Tickets <span class="badge badge-danger">02</span></a></li>
                                <li><a class="<?= $currentPage === 'track-order.php' ? 'active' : '' ?>" href="track-order.php"><i class="far fa-map-location-dot"></i> Track My Order</a></li>
                                <li><a class="<?= $currentPage === 'payment-method.php' ? 'active' : '' ?>" href="payment-method.php"><i class="far fa-wallet"></i> Payment Methods</a></li>
                                <li><a class="<?= $currentPage === 'user-notification.php' ? 'active' : '' ?>" href="user-notification.php"><i class="far fa-bell"></i> Notification <span class="badge badge-danger">02</span></a></li>
                                <li><a class="<?= $currentPage === 'user-message.php' ? 'active' : '' ?>" href="user-message.php"><i class="far fa-envelope"></i> Messages <span class="badge badge-danger">02</span></a></li>
                                <li><a class="<?= $currentPage === 'user-setting.php' ? 'active' : '' ?>" href="user-setting.php"><i class="far fa-gear"></i> Settings</a></li>
                                <li><a href="#"><i class="far fa-sign-out"></i> Logout</a></li>
                            </ul>
                        </div>
