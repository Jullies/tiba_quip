<!-- header area -->
    <header class="header">

        <?php require __DIR__ . '/topbar.php'; ?>

        <!-- header middle -->
        <div class="header-middle">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-5 col-lg-3 col-xl-3">
                        <div class="header-middle-logo">
                            <a class="navbar-brand" href="index.php">
                                <img src="assets/img/logo/logo.png" alt="logo">
                            </a>
                        </div>
                    </div>
                    <div class="d-none d-lg-block col-lg-6 col-xl-5">
                        <div class="header-middle-search">
                            <form action="#">
                                <div class="search-content">
                                    <select class="select">
                                        <option value="">All Category</option>
                                        <option value="1">Medicine</option>
                                        <option value="2">Medical Equipments</option>
                                        <option value="3">Beauty Care</option>
                                        <option value="4">Baby & Mom Care</option>
                                        <option value="5">Healthcare</option>
                                        <option value="6">Food & Nutrition</option>
                                        <option value="7">Medical Supplies</option>
                                        <option value="8">Lab Test</option>
                                        <option value="9">Fitness</option>
                                        <option value="10">Vitamins & Supplement</option>
                                        <option value="11">Pet Care</option>
                                    </select>
                                    <input type="text" class="form-control" placeholder="Search Here...">
                                    <button type="submit" class="search-btn"><i class="far fa-search"></i></button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-7 col-lg-3 col-xl-4">
                        <div class="header-middle-right">
                            <ul class="header-middle-list">
                                <li>
                                    <a href="#" class="list-item">
                                        <div class="list-item-icon">
                                            <i class="far fa-user-circle"></i>
                                        </div>
                                        <div class="list-item-info">
                                            <h6>Sign In</h6>
                                            <h5>Account</h5>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" class="list-item">
                                        <div class="list-item-icon">
                                            <i class="far fa-heart"></i><span>0</span>
                                        </div>
                                        <div class="list-item-info">
                                            <h6>Wishlist</h6>
                                            <h5>My Items</h5>
                                        </div>
                                    </a>
                                </li>
                                <li class="dropdown-cart">
                                    <a href="#" class="shop-cart list-item">
                                        <div class="list-item-icon">
                                            <i class="far fa-shopping-bag"></i><span>5</span>
                                        </div>
                                        <div class="list-item-info">
                                            <h6>$350.00</h6>
                                            <h5>My Cart</h5>
                                        </div>
                                    </a>
                                    <div class="dropdown-cart-menu">
                                        <div class="dropdown-cart-header">
                                            <span>03 Items</span>
                                            <a href="#">View Cart</a>
                                        </div>
                                        <ul class="dropdown-cart-list">
                                            <li>
                                                <div class="dropdown-cart-item">
                                                    <div class="cart-img">
                                                        <a href="#"><img src="assets/img/product/01.png" alt="#"></a>
                                                    </div>
                                                    <div class="cart-info">
                                                        <h4><a href="#">Surgical Face Mask</a></h4>
                                                        <p class="cart-qty">1x - <span
                                                                class="cart-amount">$200.00</span></p>
                                                    </div>
                                                    <a href="#" class="cart-remove" title="Remove this item"><i
                                                            class="far fa-times-circle"></i></a>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="dropdown-cart-item">
                                                    <div class="cart-img">
                                                        <a href="#"><img src="assets/img/product/02.png" alt="#"></a>
                                                    </div>
                                                    <div class="cart-info">
                                                        <h4><a href="#">Surgical Face Mask</a></h4>
                                                        <p class="cart-qty">1x - <span
                                                                class="cart-amount">$120.00</span></p>
                                                    </div>
                                                    <a href="#" class="cart-remove" title="Remove this item"><i
                                                            class="far fa-times-circle"></i></a>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="dropdown-cart-item">
                                                    <div class="cart-img">
                                                        <a href="#"><img src="assets/img/product/03.png" alt="#"></a>
                                                    </div>
                                                    <div class="cart-info">
                                                        <h4><a href="#">Surgical Face Mask</a></h4>
                                                        <p class="cart-qty">1x - <span
                                                                class="cart-amount">$330.00</span></p>
                                                    </div>
                                                    <a href="#" class="cart-remove" title="Remove this item"><i
                                                            class="far fa-times-circle"></i></a>
                                                </div>
                                            </li>
                                        </ul>
                                        <div class="dropdown-cart-bottom">
                                            <div class="dropdown-cart-total">
                                                <span>Total</span>
                                                <span class="total-amount">$650.00</span>
                                            </div>
                                            <a href="#" class="theme-btn">Checkout</a>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- header middle end -->

        <!-- navbar -->
        <div class="main-navigation">
            <nav class="navbar navbar-expand-lg">
                <div class="container position-relative">
                    <a class="navbar-brand" href="index.php">
                        <img src="assets/img/logo/logo.png" class="logo-scrolled" alt="logo">
                    </a>
                    <div class="category-all">
                        <button class="category-btn" type="button">
                            <i class="fas fa-list-ul"></i><span>All Categories</span>
                        </button>
                        <ul class="main-category">
                            <li>
                                <a href="#">
                                    <img src="assets/img/icon/medicine.svg" alt="">
                                    <span>Medicine</span><i class="far fa-angle-right"></i>
                                </a>
                                <div class="sub-category-mega">
                                    <div class="row">
                                        <div class="col-lg-3">
                                            <div class="category-single">
                                                <h6 class="category-title-text">Medicine</h6>
                                                <div class="category-link">
                                                    <a href="#">Allergies & Sinus</a>
                                                    <a href="#">E.N.T Preparations</a>
                                                    <a href="#">Eye Preparations</a>
                                                    <a href="#">Vitamin & Nutritional</a>
                                                    <a href="#">Fever & Pain Relief</a>
                                                    <a href="#">Dermatological</a>
                                                    <a href="#">Bone Formation</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="category-single">
                                                <h6 class="category-title-text">Medicine</h6>
                                                <div class="category-link">
                                                    <a href="#">Allergies & Sinus</a>
                                                    <a href="#">E.N.T Preparations</a>
                                                    <a href="#">Eye Preparations</a>
                                                    <a href="#">Vitamin & Nutritional</a>
                                                    <a href="#">Fever & Pain Relief</a>
                                                    <a href="#">Dermatological</a>
                                                    <a href="#">Bone Formation</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="category-single">
                                                <h6 class="category-title-text">Medicine</h6>
                                                <div class="category-link">
                                                    <a href="#">Allergies & Sinus</a>
                                                    <a href="#">E.N.T Preparations</a>
                                                    <a href="#">Eye Preparations</a>
                                                    <a href="#">Vitamin & Nutritional</a>
                                                    <a href="#">Fever & Pain Relief</a>
                                                    <a href="#">Dermatological</a>
                                                    <a href="#">Bone Formation</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="category-img">
                                                <a href="#"><img src="assets/img/banner/category-banner.jpg" alt=""></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li><a href="#"><img src="assets/img/icon/health-care.svg" alt=""><span>Healthcare</span></a></li>
                            <li><a href="#"><img src="assets/img/icon/beauty-care.svg" alt=""><span>Beauty Care</span></a></li>
                            <li><a href="#"><img src="assets/img/icon/sexual.svg" alt=""><span>Sexual Wellness</span></a></li>
                            <li><a href="#"><img src="assets/img/icon/fitness.svg" alt=""><span>Fitness</span></a></li>
                            <li><a href="#"><img src="assets/img/icon/lab-test.svg" alt=""><span>Lab Test</span></a></li>
                            <li><a href="#"><img src="assets/img/icon/baby-mom-care.svg" alt=""><span>Baby & Mom Care</span></a></li>
                            <li><a href="#"><img src="assets/img/icon/supplements.svg" alt=""><span>Vitamins & Supplement</span></a></li>
                            <li><a href="#"><img src="assets/img/icon/food-nutrition.svg" alt=""><span>Food & Nutrition</span></a></li>
                            <li><a href="#"><img src="assets/img/icon/medical-equipements.svg" alt=""><span>Medical Equipments</span></a></li>
                            <li><a href="#"><img src="assets/img/icon/medical-supplies.svg" alt=""><span>Medical Supplies</span></a></li>
                            <li><a href="#"><img src="assets/img/icon/pet-care.svg" alt=""><span>Pet Care</span></a></li>
                        </ul>
                    </div>
                    <div class="mobile-menu-right">
                        <div class="mobile-menu-btn">
                            <a href="#" class="nav-right-link search-box-outer"><i class="far fa-search"></i></a>
                            <a href="wishlist.php" class="nav-right-link"><i
                                    class="far fa-heart"></i><span>2</span></a>
                            <a href="shop-cart.php" class="nav-right-link"><i
                                    class="far fa-shopping-bag"></i><span>5</span></a>
                        </div>
                        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas"
                            data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar"
                            aria-label="Toggle navigation">
                            <span></span>
                            <span></span>
                            <span></span>
                        </button>
                    </div>
                    <div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasNavbar"
                        aria-labelledby="offcanvasNavbarLabel">
                        <div class="offcanvas-header">
                            <a href="index.php" class="offcanvas-brand" id="offcanvasNavbarLabel">
                                <img src="assets/img/logo/logo.png" alt="">
                            </a>
                            <button type="button" class="btn-close" data-bs-dismiss="offcanvas"
                                aria-label="Close"></button>
                        </div>
                        <div class="offcanvas-body">
                            <ul class="navbar-nav justify-content-end flex-grow-1">
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#"
                                        data-bs-toggle="dropdown">Home</a>
                                    <ul class="dropdown-menu fade-down">
                                        <li><a class="dropdown-item" href="index.php">Home Demo 01</a></li>
                                        <li><a class="dropdown-item" href="index-2.php">Home Demo 02</a></li>
                                        <li><a class="dropdown-item" href="index-3.php">Home Demo 03</a></li>
                                    </ul>
                                </li>
                                <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Pages</a>
                                    <ul class="dropdown-menu fade-down">
                                        <li><a class="dropdown-item" href="about.php">About Us</a></li>
                                        <li><a class="dropdown-item" href="brand.php">Brands</a></li>
                                        <li class="dropdown-submenu">
                                            <a class="dropdown-item dropdown-toggle" href="#">Category</a>
                                            <ul class="dropdown-menu">
                                                <li><a class="dropdown-item" href="category.php">Category One</a></li>
                                                <li><a class="dropdown-item" href="category-2.php">Category Two</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li class="dropdown-submenu">
                                            <a class="dropdown-item dropdown-toggle" href="#">Authentication</a>
                                            <ul class="dropdown-menu">
                                                <li><a class="dropdown-item" href="login.php">Login</a></li>
                                                <li><a class="dropdown-item" href="register.php">Register</a></li>
                                                <li><a class="dropdown-item" href="forgot-password.php">Forgot
                                                        Password</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li class="dropdown-submenu">
                                            <a class="dropdown-item dropdown-toggle" href="#">Extra Pages</a>
                                            <ul class="dropdown-menu">
                                                <li><a class="dropdown-item" href="coming-soon.php">Coming Soon</a>
                                                </li>
                                                <li><a class="dropdown-item" href="return.php">Return Policy</a></li>
                                                <li><a class="dropdown-item" href="terms.php">Terms Of Service</a></li>
                                                <li><a class="dropdown-item" href="privacy.php">Privacy Policy</a></li>
                                                <li><a class="dropdown-item" href="mail-success.php">Mail Success</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li><a class="dropdown-item" href="team.php">Our Team</a></li>
                                        <li><a class="dropdown-item" href="affiliate.php">Affiliate</a></li>
                                        <li><a class="dropdown-item" href="gallery.php">Our Gallery</a></li>
                                        <li><a class="dropdown-item" href="contact.php">Contact Us</a></li>
                                        <li><a class="dropdown-item" href="help.php">Help</a></li>
                                        <li><a class="dropdown-item" href="invoice.php">Invoices</a></li>
                                        <li><a class="dropdown-item" href="faq.php">Faq</a></li>
                                        <li><a class="dropdown-item" href="testimonial.php">Testimonials</a></li>
                                        <li><a class="dropdown-item" href="404.php">404 Error</a></li>
                                    </ul>
                                </li>
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Account</a>
                                    <ul class="dropdown-menu fade-down">
                                        <li><a class="dropdown-item" href="user-dashboard.php">Dashboard</a></li>
                                        <li><a class="dropdown-item" href="user-profile.php">My Profile</a></li>
                                        <li class="dropdown-submenu">
                                            <a class="dropdown-item dropdown-toggle" href="#">Orders</a>
                                            <ul class="dropdown-menu">
                                                <li><a class="dropdown-item" href="order-list.php">Orders List</a></li>
                                                <li><a class="dropdown-item" href="order-detail.php">Order Details</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li><a class="dropdown-item" href="wishlist.php">My Wishlist</a></li>
                                        <li class="dropdown-submenu">
                                            <a class="dropdown-item dropdown-toggle" href="#">Address</a>
                                            <ul class="dropdown-menu">
                                                <li><a class="dropdown-item" href="address-list.php">Address List</a>
                                                </li>
                                                <li><a class="dropdown-item" href="add-address.php">Add Address</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li class="dropdown-submenu">
                                            <a class="dropdown-item dropdown-toggle" href="#">Support Tickets</a>
                                            <ul class="dropdown-menu">
                                                <li><a class="dropdown-item" href="support-ticket.php">Support
                                                        Tickets</a></li>
                                                <li><a class="dropdown-item" href="ticket-detail.php">Ticket
                                                        Details</a></li>
                                            </ul>
                                        </li>
                                        <li><a class="dropdown-item" href="track-order.php">Track My Order</a></li>
                                        <li class="dropdown-submenu">
                                            <a class="dropdown-item dropdown-toggle" href="#">Payment Methods</a>
                                            <ul class="dropdown-menu">
                                                <li><a class="dropdown-item" href="payment-method.php">Payment
                                                        Methods</a></li>
                                                <li><a class="dropdown-item" href="add-payment.php">Add Payment</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li><a class="dropdown-item" href="user-notification.php">Notification</a></li>
                                        <li><a class="dropdown-item" href="user-message.php">Messages</a></li>
                                        <li><a class="dropdown-item" href="user-setting.php">Settings</a></li>
                                    </ul>
                                </li>
                                <li class="nav-item mega-menu dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Menu</a>
                                    <div class="dropdown-menu fade-down">
                                        <div class="mega-content">
                                            <div class="container-fluid px-lg-0">
                                                <div class="row">
                                                    <div class="col-12 col-lg-2">
                                                        <h5 class="mega-menu-title">Medicine</h5>
                                                        <ul class="mega-menu-item">
                                                            <li><a class="dropdown-item"
                                                                    href="shop-grid.php">Allergies & Sinus</a></li>
                                                            <li><a class="dropdown-item" href="shop-grid.php">E.N.T Preparations</a></li>
                                                            <li><a class="dropdown-item"
                                                                    href="shop-grid.php">Eye Preparations</a></li>
                                                            <li><a class="dropdown-item"
                                                                    href="shop-grid.php">Vitamin & Nutritional</a></li>
                                                            <li><a class="dropdown-item"
                                                                    href="shop-grid.php">Fever & Pain Relief</a></li>
                                                            <li><a class="dropdown-item"
                                                                    href="shop-grid.php">Dermatological</a></li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-12 col-lg-2">
                                                        <h5 class="mega-menu-title">Equipment</h5>
                                                        <ul class="mega-menu-item">
                                                            <li><a class="dropdown-item"
                                                                    href="shop-grid.php">Biopsy Tools</a></li>
                                                            <li><a class="dropdown-item"
                                                                    href="shop-grid.php">Monitoring</a></li>
                                                            <li><a class="dropdown-item" href="shop-grid.php">Infusion Stands</a>
                                                            </li>
                                                            <li><a class="dropdown-item" href="shop-grid.php">Lighting</a>
                                                            </li>
                                                            <li><a class="dropdown-item"
                                                                    href="shop-grid.php">Machines</a></li>
                                                            <li><a class="dropdown-item" href="shop-grid.php">Thermometer</a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-12 col-lg-2">
                                                        <h5 class="mega-menu-title">Wound Care</h5>
                                                        <ul class="mega-menu-item">
                                                            <li><a class="dropdown-item"
                                                                    href="shop-grid.php">Surgical Sutures</a></li>
                                                            <li><a class="dropdown-item" href="shop-grid.php">Bandages</a></li>
                                                            <li><a class="dropdown-item"
                                                                    href="shop-grid.php">Patches and Tapes</a></li>
                                                            <li><a class="dropdown-item"
                                                                    href="shop-grid.php">Stomatology</a></li>
                                                            <li><a class="dropdown-item"
                                                                    href="shop-grid.php">Wound Healing</a></li>
                                                            <li><a class="dropdown-item"
                                                                    href="shop-grid.php">Uniforms</a></li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-12 col-lg-2">
                                                        <h5 class="mega-menu-title">Higiene</h5>
                                                        <ul class="mega-menu-item">
                                                            <li><a class="dropdown-item"
                                                                    href="shop-grid.php">Face Masks</a></li>
                                                            <li><a class="dropdown-item" href="shop-grid.php">Sterilization</a></li>
                                                            <li><a class="dropdown-item"
                                                                    href="shop-grid.php">Surgical Foils</a></li>
                                                            <li><a class="dropdown-item"
                                                                    href="shop-grid.php">Disposable Products</a></li>
                                                            <li><a class="dropdown-item"
                                                                    href="shop-grid.php">Protective Covers</a></li>
                                                            <li><a class="dropdown-item"
                                                                    href="shop-grid.php">Diagnostic Tests</a></li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-12 col-lg-4">
                                                        <div class="mega-menu-img">
                                                            <a href="#"><img
                                                                    src="assets/img/banner/mega-menu-banner.jpg"
                                                                    alt=""></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Shop</a>
                                    <ul class="dropdown-menu fade-down">
                                        <li class="dropdown-submenu">
                                            <a class="dropdown-item dropdown-toggle" href="#">Shop Grid</a>
                                            <ul class="dropdown-menu">
                                                <li><a class="dropdown-item" href="shop-grid.php">Shop Grid One</a>
                                                </li>
                                                <li><a class="dropdown-item" href="shop-grid-2.php">Shop Grid Two</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li class="dropdown-submenu">
                                            <a class="dropdown-item dropdown-toggle" href="#">Shop List</a>
                                            <ul class="dropdown-menu">
                                                <li><a class="dropdown-item" href="shop-list.php">Shop List One</a>
                                                </li>
                                                <li><a class="dropdown-item" href="shop-list-2.php">Shop List Two</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li><a class="dropdown-item" href="shop-search.php">Shop Search</a></li>
                                        <li><a class="dropdown-item" href="shop-cart.php">Shop Cart</a></li>
                                        <li><a class="dropdown-item" href="shop-checkout.php">Checkout</a></li>
                                        <li><a class="dropdown-item" href="shop-checkout-complete.php">Checkout
                                                Complete</a></li>
                                        <li><a class="dropdown-item" href="shop-single.php">Shop Single</a></li>
                                        <li><a class="dropdown-item" href="shop-compare.php">Shop Compare</a></li>
                                    </ul>
                                </li>
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Blog</a>
                                    <ul class="dropdown-menu fade-down">
                                        <li><a class="dropdown-item" href="blog-grid.php">Blog Grid</a></li>
                                        <li><a class="dropdown-item" href="blog-grid-sidebar.php">Blog Grid Sidebar</a>
                                        </li>
                                        <li><a class="dropdown-item" href="blog-single.php">Blog Single</a></li>
                                        <li><a class="dropdown-item" href="blog-single-sidebar.php">Blog Single
                                                Sidebar</a></li>
                                    </ul>
                                </li>
                                <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
                            </ul>
                            <!-- nav-right -->
                            <div class="nav-right">
                                <a class="nav-right-link" href="#"><i class="fal fa-star"></i> Recently Viewed</a>
                                <a class="nav-right-link" href="track-order.php"><i class="fal fa-truck-fast"></i> Track My Order</a>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>
        </div>
        <!-- navbar end -->

    </header>
    <!-- header area end -->


    <!-- mobile popup search -->
    <div class="search-popup">
        <button class="close-search"><span class="far fa-times"></span></button>
        <form action="#">
            <div class="form-group">
                <input type="search" name="search-field" class="form-control" placeholder="Search Here..." required>
                <button type="submit"><i class="far fa-search"></i></button>
            </div>
        </form>
    </div>
    <!-- mobile popup search end -->
