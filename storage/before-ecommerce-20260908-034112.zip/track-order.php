<?php
require_once __DIR__ . '/overall/bootstrap.php';
$bodyClass = '';
$pageScripts = [];
require __DIR__ . '/overall/head.php';
require __DIR__ . '/overall/header.php';
?>
<main class="main">

        <!-- breadcrumb -->
        <div class="site-breadcrumb">
            <div class="site-breadcrumb-bg" style="background: url(assets/img/breadcrumb/01.jpg)"></div>
            <div class="container">
                <div class="site-breadcrumb-wrap">
                    <h4 class="breadcrumb-title">Track My Order</h4>
                    <ul class="breadcrumb-menu">
                        <li><a href="index.php"><i class="far fa-home"></i> Home</a></li>
                        <li class="active">Track My Order</li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- breadcrumb end -->


        <!-- user dashboard -->
        <div class="user-area bg pt-100 pb-80">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3">
                        <?php require __DIR__ . '/overall/sidenav.php'; ?>
                    </div>
                    <div class="col-lg-9">
                        <div class="user-wrapper">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="user-card user-track-order">
                                        <h4 class="user-card-title">Track My Order</h4>
                                        <div class="track-order-content">
                                            <h5>Tracking Order Number: <span>#28VR5K59</span></h5>
                                            <div class="track-order-info">
                                                <a href="#"><span>Shipped Via:</span> Express Shipping</a>
                                                <a href="#"><span>Status:</span> Checking Quality</a>
                                                <a href="#"><span>Expected Date:</span> August 27, 2024</a>
                                            </div>
                                            <div class="track-order-step">
                                                <div class="step-item completed">
                                                    <div class="step-icon">
                                                        <i class="fal fa-shopping-cart"></i>
                                                    </div>
                                                    <h6>Confirmed Order</h6>
                                                </div>
                                                <div class="step-item completed">
                                                    <div class="step-icon">
                                                        <i class="fal fa-cog"></i>
                                                    </div>
                                                    <h6>Processing Order</h6>
                                                </div>
                                                <div class="step-item completed">
                                                    <div class="step-icon">
                                                        <i class="fal fa-check-circle"></i>
                                                    </div>
                                                    <h6>Quality Check</h6>
                                                </div>
                                                <div class="step-item">
                                                    <div class="step-icon">
                                                        <i class="fal fa-truck-fast"></i>
                                                    </div>
                                                    <h6>Product Dispatched</h6>
                                                </div>
                                                <div class="step-item">
                                                    <div class="step-icon">
                                                        <i class="fal fa-home"></i>
                                                    </div>
                                                    <h6>Product Delivered</h6>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- user dashboard end -->

    </main>


    <?php require __DIR__ . '/overall/footer.php'; ?>
<?php require __DIR__ . '/overall/scripts.php'; ?>
