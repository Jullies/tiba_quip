<?php
require_once __DIR__ . '/overall/bootstrap.php';
$bodyClass = '';
$pageScripts = [];
require __DIR__ . '/overall/head.php';
require __DIR__ . '/overall/header.php';
?>
<main class="main">

        <!-- breadcrumb -->
        <div class="site-breadcrumb">
            <div class="site-breadcrumb-bg" style="background: url(assets/img/breadcrumb/01.jpg)"></div>
            <div class="container">
                <div class="site-breadcrumb-wrap">
                    <h4 class="breadcrumb-title">Order Details</h4>
                    <ul class="breadcrumb-menu">
                        <li><a href="index.php"><i class="far fa-home"></i> Home</a></li>
                        <li class="active">Order Details</li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- breadcrumb end -->


        <!-- user dashboard -->
        <div class="user-area bg pt-100 pb-80">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3">
                        <?php require __DIR__ . '/overall/sidenav.php'; ?>
                    </div>
                    <div class="col-lg-9">
                        <div class="user-wrapper">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="user-card user-order-detail">
                                        <div class="user-card-header">
                                            <h4 class="user-card-title">Order Details (#28VR5K59)</h4>
                                            <div class="user-card-header-right">
                                                <a href="order-list.php" class="theme-btn"><span class="fas fa-arrow-left"></span>Order List</a>
                                            </div> 
                                        </div>
                                        <div class="table-responsive">
                                            <table class="table table-borderless text-nowrap">
                                                <thead>
                                                    <tr>
                                                        <th>Product</th>
                                                        <th>Brand</th>
                                                        <th>Quantity</th>
                                                        <th>Size</th>
                                                        <th>Color</th>
                                                        <th>Total</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>
                                                            <div class="table-list-info">
                                                                <a href="#">
                                                                    <div class="table-list-img">
                                                                        <img src="assets/img/product/01.png" alt="">
                                                                    </div>
                                                                    <div class="table-list-content">
                                                                        <h6>Surgical Face Mask</h6>
                                                                        <span>Item ID: #123456</span>
                                                                    </div>
                                                                </a>
                                                            </div>
                                                        </td>
                                                        <td>Moderno</td>
                                                        <td>20 Pcs</td>
                                                        <td>XXL</td>
                                                        <td>Black</td>
                                                        <td>$150</td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <div class="table-list-info">
                                                                <a href="#">
                                                                    <div class="table-list-img">
                                                                        <img src="assets/img/product/02.png" alt="">
                                                                    </div>
                                                                    <div class="table-list-content">
                                                                        <h6>Surgical Face Mask</h6>
                                                                        <span>Item ID: #123456</span>
                                                                    </div>
                                                                </a>
                                                            </div>
                                                        </td>
                                                        <td>Moderno</td>
                                                        <td>20 Pcs</td>
                                                        <td>XXL</td>
                                                        <td>Black</td>
                                                        <td>$150</td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <div class="table-list-info">
                                                                <a href="#">
                                                                    <div class="table-list-img">
                                                                        <img src="assets/img/product/03.png" alt="">
                                                                    </div>
                                                                    <div class="table-list-content">
                                                                        <h6>Surgical Face Mask</h6>
                                                                        <span>Item ID: #123456</span>
                                                                    </div>
                                                                </a>
                                                            </div>
                                                        </td>
                                                        <td>Moderno</td>
                                                        <td>20 Pcs</td>
                                                        <td>XXL</td>
                                                        <td>Black</td>
                                                        <td>$150</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="order-detail-content">
                                                    <h5>Shipping Address</h5>
                                                    <p><i class="far fa-location-dot"></i> 25/B Milford Road, Richison Drive, New York, USA</p>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="order-detail-content">
                                                    <h5>Order Summary</h5>
                                                    <ul>
                                                        <li>Subtotal<span>$350.00</span></li>
                                                        <li>Shipping<span>Free</span></li>
                                                        <li>Discount<span>$10.00</span></li>
                                                        <li>Tax<span>$20.00</span></li>
                                                        <li>Total<span>$360.00</span></li>
                                                    </ul>
                                                    <p class="mt-4">Paid by Credit/Debit Card</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- user dashboard end -->

    </main>


    <?php require __DIR__ . '/overall/footer.php'; ?>
<?php require __DIR__ . '/overall/scripts.php'; ?>
