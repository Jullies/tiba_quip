<?php
require_once __DIR__ . '/includes/bootstrap.php';

$schema = "
    CREATE TABLE IF NOT EXISTS shop_service_requests (
        request_id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        request_type ENUM('service','product') NOT NULL,
        item_name VARCHAR(160) NOT NULL,
        customer_name VARCHAR(160) NOT NULL,
        customer_email VARCHAR(190) NOT NULL,
        customer_phone VARCHAR(40) NOT NULL,
        message TEXT NULL,
        page_path VARCHAR(190) DEFAULT NULL,
        status ENUM('new','contacted','closed') NOT NULL DEFAULT 'new',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        KEY idx_request_status (status, created_at),
        KEY idx_request_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
";
mysqli_query($conn, $schema);

$statusTable = 'shop_service_requests';
$statusPrimaryKey = 'request_id';
require __DIR__ . '/includes/request-status.php';
$requests = [];
$requestQuery = mysqli_query($conn, "SELECT request_id, request_type, item_name, customer_name, customer_email, customer_phone, message, page_path, status, created_at FROM shop_service_requests ORDER BY FIELD(status, 'new', 'contacted', 'closed'), created_at DESC LIMIT 250");
while ($requestQuery && ($row = mysqli_fetch_assoc($requestQuery))) {
    $requests[] = $row;
}
?>
<?php include __DIR__ . '/includes/head.php'; ?>
<?php include __DIR__ . '/includes/sidenav.php'; ?>
<div class="section-content-right">
    <?php include __DIR__ . '/includes/topbar.php'; ?>
    <div class="main-content"><div class="main-content-inner"><div class="main-content-wrap">
<?php if (!empty($statusError)): ?><div class="alert alert-danger" role="alert"><?php echo jd_admin_h($statusError); ?></div><?php endif; ?>
        <div class="flex items-center justify-between flex-wrap gap20 mb-27">
            <div><h3>Service &amp; Product Requests</h3><div class="body-text">Customer details collected from the JD Shop services page.</div></div>
            <div class="body-title-2"><?php echo number_format(count($requests)); ?> requests</div>
        </div>
        <div class="wg-box">
            <div class="wg-table table-all-user">
                <ul class="table-title flex gap20 mb-14">
                    <li><div class="body-title">Customer</div></li><li><div class="body-title">Request</div></li><li><div class="body-title">Contact details</div></li><li><div class="body-title">Message</div></li><li><div class="body-title">Received</div></li>
                </ul>
                <ul class="flex flex-column gap14">
                    <?php if (empty($requests)): ?>
                        <li class="product-item gap14"><div class="body-text">No service or product requests have been submitted yet.</div></li>
                    <?php else: ?>
                        <?php foreach ($requests as $request): ?>
                            <?php $type = ($request['request_type'] ?? '') === 'product' ? 'Product' : 'Service'; ?>
                            <li class="product-item gap14">
                                <div class="flex items-center justify-between flex-grow gap20 service-request-row">
                                    <div><div class="body-title-2"><?php echo jd_admin_h($request['customer_name']); ?></div><div class="text-tiny">#<?php echo (int)$request['request_id']; ?></div></div>
                                    <div><span class="block-available"><?php echo $type; ?></span><div class="body-text mt-4"><?php echo jd_admin_h($request['item_name']); ?></div></div>
                                    <div><a class="body-text" href="tel:<?php echo rawurlencode((string)$request['customer_phone']); ?>"><?php echo jd_admin_h($request['customer_phone']); ?></a><br><a class="text-tiny" href="mailto:<?php echo rawurlencode((string)$request['customer_email']); ?>"><?php echo jd_admin_h($request['customer_email']); ?></a></div>
                                    <div class="text-tiny service-request-row__message"><?php echo jd_admin_h($request['message'] ?: 'No additional message.'); ?></div>
                                    <div class="text-tiny"><?php echo !empty($request['created_at']) ? date('M d, Y H:i', strtotime($request['created_at'])) : '—'; ?><?php jd_admin_status_form($request['request_id'], $request['status']); ?></div>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
        <style>.service-request-row > div{min-width:0}.service-request-row__message{max-width:280px;line-height:1.5}@media(max-width:991px){.service-request-row{align-items:flex-start!important;flex-direction:column}}</style>
    </div></div></div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
