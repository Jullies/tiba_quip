<?php
require_once __DIR__ . '/includes/bootstrap.php';

$productId = max(0, (int)($_GET['id'] ?? 0));
if ($productId <= 0) {
    header('Location: product-list.php');
    exit;
}
if (function_exists('ensure_product_details_table')) {
    ensure_product_details_table($conn);
}
$sql = "SELECT p.*, pd.sku, pd.description, pd.additional_info, pd.size_guide
        FROM my_shop_products p
        LEFT JOIN my_shop_product_details pd ON pd.product_id = p.product_id
        WHERE p.product_id = {$productId} LIMIT 1";
$result = mysqli_query($conn, $sql);
$product = $result ? mysqli_fetch_assoc($result) : null;
if (!$product) {
    header('Location: product-list.php');
    exit;
}
$categories = [];
$byCategory = [];
$result = mysqli_query($conn, 'SELECT product_catg_id, product_category FROM my_shop_categories ORDER BY product_category');
while ($result && ($row = mysqli_fetch_assoc($result))) { $categories[] = $row; }
$result = mysqli_query($conn, 'SELECT product_sub_catg_id, product_catg_id, product_sub_category FROM my_shop_sub_categories ORDER BY product_sub_category');
while ($result && ($row = mysqli_fetch_assoc($result))) { $byCategory[(int)$row['product_catg_id']][] = $row; }
?>
<?php include __DIR__ . '/includes/head.php'; ?>
<?php include __DIR__ . '/includes/sidenav.php'; ?>
<div class="section-content-right"><?php include __DIR__ . '/includes/topbar.php'; ?>
    <div class="main-content"><div class="main-content-inner"><div class="main-content-wrap">
        <div class="flex items-center justify-between flex-wrap gap20 mb-27">
            <div><h3>Edit product</h3><div class="body-text">Update the product, its details, and its real product image.</div></div>
            <a class="tf-button style-3" href="product-list.php"><i class="icon-arrow-left"></i>Back to products</a>
        </div>
        <div class="wg-box">
            <form id="productEditForm" enctype="multipart/form-data" class="form-new-product form-style-1">
                <input type="hidden" name="csrf_token" value="<?php echo jd_admin_h(jd_admin_csrf_token()); ?>">
                <input type="hidden" name="product_id" value="<?php echo (int)$product['product_id']; ?>">
                <input type="hidden" name="update_shop_product" value="1">
                <div id="productEditMessage" class="alert" style="display:none" role="alert"></div>
                <fieldset class="name"><div class="body-title">Product name <span class="tf-color-1">*</span></div><input class="flex-grow" name="product_name" required value="<?php echo jd_admin_h($product['product_name']); ?>"></fieldset>
                <fieldset class="category"><div class="body-title">Subcategory</div><div class="select flex-grow"><select name="product_sub_catg_id"><option value="">Uncategorized</option><?php foreach ($categories as $category): foreach (($byCategory[(int)$category['product_catg_id']] ?? []) as $subcategory): ?><option value="<?php echo (int)$subcategory['product_sub_catg_id']; ?>" <?php echo (int)$product['product_sub_catg_id'] === (int)$subcategory['product_sub_catg_id'] ? 'selected' : ''; ?>><?php echo jd_admin_h($category['product_category'].' — '.$subcategory['product_sub_category']); ?></option><?php endforeach; endforeach; ?></select></div></fieldset>
                <fieldset class="name"><div class="body-title">SKU</div><input class="flex-grow" name="product_sku" value="<?php echo jd_admin_h($product['sku'] ?? ''); ?>"></fieldset>
                <fieldset class="name"><div class="body-title">Selling price (KSh) <span class="tf-color-1">*</span></div><input class="flex-grow" type="number" min="0" step="1" name="selling_price" required value="<?php echo (float)$product['selling_price']; ?>"></fieldset>
                <fieldset class="name"><div class="body-title">Previous price (KSh)</div><input class="flex-grow" type="number" min="0" step="1" name="was_selling_price" value="<?php echo $product['was_selling_price'] !== null ? (float)$product['was_selling_price'] : ''; ?>"></fieldset>
                <fieldset><div class="body-title">Description</div><textarea name="product_description" rows="4"><?php echo jd_admin_h($product['description'] ?? ''); ?></textarea></fieldset>
                <fieldset><div class="body-title">Additional information</div><textarea name="product_additional_info" rows="3"><?php echo jd_admin_h($product['additional_info'] ?? ''); ?></textarea></fieldset>
                <fieldset><div class="body-title">Size guide</div><textarea name="product_size_guide" rows="3"><?php echo jd_admin_h($product['size_guide'] ?? ''); ?></textarea></fieldset>
                <fieldset><div class="body-title">Replace product image</div><input type="file" name="product_image" accept="image/jpeg,image/png,image/gif,image/webp"><div class="text-tiny mt-8">Leave empty to retain the current image.</div><img data-product-image id="productImagePreview" class="mt-12" src="<?php echo jd_admin_h(jd_admin_image_url($product['product_link'])); ?>" alt="<?php echo jd_admin_h($product['product_name']); ?>" style="width:120px;height:120px;object-fit:cover;border-radius:10px"></fieldset>
                <div class="bot"><button class="tf-button w208" id="productEditSubmit" type="submit">Save changes</button></div>
            </form>
        </div>
    </div></div><?php include __DIR__ . '/includes/footer.php'; ?></div>
<script>
document.getElementById('productEditForm').addEventListener('submit', async function(event) {
    event.preventDefault(); const form=this, button=document.getElementById('productEditSubmit'), message=document.getElementById('productEditMessage');
    button.disabled=true; try { const response=await fetch('action.php',{method:'POST',body:new FormData(form),credentials:'same-origin'}), data=await response.json(); if(!response.ok||data.status!=='success') throw new Error(data.message||'Unable to update product.'); message.className='alert alert-success'; message.textContent=data.message||'Product updated.'; const preview=document.getElementById('productImagePreview'); if(preview && data.product_image){preview.src=window.jdAdminImageUrl(data.product_image);} form.querySelector('[name=product_image]').value=''; message.style.display='block'; } catch(error) { message.className='alert alert-danger'; message.textContent=error.message; message.style.display='block'; } finally { button.disabled=false; }
});
</script>
