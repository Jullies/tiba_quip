<?php
require_once __DIR__ . '/includes/bootstrap.php';
$counts = [];
$result = mysqli_query($conn, 'SELECT user_level, COUNT(*) AS total FROM webaccounts GROUP BY user_level');
while ($result && ($row = mysqli_fetch_assoc($result))) $counts[$row['user_level']] = (int)$row['total'];
include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidenav.php';
?>
<div class="section-content-right"><?php include __DIR__ . '/includes/topbar.php'; ?>
<div class="main-content"><div class="main-content-inner"><div class="main-content-wrap">
<h3 class="mb-27">Account Roles</h3>
<div class="wg-box"><p>The shop supports two account roles. Assign a role when adding or editing a user.</p>
<table class="table"><thead><tr><th>Role</th><th>Access</th><th>Users</th></tr></thead><tbody>
<tr><td>Administrator</td><td>All administration pages and management actions</td><td><?php echo $counts['admin'] ?? 0; ?></td></tr>
<tr><td>Customer</td><td>Personal shop account, purchases and wishlist</td><td><?php echo $counts['normal'] ?? 0; ?></td></tr>
</tbody></table><a href="all-user.php" class="tf-button">Manage users</a></div>
</div></div><?php include __DIR__ . '/includes/footer.php'; ?>
