<?php
	require_once __DIR__ . '/includes/bootstrap.php';

	$categories = [];
	$categoriesQuery = mysqli_query($conn, "SELECT bc.catg_id, bc.category, bc.last_modified, COUNT(sc.subcatg_id) AS sub_count FROM blog_category bc LEFT JOIN blog_sub_category sc ON sc.catg_id = bc.catg_id GROUP BY bc.catg_id ORDER BY bc.last_modified DESC");
	if($categoriesQuery){
		while($row = mysqli_fetch_assoc($categoriesQuery)){
			$categories[] = $row;
		}
	}

	$subcategories = [];
	$subQuery = mysqli_query(
		$conn,
		"SELECT sc.subcatg_id, sc.sub_category, sc.last_modified, sc.catg_id, bc.category 
		 FROM blog_sub_category sc 
		 INNER JOIN blog_category bc ON bc.catg_id = sc.catg_id 
		 ORDER BY sc.last_modified DESC"
	);
	if($subQuery){
		while($row = mysqli_fetch_assoc($subQuery)){
			$subcategories[] = $row;
		}
	}
?>
<?php include __DIR__ . '/includes/head.php'; ?>
<?php include __DIR__ . '/includes/sidenav.php'; ?>
                <div class="section-content-right">
                    <?php include __DIR__ . '/includes/topbar.php'; ?>
                    <div class="main-content">
                        <div class="main-content-inner">
                            <div class="main-content-wrap blog-category-page">
                                <style>
                                    .blog-category-page .category-summary { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:20px; margin-bottom:28px; }
                                    .blog-category-page .category-summary .wg-box { padding:22px; }
                                    .blog-category-page .summary-label { color:#6b7280; font-size:14px; margin-bottom:8px; }
                                    .blog-category-page .summary-number { color:#111827; font-size:30px; font-weight:700; }
                                    .blog-category-page .category-panel { padding:26px; height:100%; }
                                    .blog-category-page .card { border:0; box-shadow:none; background:transparent; }
                                    .blog-category-page .card-body { padding:0; }
                                    .blog-category-page .form-control, .blog-category-page .form-select { min-height:46px; border:1px solid #e5e7eb; border-radius:8px; }
                                    .blog-category-page .btn-success { background:#1d5eff; border-color:#1d5eff; }
                                    .blog-category-page .btn-outline-primary { color:#1d5eff; border-color:#1d5eff; }
                                    @media (max-width:767px) { .blog-category-page .category-summary { grid-template-columns:1fr; gap:12px; } .blog-category-page .category-panel { padding:18px; } }
                                </style>
                                <div class="flex items-center flex-wrap justify-between gap20 mb-27">
                                    <div><h3>Post Categories</h3><div class="text-tiny mt-8">Organize every blog post with clear parent categories and subcategories.</div></div>
                                    <ul class="breadcrumbs flex items-center flex-wrap justify-start gap10"><li><a href="index.php"><div class="text-tiny">Dashboard</div></a></li><li><i class="icon-chevron-right"></i></li><li><a href="blogs.php"><div class="text-tiny">Blogs</div></a></li><li><i class="icon-chevron-right"></i></li><li><div class="text-tiny">Post Categories</div></li></ul>
                                </div>
                                <div class="category-summary">
                                    <div class="wg-box"><div class="summary-label">Blog categories</div><div class="summary-number"><?php echo count($categories); ?></div></div>
                                    <div class="wg-box"><div class="summary-label">Blog subcategories</div><div class="summary-number"><?php echo count($subcategories); ?></div></div>
                                </div>

			<div class="row g-4">
				<div class="col-lg-5">
					<div class="wg-box category-panel mb-4">
						<div class="card-body">
							<h5 class="card-title" id="categoryFormTitle">Add Category</h5>
							<div id="categoryMessage" class="alert d-none" role="alert"></div>
							<form class="row g-3" id="categoryForm">
								<input type="hidden" name="category_id" id="categoryIdInput">
								<div class="col-12">
									<label class="form-label">Category name</label>
									<input type="text" class="form-control" name="category_name" placeholder="e.g. Soil Diagnostics" required>
								</div>
								<div class="col-12 d-flex gap-2">
									<button class="btn btn-success" type="submit"><i class="fa fa-plus me-1"></i>Add Category</button>
									<button class="btn btn-outline-secondary" type="reset">Clear</button>
								</div>
							</form>
						</div>
					</div>
					<div class="wg-box category-panel">
						<div class="card-body">
							<h5 class="card-title" id="subcategoryFormTitle">Add Subcategory</h5>
							<div id="subcategoryMessage" class="alert d-none" role="alert"></div>
							<form class="row g-3" id="subcategoryForm">
								<input type="hidden" name="subcategory_id" id="subcategoryIdInput">
								<div class="col-12">
									<label class="form-label">Parent Category</label>
									<select class="form-select" name="parent_category" required>
										<option value="">Select category</option>
										<?php foreach ($categories as $category): ?>
											<option value="<?php echo (int)$category['catg_id']; ?>"><?php echo htmlspecialchars($category['category']); ?></option>
										<?php endforeach; ?>
									</select>
								</div>
								<div class="col-12">
									<label class="form-label">Subcategory name</label>
									<input type="text" class="form-control" name="subcategory_name" placeholder="e.g. Soil Sampling" required>
								</div>
								<div class="col-12 d-flex gap-2">
									<button class="btn btn-outline-primary" type="submit"><i class="fa fa-plus me-1"></i>Add Subcategory</button>
									<button class="btn btn-outline-secondary" type="reset">Clear</button>
								</div>
							</form>
						</div>
					</div>
				</div>

				<div class="col-lg-7">
					<div class="wg-box category-panel">
						<div class="card-body">
							<h5 class="card-title mb-3">Categories</h5>
							<div class="table-responsive">
								<table class="table align-middle">
									<thead class="table-light">
										<tr>
											<th>Name</th>
											<th>Subcategories</th>
											<th>Last Updated</th>
											<th></th>
										</tr>
									</thead>
									<tbody>
										<?php if(empty($categories)): ?>
											<tr>
												<td colspan="4" class="text-center text-muted py-4">No categories yet. Create your first one.</td>
											</tr>
										<?php else: ?>
											<?php foreach ($categories as $category): ?>
												<tr>
													<td><?php echo htmlspecialchars($category['category']); ?></td>
													<td><?php echo (int)$category['sub_count']; ?></td>
													<td><?php echo $category['last_modified'] ? date('M d, Y H:i', strtotime($category['last_modified'])) : '—'; ?></td>
													<td class="text-end">
														<button
															type="button"
															class="btn btn-sm btn-outline-primary edit-category"
															data-category-id="<?php echo (int)$category['catg_id']; ?>"
															data-category-name="<?php echo htmlspecialchars($category['category'], ENT_QUOTES, 'UTF-8'); ?>"
														>
															<i class="fa fa-pen me-1"></i>Edit
														</button>
													</td>
												</tr>
											<?php endforeach; ?>
										<?php endif; ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
					<div class="wg-box category-panel mt-4">
						<div class="card-body">
							<h5 class="card-title mb-3">Subcategories</h5>
							<div class="table-responsive">
								<table class="table align-middle">
									<thead class="table-light">
										<tr>
											<th>Name</th>
											<th>Parent Category</th>
											<th>Last Updated</th>
											<th></th>
										</tr>
									</thead>
									<tbody>
										<?php if(empty($subcategories)): ?>
											<tr>
												<td colspan="4" class="text-center text-muted py-4">No subcategories yet.</td>
											</tr>
										<?php else: ?>
											<?php foreach ($subcategories as $subcategory): ?>
												<tr>
													<td><?php echo htmlspecialchars($subcategory['sub_category']); ?></td>
													<td><?php echo htmlspecialchars($subcategory['category']); ?></td>
													<td><?php echo $subcategory['last_modified'] ? date('M d, Y H:i', strtotime($subcategory['last_modified'])) : '—'; ?></td>
													<td class="text-end">
														<button
															type="button"
															class="btn btn-sm btn-outline-primary edit-subcategory"
															data-subcategory-id="<?php echo (int)$subcategory['subcatg_id']; ?>"
															data-subcategory-name="<?php echo htmlspecialchars($subcategory['sub_category'], ENT_QUOTES, 'UTF-8'); ?>"
															data-category-id="<?php echo (int)$subcategory['catg_id']; ?>"
														>
															<i class="fa fa-pen me-1"></i>Edit
														</button>
													</td>
												</tr>
											<?php endforeach; ?>
										<?php endif; ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
			</div>

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
	<script>
		const categoryForm = document.getElementById('categoryForm');
		const subcategoryForm = document.getElementById('subcategoryForm');
		const categoryMessage = document.getElementById('categoryMessage');
		const subcategoryMessage = document.getElementById('subcategoryMessage');
		const categoryIdInput = document.getElementById('categoryIdInput');
		const subcategoryIdInput = document.getElementById('subcategoryIdInput');
		const categoryFormTitle = document.getElementById('categoryFormTitle');
		const subcategoryFormTitle = document.getElementById('subcategoryFormTitle');
		const categorySubmitBtn = categoryForm ? categoryForm.querySelector('button[type="submit"]') : null;
		const subcategorySubmitBtn = subcategoryForm ? subcategoryForm.querySelector('button[type="submit"]') : null;
		const defaultCategoryBtnHtml = categorySubmitBtn ? categorySubmitBtn.innerHTML : '';
		const defaultSubcategoryBtnHtml = subcategorySubmitBtn ? subcategorySubmitBtn.innerHTML : '';

		function showMessage(el, type, text){
			if(!el) return;
			el.textContent = text;
			el.classList.remove('d-none', 'alert-success', 'alert-danger');
			el.classList.add(type === 'success' ? 'alert-success' : 'alert-danger');
		}

		function resetMessage(el){
			if(!el) return;
			el.classList.add('d-none');
			el.textContent = '';
		}

		function sendAdminRequest(key, payload, messageEl, button){
			fetch('action.php', {
				method: 'POST',
				headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'},
				body: new URLSearchParams({ csrf_token: document.querySelector('meta[name="csrf-token"]')?.content || '', [key]: JSON.stringify(payload) })
			})
				.then(res => res.json())
				.then(data => {
					showMessage(messageEl, data.status === 'success' ? 'success' : 'error', data.message || '');
					if(data.status === 'success'){
						setTimeout(() => window.location.reload(), 900);
					}
				})
				.catch(() => {
					showMessage(messageEl, 'error', 'Something went wrong. Please try again.');
				})
				.finally(() => {
					if(button){ button.disabled = false; }
				});
		}

		function resetCategoryFormState(){
			if(!categoryForm) return;
			categoryForm.reset();
			if(categoryIdInput){ categoryIdInput.value = ''; }
			if(categoryFormTitle){ categoryFormTitle.textContent = 'Add Category'; }
			if(categorySubmitBtn && defaultCategoryBtnHtml){ categorySubmitBtn.innerHTML = defaultCategoryBtnHtml; }
			resetMessage(categoryMessage);
		}

		function resetSubcategoryFormState(){
			if(!subcategoryForm) return;
			subcategoryForm.reset();
			if(subcategoryIdInput){ subcategoryIdInput.value = ''; }
			if(subcategoryFormTitle){ subcategoryFormTitle.textContent = 'Add Subcategory'; }
			if(subcategorySubmitBtn && defaultSubcategoryBtnHtml){ subcategorySubmitBtn.innerHTML = defaultSubcategoryBtnHtml; }
			resetMessage(subcategoryMessage);
		}

		function startCategoryEdit(data){
			if(!categoryForm || !data){ return; }
			if(categoryIdInput){ categoryIdInput.value = data.id || ''; }
			categoryForm.category_name.value = data.name || '';
			if(categoryFormTitle){ categoryFormTitle.textContent = 'Edit Category'; }
			if(categorySubmitBtn){ categorySubmitBtn.innerHTML = '<i class="fa fa-save me-1"></i>Update Category'; }
			resetMessage(categoryMessage);
			categoryForm.scrollIntoView({ behavior: 'smooth', block: 'start' });
		}

		function startSubcategoryEdit(data){
			if(!subcategoryForm || !data){ return; }
			if(subcategoryIdInput){ subcategoryIdInput.value = data.id || ''; }
			if(subcategoryForm.subcategory_name){ subcategoryForm.subcategory_name.value = data.name || ''; }
			if(subcategoryForm.parent_category){
				const value = data.category_id ? String(data.category_id) : '';
				subcategoryForm.parent_category.value = value;
			}
			if(subcategoryFormTitle){ subcategoryFormTitle.textContent = 'Edit Subcategory'; }
			if(subcategorySubmitBtn){ subcategorySubmitBtn.innerHTML = '<i class="fa fa-save me-1"></i>Update Subcategory'; }
			resetMessage(subcategoryMessage);
			subcategoryForm.scrollIntoView({ behavior: 'smooth', block: 'start' });
		}

		if(categoryForm){
			categoryForm.addEventListener('reset', () => setTimeout(resetCategoryFormState, 0));
		}

		if(subcategoryForm){
			subcategoryForm.addEventListener('reset', () => setTimeout(resetSubcategoryFormState, 0));
		}

		if(categoryForm){
			categoryForm.addEventListener('submit', function(e){
				e.preventDefault();
				const name = this.category_name.value.trim();
				if(!name){
					showMessage(categoryMessage, 'error', 'Please enter a category name.');
					return;
				}
				const submitBtn = this.querySelector('button[type="submit"]');
				submitBtn.disabled = true;
				const payload = { category: name };
				let actionKey = 'add_blog_category';
				if(categoryIdInput && categoryIdInput.value){
					payload.category_id = parseInt(categoryIdInput.value, 10);
					actionKey = 'update_blog_category';
				}
				sendAdminRequest(actionKey, payload, categoryMessage, submitBtn);
			});
		}

		if(subcategoryForm){
			subcategoryForm.addEventListener('submit', function(e){
				e.preventDefault();
				const categoryId = this.parent_category.value;
				const subName = this.subcategory_name.value.trim();
				if(!categoryId || !subName){
					showMessage(subcategoryMessage, 'error', 'Select a category and provide a subcategory name.');
					return;
				}
				const submitBtn = this.querySelector('button[type="submit"]');
				submitBtn.disabled = true;
				const payload = { category_id: parseInt(categoryId, 10), sub_category: subName };
				let actionKey = 'add_blog_subcategory';
				if(subcategoryIdInput && subcategoryIdInput.value){
					payload.subcategory_id = parseInt(subcategoryIdInput.value, 10);
					actionKey = 'update_blog_subcategory';
				}
				sendAdminRequest(actionKey, payload, subcategoryMessage, submitBtn);
			});
		}

		document.addEventListener('click', function(event){
			const editCategoryBtn = event.target.closest('.edit-category');
			if(editCategoryBtn){
				const id = parseInt(editCategoryBtn.dataset.categoryId, 10);
				const name = editCategoryBtn.dataset.categoryName || '';
				if(id){
					startCategoryEdit({ id, name });
				}
				return;
			}
			const editSubcategoryBtn = event.target.closest('.edit-subcategory');
			if(editSubcategoryBtn){
				const id = parseInt(editSubcategoryBtn.dataset.subcategoryId, 10);
				const name = editSubcategoryBtn.dataset.subcategoryName || '';
				const categoryId = parseInt(editSubcategoryBtn.dataset.categoryId, 10) || '';
				if(id){
					startSubcategoryEdit({ id, name, category_id: categoryId });
				}
			}
		});
	</script>
							</div>
						</div>
						<?php include __DIR__ . '/includes/footer.php'; ?>
