<?php
require_once __DIR__ . '/includes/bootstrap.php';

$parentCategories = [];
$parentQuery = mysqli_query($conn, "SELECT product_catg_id, product_category FROM my_shop_categories ORDER BY product_category ASC");
if ($parentQuery) {
    while ($row = mysqli_fetch_assoc($parentQuery)) {
        $parentCategories[] = $row;
    }
}

$searchTerm = trim((string)($_GET['q'] ?? ''));
$perPage = (int)($_GET['per_page'] ?? 10);
if (!in_array($perPage, [10, 20, 30], true)) { $perPage = 10; }
$currentPage = max(1, (int)($_GET['page'] ?? 1));
$whereClause = '';
if ($searchTerm !== '') {
    $searchEsc = mysqli_real_escape_string($conn, $searchTerm);
    $whereClause = " WHERE sc.product_sub_category LIKE '%{$searchEsc}%' OR c.product_category LIKE '%{$searchEsc}%' OR CAST(sc.product_sub_catg_id AS CHAR) LIKE '%{$searchEsc}%'";
}
$totalSubcategories = 0;
$countQuery = mysqli_query($conn, "SELECT COUNT(*) AS total FROM my_shop_sub_categories sc LEFT JOIN my_shop_categories c ON c.product_catg_id = sc.product_catg_id{$whereClause}");
if ($countQuery && ($countRow = mysqli_fetch_assoc($countQuery))) { $totalSubcategories = (int)($countRow['total'] ?? 0); }
$totalPages = max(1, (int)ceil($totalSubcategories / $perPage));
$currentPage = min($currentPage, $totalPages);
$offset = ($currentPage - 1) * $perPage;

$subcategories = [];
$subQuery = mysqli_query($conn, "
    SELECT sc.product_sub_catg_id, sc.product_catg_id, sc.product_sub_category, sc.last_modified,
           COALESCE(c.product_category, 'Unassigned') AS product_category,
           COUNT(p.product_id) AS product_count
    FROM my_shop_sub_categories sc
    LEFT JOIN my_shop_categories c ON c.product_catg_id = sc.product_catg_id
    LEFT JOIN my_shop_products p ON p.product_sub_catg_id = sc.product_sub_catg_id
    {$whereClause}
    GROUP BY sc.product_sub_catg_id, sc.product_catg_id, sc.product_sub_category, sc.last_modified, c.product_category
    ORDER BY c.product_category ASC, sc.product_sub_category ASC
    LIMIT {$perPage} OFFSET {$offset}
");
if ($subQuery) { while ($row = mysqli_fetch_assoc($subQuery)) { $subcategories[] = $row; } }
?>
<?php include __DIR__ . '/includes/head.php'; ?>
<?php include __DIR__ . '/includes/sidenav.php'; ?>
<div class="section-content-right">
    <?php include __DIR__ . '/includes/topbar.php'; ?>
    <div class="main-content"><div class="main-content-inner"><div class="main-content-wrap">
        <div class="flex items-center flex-wrap justify-between gap20 mb-27">
            <h3>Subcategories</h3>
            <ul class="breadcrumbs flex items-center flex-wrap justify-start gap10"><li><a href="index.php"><div class="text-tiny">Dashboard</div></a></li><li><i class="icon-chevron-right"></i></li><li><div class="text-tiny">Category</div></li><li><i class="icon-chevron-right"></i></li><li><div class="text-tiny">Subcategories</div></li></ul>
        </div>
        <div class="wg-box">
            <div class="flex items-center justify-between gap10 flex-wrap">
                <div class="wg-filter flex-grow">
                    <form class="show" method="get" action="subcategory-list.php">
                        <?php if ($searchTerm !== ''): ?><input type="hidden" name="q" value="<?php echo jd_admin_h($searchTerm); ?>"><?php endif; ?>
                        <div class="text-tiny">Showing</div><div class="select"><select name="per_page" onchange="this.form.submit()"><option value="10" <?php echo $perPage === 10 ? 'selected' : ''; ?>>10</option><option value="20" <?php echo $perPage === 20 ? 'selected' : ''; ?>>20</option><option value="30" <?php echo $perPage === 30 ? 'selected' : ''; ?>>30</option></select></div><div class="text-tiny">entries</div>
                    </form>
                    <form class="form-search" method="get" action="subcategory-list.php"><input type="hidden" name="per_page" value="<?php echo $perPage; ?>"><fieldset class="name"><input type="text" name="q" value="<?php echo jd_admin_h($searchTerm); ?>" placeholder="Search subcategories..." tabindex="2"></fieldset><div class="button-submit"><button type="submit"><i class="icon-search"></i></button></div></form>
                </div>
                <button type="button" class="tf-button style-1 w208" id="openSubcategoryModal"><i class="icon-plus"></i>Add new</button>
            </div>
            <div class="wg-table table-all-category">
                <ul class="table-title flex gap20 mb-14"><li><div class="body-title">Subcategory</div></li><li><div class="body-title">Parent category</div></li><li><div class="body-title">Products</div></li><li><div class="body-title">Updated</div></li><li><div class="body-title">Action</div></li></ul>
                <ul class="flex flex-column">
                    <?php if (empty($subcategories)): ?>
                    <li class="product-item gap14"><div class="flex items-center justify-center flex-grow"><div class="body-text">No subcategories found.</div></div></li>
                    <?php else: foreach ($subcategories as $subcategory): ?>
                    <li class="product-item gap14"><div class="image no-bg"><i class="icon-layers"></i></div><div class="flex items-center justify-between gap20 flex-grow">
                        <div class="name"><a href="product-list.php" class="body-title-2"><?php echo jd_admin_h($subcategory['product_sub_category']); ?></a></div>
                        <div class="body-text"><?php echo jd_admin_h($subcategory['product_category']); ?></div>
                        <div class="body-text"><?php echo number_format((int)$subcategory['product_count']); ?></div>
                        <div class="body-text"><?php echo !empty($subcategory['last_modified']) ? date('d M Y', strtotime($subcategory['last_modified'])) : '-'; ?></div>
                        <div class="list-icon-function"><button type="button" class="item edit admin-edit-subcategory" data-id="<?php echo (int)$subcategory['product_sub_catg_id']; ?>" data-parent="<?php echo (int)$subcategory['product_catg_id']; ?>" data-name="<?php echo jd_admin_h($subcategory['product_sub_category']); ?>" style="border:0"><i class="icon-edit-3"></i></button><button type="button" class="item trash admin-delete-subcategory" data-id="<?php echo (int)$subcategory['product_sub_catg_id']; ?>" data-name="<?php echo jd_admin_h($subcategory['product_sub_category']); ?>" style="border:0"><i class="icon-trash-2"></i></button></div>
                    </div></li>
                    <?php endforeach; endif; ?>
                </ul>
            </div>
            <div class="divider"></div><div class="flex items-center justify-between flex-wrap gap10"><div class="text-tiny">Showing <?php echo count($subcategories); ?> of <?php echo $totalSubcategories; ?> entries</div><ul class="wg-pagination"><li><a href="?<?php echo http_build_query(['q'=>$searchTerm,'per_page'=>$perPage,'page'=>max(1,$currentPage-1)]); ?>"><i class="icon-chevron-left"></i></a></li><?php for($page=max(1,$currentPage-2);$page<=min($totalPages,$currentPage+2);$page++): ?><li<?php echo $page===$currentPage?' class="active"':''; ?>><a href="?<?php echo http_build_query(['q'=>$searchTerm,'per_page'=>$perPage,'page'=>$page]); ?>"><?php echo $page; ?></a></li><?php endfor; ?><li><a href="?<?php echo http_build_query(['q'=>$searchTerm,'per_page'=>$perPage,'page'=>min($totalPages,$currentPage+1)]); ?>"><i class="icon-chevron-right"></i></a></li></ul></div>
        </div>
        <div class="modal fade" id="subcategoryManagerModal" tabindex="-1" aria-hidden="true"><div class="modal-dialog modal-dialog-centered"><div class="modal-content"><form id="subcategoryManagerForm"><div class="modal-header"><h5 class="modal-title" id="subcategoryModalTitle">Add subcategory</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><input type="hidden" id="subcategoryManagerId"><div id="subcategoryManagerMessage" class="alert" style="display:none"></div><div class="mb-3"><label class="body-title" for="subcategoryManagerParent">Parent category <span class="tf-color-1">*</span></label><select class="form-select" id="subcategoryManagerParent" required><option value="">Select parent category</option><?php foreach($parentCategories as $category): ?><option value="<?php echo (int)$category['product_catg_id']; ?>"><?php echo jd_admin_h($category['product_category']); ?></option><?php endforeach; ?></select></div><div><label class="body-title" for="subcategoryManagerName">Subcategory name <span class="tf-color-1">*</span></label><input class="form-control" id="subcategoryManagerName" required></div></div><div class="modal-footer"><button type="button" class="tf-button style-3" data-bs-dismiss="modal">Cancel</button><button type="submit" class="tf-button" id="subcategoryManagerSubmit">Save subcategory</button></div></form></div></div></div>
    </div></div>
    <script>
    document.addEventListener('DOMContentLoaded',function(){
        const modal=bootstrap.Modal.getOrCreateInstance(document.getElementById('subcategoryManagerModal')),form=document.getElementById('subcategoryManagerForm'),id=document.getElementById('subcategoryManagerId'),parent=document.getElementById('subcategoryManagerParent'),name=document.getElementById('subcategoryManagerName'),title=document.getElementById('subcategoryModalTitle'),submit=document.getElementById('subcategoryManagerSubmit'),message=document.getElementById('subcategoryManagerMessage');
        const notify=(text,type)=>{message.className='alert alert-'+type;message.textContent=text;message.style.display='block';};
        const open=(record)=>{form.reset();message.style.display='none';id.value=record?record.id:'';parent.value=record?record.parent:'';name.value=record?record.name:'';title.textContent=record?'Edit subcategory':'Add subcategory';submit.textContent=record?'Save changes':'Save subcategory';modal.show();};
        document.getElementById('openSubcategoryModal').addEventListener('click',()=>open(null));
        document.addEventListener('click',async function(event){const edit=event.target.closest('.admin-edit-subcategory');if(edit){open({id:edit.dataset.id,parent:edit.dataset.parent,name:edit.dataset.name});return;}const remove=event.target.closest('.admin-delete-subcategory');if(!remove||!confirm('Delete subcategory "'+remove.dataset.name+'"? Products must be reassigned first.'))return;const payload=new FormData();payload.append('csrf_token',document.querySelector('meta[name="csrf-token"]').content);payload.append('delete_shop_sub_category',JSON.stringify({subcategory_id:Number(remove.dataset.id)}));try{const response=await fetch('action.php',{method:'POST',body:payload,credentials:'same-origin'}),data=await response.json();if(!response.ok||data.status!=='success')throw new Error(data.message||'Unable to delete subcategory.');location.reload();}catch(error){alert(error.message);}});
        form.addEventListener('submit',async function(event){event.preventDefault();const editing=Number(id.value)>0,payload=new FormData();payload.append('csrf_token',document.querySelector('meta[name="csrf-token"]').content);payload.append(editing?'update_shop_sub_category':'add_shop_sub_category',JSON.stringify(editing?{subcategory_id:Number(id.value),product_catg_id:Number(parent.value),product_sub_category:name.value.trim()}:{product_catg_id:Number(parent.value),product_sub_category:name.value.trim()}));submit.disabled=true;try{const response=await fetch('action.php',{method:'POST',body:payload,credentials:'same-origin'}),data=await response.json();if(!response.ok||data.status!=='success')throw new Error(data.message||'Unable to save subcategory.');location.reload();}catch(error){notify(error.message,'danger');}finally{submit.disabled=false;}});
    });
    </script>
    <?php include __DIR__ . '/includes/footer.php'; ?>
</div>
