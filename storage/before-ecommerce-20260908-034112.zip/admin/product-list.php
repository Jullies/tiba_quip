<?php
require_once __DIR__ . '/includes/bootstrap.php';

$products = [];
$searchTerm = trim((string)($_GET['q'] ?? ''));
$categoryId = max(0, (int)($_GET['category_id'] ?? 0));
$perPage = (int)($_GET['per_page'] ?? 10);
if (!in_array($perPage, [10, 20, 30], true)) {
    $perPage = 10;
}
$currentPage = max(1, (int)($_GET['page'] ?? 1));
$filters = [];
if ($searchTerm !== '') {
    $searchEsc = mysqli_real_escape_string($conn, $searchTerm);
    $filters[] = "(p.product_name LIKE '%{$searchEsc}%' OR CAST(p.product_id AS CHAR) LIKE '%{$searchEsc}%')";
}
if ($categoryId > 0) {
    $filters[] = "sc.product_catg_id = {$categoryId}";
}
$whereClause = $filters ? ' WHERE ' . implode(' AND ', $filters) : '';
$totalProducts = 0;
$totalQuery = mysqli_query($conn, "SELECT COUNT(*) AS total FROM my_shop_products p LEFT JOIN my_shop_sub_categories sc ON sc.product_sub_catg_id = p.product_sub_catg_id{$whereClause}");
if ($totalQuery) {
    $totalRow = mysqli_fetch_assoc($totalQuery);
    $totalProducts = (int)($totalRow['total'] ?? 0);
}
$totalPages = max(1, (int)ceil($totalProducts / $perPage));
if ($currentPage > $totalPages) {
    $currentPage = $totalPages;
}
$offset = ($currentPage - 1) * $perPage;
$productSql = "
    SELECT p.product_id, p.product_name, p.product_link, p.selling_price, p.was_selling_price, p.last_modified,
           COALESCE(st.stock_qty, 0) AS stock_qty,
           COALESCE(progress.ordered_qty, 0) AS ordered_qty,
           COALESCE(progress.cancelled_qty, 0) AS cancelled_qty,
           COALESCE(progress.shipping_qty, 0) AS shipping_qty,
           COALESCE(progress.completed_qty, 0) AS completed_qty
    FROM my_shop_products p
    LEFT JOIN my_shop_sub_categories sc ON sc.product_sub_catg_id = p.product_sub_catg_id
    LEFT JOIN (
        SELECT product_id, SUM(stock_qty) AS stock_qty
        FROM my_shop_stock
        GROUP BY product_id
    ) st ON st.product_id = p.product_id
    LEFT JOIN (
        SELECT oi.item_ref_id AS product_id,
               SUM(CASE WHEN so.order_status = 'pending' THEN oi.quantity ELSE 0 END) AS ordered_qty,
               SUM(CASE WHEN so.order_status = 'cancelled' THEN oi.quantity ELSE 0 END) AS cancelled_qty,
               SUM(CASE WHEN so.order_status = 'shipping' THEN oi.quantity ELSE 0 END) AS shipping_qty,
               SUM(CASE WHEN so.order_status = 'fulfilled' THEN oi.quantity ELSE 0 END) AS completed_qty
        FROM shop_order_items oi
        INNER JOIN shop_orders so ON so.order_id = oi.order_id
        WHERE oi.item_type = 'product'
        GROUP BY oi.item_ref_id
    ) progress ON progress.product_id = p.product_id
    {$whereClause}
    ORDER BY p.last_modified DESC
    LIMIT {$perPage} OFFSET {$offset}
";
$productQuery = mysqli_query($conn, $productSql);
if($productQuery){
    while($row = mysqli_fetch_assoc($productQuery)){
        $products[] = $row;
    }
}

$shopCategories = [];
$subCategoriesByCategory = [];
$categoryQuery = mysqli_query($conn, "SELECT product_catg_id, product_category FROM my_shop_categories ORDER BY product_category ASC");
if ($categoryQuery) {
    while ($row = mysqli_fetch_assoc($categoryQuery)) {
        $shopCategories[] = $row;
    }
}
$subcategoryQuery = mysqli_query($conn, "SELECT product_sub_catg_id, product_catg_id, product_sub_category FROM my_shop_sub_categories ORDER BY product_sub_category ASC");
if ($subcategoryQuery) {
    while ($row = mysqli_fetch_assoc($subcategoryQuery)) {
        $parentId = (int)($row['product_catg_id'] ?? 0);
        $subCategoriesByCategory[$parentId][] = $row;
    }
}
?>

<?php include __DIR__ . '/includes/head.php'; ?>

<?php include __DIR__ . '/includes/sidenav.php'; ?>
                <!-- section-content-right -->
                <div class="section-content-right">
                    <?php include __DIR__ . '/includes/topbar.php'; ?>
                    <!-- main-content -->
                    <div class="main-content">
                        <!-- main-content-wrap -->
                        <div class="main-content-inner">
                            <!-- main-content-wrap -->
                            <div class="main-content-wrap">
                                <div class="flex items-center flex-wrap justify-between gap20 mb-27">
                                    <h3>Product List</h3>
                                    <ul class="breadcrumbs flex items-center flex-wrap justify-start gap10">
                                        <li>
                                            <a href="index.php"><div class="text-tiny">Dashboard</div></a>
                                        </li>
                                        <li>
                                            <i class="icon-chevron-right"></i>
                                        </li>
                                        <li>
                                            <a href="#"><div class="text-tiny">Ecommerce</div></a>
                                        </li>
                                        <li>
                                            <i class="icon-chevron-right"></i>
                                        </li>
                                        <li>
                                            <div class="text-tiny">Product List</div>
                                        </li>
                                    </ul>
                                </div>
                                <!-- product-list -->
                                <div class="wg-box">
                                    <div class="title-box">
                                        <i class="icon-coffee"></i>
                                        <div class="body-text">Tip search by Product ID: Each product is provided with a unique ID, which you can rely on to find the exact product you need.</div>
                                    </div>
                                    <div class="flex items-center justify-between gap10 flex-wrap">
                                        <div class="wg-filter flex-grow">
                                            <form class="show" method="get" action="product-list.php">
                                                <?php if ($searchTerm !== ''): ?><input type="hidden" name="q" value="<?php echo jd_admin_h($searchTerm); ?>"><?php endif; ?>
                                                <?php if ($categoryId > 0): ?><input type="hidden" name="category_id" value="<?php echo $categoryId; ?>"><?php endif; ?>
                                                <div class="text-tiny">Showing</div>
                                                <div class="select">
                                                    <select name="per_page" onchange="this.form.submit()">
                                                        <option value="10" <?php echo $perPage === 10 ? 'selected' : ''; ?>>10</option>
                                                        <option value="20" <?php echo $perPage === 20 ? 'selected' : ''; ?>>20</option>
                                                        <option value="30" <?php echo $perPage === 30 ? 'selected' : ''; ?>>30</option>
                                                    </select>
                                                </div>
                                                <div class="text-tiny">entries</div>
                                            </form>
                                            <form class="form-search" method="get" action="product-list.php">
                                                <input type="hidden" name="per_page" value="<?php echo $perPage; ?>">
                                                <?php if ($categoryId > 0): ?><input type="hidden" name="category_id" value="<?php echo $categoryId; ?>"><?php endif; ?>
                                                <fieldset class="name">
                                                    <input type="text" placeholder="Search by product name or ID..." class="" name="q" tabindex="2" value="<?php echo jd_admin_h($searchTerm); ?>">
                                                </fieldset>
                                                <div class="button-submit">
                                                    <button class="" type="submit"><i class="icon-search"></i></button>
                                                </div>
                                            </form>
                                        </div>
                                        <button type="button" class="tf-button style-1 w208" id="openProductModal"><i class="icon-plus"></i>Add new</button>
                                    </div>
                                    <div class="wg-table table-product-list">
                                        <ul class="table-title flex gap20 mb-14">
                                            <li>
                                                <div class="body-title">Product</div>
                                            </li>    
                                            <li>
                                                <div class="body-title">Price</div>
                                            </li>
                                            <li>
                                                <div class="body-title">Quantity</div>
                                            </li>
                                            <li>
                                                <div class="body-title">Order progress</div>
                                            </li>
                                            <li>
                                                <div class="body-title">Discount</div>
                                            </li>
                                            <li>
                                                <div class="body-title">Stock</div>
                                            </li>
                                            <li>
                                                <div class="body-title">Action</div>
                                            </li>
                                        </ul>
                                        <ul class="flex flex-column">
                                            <?php if(empty($products)): ?>
                                            <li class="product-item gap14">
                                                <div class="flex items-center justify-center flex-grow">
                                                    <div class="body-text">No products found.</div>
                                                </div>
                                            </li>
                                            <?php else: ?>
                                            <?php foreach($products as $product): ?>
                                            <?php
                                                $productId = (int)($product['product_id'] ?? 0);
                                                $productName = htmlspecialchars((string)($product['product_name'] ?? 'Untitled product'), ENT_QUOTES, 'UTF-8');
                                                $price = (float)($product['selling_price'] ?? 0);
                                                $wasPrice = isset($product['was_selling_price']) && $product['was_selling_price'] !== null ? (float)$product['was_selling_price'] : null;
                                                $stockQty = (float)($product['stock_qty'] ?? 0);
                                                $orderedQty = (float)($product['ordered_qty'] ?? 0);
                                                $cancelledQty = (float)($product['cancelled_qty'] ?? 0);
                                                $shippingQty = (float)($product['shipping_qty'] ?? 0);
                                                $completedQty = (float)($product['completed_qty'] ?? 0);
                                                $salePercent = 0;
                                                if($wasPrice && $wasPrice > 0 && $wasPrice > $price){
                                                    $salePercent = round((($wasPrice - $price) / $wasPrice) * 100);
                                                }
                                                $stockLabelClass = $stockQty > 0 ? 'block-available' : 'block-not-available';
                                                $stockLabelText = $stockQty > 0 ? 'In stock' : 'Out of stock';
                                            ?>
                                            <li class="product-item gap14">
                                                <div class="image no-bg">
                                                    <?php if (!empty($product['product_link'])): ?><img data-product-image src="<?php echo jd_admin_h(jd_admin_image_url($product['product_link'])); ?>" alt="<?php echo $productName; ?>"><?php else: ?><i class="icon-image"></i><?php endif; ?>
                                                </div>
                                                <div class="flex items-center justify-between gap20 flex-grow">
                                                    <div class="name">
                                                        <a href="product-edit.php?id=<?php echo $productId; ?>" class="body-title-2"><?php echo $productName; ?></a>
                                                    </div>
                                                    <div class="body-text">KSh <?php echo number_format($price, 2); ?></div>
                                                    <div class="body-text"><?php echo number_format($stockQty, 0); ?></div>
                                                    <div class="jd-product-order-progress" aria-label="Order progress">
                                                        <span class="is-ordered">Ordered <?php echo number_format($orderedQty, 0); ?></span>
                                                        <span class="is-cancelled">Cancelled <?php echo number_format($cancelledQty, 0); ?></span>
                                                        <span class="is-shipping">Shipping <?php echo number_format($shippingQty, 0); ?></span>
                                                        <span class="is-completed">Completed <?php echo number_format($completedQty, 0); ?></span>
                                                    </div>
                                                    <div class="body-text"><?php echo $salePercent > 0 ? $salePercent . '%' : '—'; ?></div>
                                                    <div>
                                                        <div class="<?php echo $stockLabelClass; ?>"><?php echo $stockLabelText; ?></div>
                                                    </div>
                                                    <div class="list-icon-function">
                                                        <a class="item eye" href="product-edit.php?id=<?php echo $productId; ?>">
                                                            <i class="icon-eye"></i>
                                                        </a>
                                                        <a class="item edit" href="product-edit.php?id=<?php echo $productId; ?>">
                                                            <i class="icon-edit-3"></i>
                                                        </a>
                                                        <button type="button" class="item trash admin-delete-product" data-product-id="<?php echo $productId; ?>" data-product-name="<?php echo $productName; ?>" style="border:0">
                                                            <i class="icon-trash-2"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </li>
                                            <?php endforeach; ?>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                    <style>
                                        .wg-table.table-product-list > *{min-width:1320px}.wg-table.table-product-list ul.table-title li:nth-child(3),.wg-table.table-product-list ul.table-title li:nth-child(5){width:90px;flex-shrink:0}.wg-table.table-product-list ul.table-title li:nth-child(4){width:185px;flex-shrink:0}.wg-table.table-product-list .product-item>.flex>div:nth-child(3),.wg-table.table-product-list .product-item>.flex>div:nth-child(5){width:90px;flex-shrink:0}.wg-table.table-product-list .product-item>.flex>div:nth-child(4){width:185px;flex-shrink:0}.jd-product-order-progress{display:flex;flex-direction:column;gap:3px;font-size:10px;font-weight:700;line-height:1.15;white-space:nowrap}.jd-product-order-progress span{display:block}.jd-product-order-progress .is-ordered{color:#a16207}.jd-product-order-progress .is-cancelled{color:#dc2626}.jd-product-order-progress .is-shipping{color:#2563eb}.jd-product-order-progress .is-completed{color:#15803d}
                                    </style>
                                    <div class="divider"></div>
                                    <div class="flex items-center justify-between flex-wrap gap10">
                                        <div class="text-tiny">Showing <?php echo count($products); ?> of <?php echo $totalProducts; ?> entries</div>
                                        <ul class="wg-pagination">
                                            <li>
                                                <a href="?<?php echo http_build_query(['q' => $searchTerm, 'category_id' => $categoryId, 'per_page' => $perPage, 'page' => max(1, $currentPage - 1)]); ?>"><i class="icon-chevron-left"></i></a>
                                            </li>
                                            <?php for ($pageNumber = max(1, $currentPage - 2); $pageNumber <= min($totalPages, $currentPage + 2); $pageNumber++): ?>
                                            <li<?php echo $pageNumber === $currentPage ? ' class="active"' : ''; ?>>
                                                <a href="?<?php echo http_build_query(['q' => $searchTerm, 'category_id' => $categoryId, 'per_page' => $perPage, 'page' => $pageNumber]); ?>"><?php echo $pageNumber; ?></a>
                                            </li>
                                            <?php endfor; ?>
                                            <li>
                                                <a href="?<?php echo http_build_query(['q' => $searchTerm, 'category_id' => $categoryId, 'per_page' => $perPage, 'page' => min($totalPages, $currentPage + 1)]); ?>"><i class="icon-chevron-right"></i></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="modal fade" id="productCreateModal" tabindex="-1" aria-hidden="true">
                                    <div class="modal-dialog modal-lg modal-dialog-centered">
                                        <div class="modal-content">
                                            <form id="productCreateForm" enctype="multipart/form-data">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Add product</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div id="productCreateMessage" class="alert" style="display:none" role="alert"></div>
                                                    <input type="hidden" name="csrf_token" value="<?php echo jd_admin_h(jd_admin_csrf_token()); ?>">
                                                    <input type="hidden" name="add_shop_product" value="1">
                                                    <div class="row g-3">
                                                        <div class="col-12">
                                                            <label class="form-label">Product name <span class="tf-color-1">*</span></label>
                                                            <input type="text" class="form-control" name="product_name" placeholder="e.g. Wireless keyboard" required>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <label class="form-label">Subcategory</label>
                                                            <select class="form-select" name="product_sub_catg_id">
                                                                <option value="">Uncategorized</option>
                                                                <?php foreach ($shopCategories as $category): $subList = $subCategoriesByCategory[(int)$category['product_catg_id']] ?? []; if (empty($subList)) continue; ?>
                                                                <optgroup label="<?php echo jd_admin_h($category['product_category']); ?>">
                                                                    <?php foreach ($subList as $subcategory): ?><option value="<?php echo (int)$subcategory['product_sub_catg_id']; ?>"><?php echo jd_admin_h($subcategory['product_sub_category']); ?></option><?php endforeach; ?>
                                                                </optgroup>
                                                                <?php endforeach; ?>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <label class="form-label">SKU <span class="text-muted">(optional)</span></label>
                                                            <input type="text" class="form-control" name="product_sku" placeholder="e.g. JD-KB-001">
                                                        </div>
                                                        <div class="col-md-6">
                                                            <label class="form-label">Selling price (KSh) <span class="tf-color-1">*</span></label>
                                                            <input type="number" class="form-control" name="selling_price" min="0" step="1" required>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <label class="form-label">Previous price (KSh) <span class="text-muted">(optional)</span></label>
                                                            <input type="number" class="form-control" name="was_selling_price" min="0" step="1">
                                                        </div>
                                                        <div class="col-12">
                                                            <label class="form-label">Description</label>
                                                            <textarea class="form-control" name="product_description" rows="3" placeholder="Product description"></textarea>
                                                        </div>
                                                        <div class="col-12">
                                                            <label class="form-label">Additional information <span class="text-muted">(optional)</span></label>
                                                            <textarea class="form-control" name="product_additional_info" rows="2" placeholder="Specifications, dimensions, or materials"></textarea>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <label class="form-label">Size guide <span class="text-muted">(optional)</span></label>
                                                            <textarea class="form-control" name="product_size_guide" rows="2" placeholder="Size guide notes"></textarea>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <label class="form-label">Product image <span class="tf-color-1">*</span></label>
                                                            <input class="form-control" type="file" name="product_image" id="productCreateImage" accept="image/jpeg,image/png,image/gif,image/webp" required>
                                                            <div class="form-text">JPEG, PNG, GIF, or WebP up to 2MB.</div>
                                                        </div>
                                                        <div class="col-12 d-none" id="productCreatePreview"><img src="" alt="Product preview" class="img-thumbnail" style="width:120px;height:120px;object-fit:cover;"></div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="tf-button style-3" data-bs-dismiss="modal">Cancel</button>
                                                    <button type="submit" class="tf-button" id="productCreateSubmit"><i class="icon-plus"></i>Add product</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <script>
                                document.addEventListener('DOMContentLoaded', function(){
                                    const modalElement=document.getElementById('productCreateModal'), modal=modalElement?bootstrap.Modal.getOrCreateInstance(modalElement):null, openButton=document.getElementById('openProductModal'), form=document.getElementById('productCreateForm'), message=document.getElementById('productCreateMessage'), image=document.getElementById('productCreateImage'), preview=document.getElementById('productCreatePreview'), submit=document.getElementById('productCreateSubmit');
                                    const showMessage=(text,type)=>{message.className='alert alert-'+type;message.textContent=text;message.style.display='block';};
                                    if(openButton){openButton.addEventListener('click',()=>{form.reset();message.style.display='none';preview.classList.add('d-none');preview.querySelector('img').src='';modal.show();});}
                                    if(image){image.addEventListener('change',function(){const file=this.files&&this.files[0];if(!file){preview.classList.add('d-none');return;}const url=URL.createObjectURL(file);preview.querySelector('img').src=url;preview.classList.remove('d-none');});}
                                    if(form){form.addEventListener('submit',async function(event){event.preventDefault();const formData=new FormData(form);if(!(formData.get('product_name')||'').trim()){showMessage('Product name is required.','danger');return;}if(!image.files.length){showMessage('Please select a product image.','danger');return;}submit.disabled=true;try{const response=await fetch('action.php',{method:'POST',body:formData,credentials:'same-origin'});const data=await response.json();if(!response.ok||data.status!=='success')throw new Error(data.message||'Unable to add product.');showMessage(data.message||'Product added.','success');setTimeout(()=>location.reload(),550);}catch(error){showMessage(error.message,'danger');}finally{submit.disabled=false;}});}
                                });
                                document.addEventListener('click', async function(event){
                                    const button=event.target.closest('.admin-delete-product');
                                    if(!button || !confirm('Delete "'+button.dataset.productName+'"? Related stock and supplier entries will also be removed.')) return;
                                    const payload=new FormData(); payload.append('csrf_token',document.querySelector('meta[name="csrf-token"]').content); payload.append('delete_shop_product',JSON.stringify({product_id:Number(button.dataset.productId)}));
                                    try{const response=await fetch('action.php',{method:'POST',body:payload,credentials:'same-origin'});const data=await response.json();if(!response.ok||data.status!=='success')throw new Error(data.message||'Unable to delete product.');location.reload();}catch(error){alert(error.message);}
                                });
                                </script>
                                <!-- /product-list -->
                            </div>
                            <!-- /main-content-wrap -->
                        </div>
                        <!-- /main-content-wrap -->
                        <?php include __DIR__ . '/includes/footer.php'; ?>
