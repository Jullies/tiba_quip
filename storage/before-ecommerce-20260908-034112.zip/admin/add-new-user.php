<?php
require_once __DIR__ . '/includes/bootstrap.php';
$id = max(0, (int)($_GET['id'] ?? 0));
$error = '';
$user = ['full_name'=>'', 'username'=>'', 'email'=>'', 'phone'=>'', 'user_level'=>'normal', 'is_active'=>1];
if ($id) {
    $result = mysqli_query($conn, "SELECT full_name, username, email, phone, user_level, is_active FROM webaccounts WHERE user_id=$id LIMIT 1");
    $user = $result ? mysqli_fetch_assoc($result) : null;
    if (!$user) { http_response_code(404); exit('User not found.'); }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!is_string($token) || !hash_equals(jd_admin_csrf_token(), $token)) {
        http_response_code(403); $error = 'Refresh the page and try again.';
    } else {
        foreach (['full_name','username','email','phone','user_level'] as $field) $user[$field] = trim((string)($_POST[$field] ?? ''));
        $user['is_active'] = isset($_POST['is_active']) ? 1 : 0;
        $password = (string)($_POST['password'] ?? '');
        if ($user['full_name'] === '' || strlen($user['full_name']) > 125 || !preg_match('/^[a-zA-Z0-9_.-]{3,25}$/', $user['username']) || !filter_var($user['email'], FILTER_VALIDATE_EMAIL) || strlen($user['email']) > 155 || $user['phone'] === '' || strlen($user['phone']) > 25) {
            $error = 'Enter a name, valid email, phone, and a username of 3–25 letters, numbers, dots, underscores or hyphens.';
        } elseif (!in_array($user['user_level'], ['admin','normal'], true)) {
            $error = 'Choose a supported account role.';
        } elseif ((!$id || $password !== '') && (strlen($password) < 8 || $password !== (string)($_POST['confirm_password'] ?? ''))) {
            $error = 'Passwords must match and contain at least 8 characters.';
        } elseif ($id === (int)($_SESSION['user_id'] ?? 0) && ($user['user_level'] !== 'admin' || !$user['is_active'])) {
            $error = 'You cannot disable your own account or remove your own admin access.';
        } else {
            $stmt = mysqli_prepare($conn, 'SELECT user_id FROM webaccounts WHERE (username=? OR email=? OR phone=?) AND user_id<>? LIMIT 1');
            mysqli_stmt_bind_param($stmt, 'sssi', $user['username'], $user['email'], $user['phone'], $id);
            mysqli_stmt_execute($stmt);
            $duplicate = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
            mysqli_stmt_close($stmt);
            if ($duplicate) $error = 'That username, email or phone is already registered.';
        }
        if ($error === '') {
            if ($id) {
                $sql = 'UPDATE webaccounts SET full_name=?, username=?, email=?, phone=?, user_level=?, is_active=?';
                $params = [$user['full_name'],$user['username'],$user['email'],$user['phone'],$user['user_level'],$user['is_active']];
                $types = 'sssssi';
                if ($password !== '') { $sql .= ', user_password=AES_ENCRYPT(?,?)'; $params[]=$password; $params[]=$password; $types.='ss'; }
                $sql .= ' WHERE user_id=? LIMIT 1'; $params[]=$id; $types.='i';
            } else {
                // Keep compatibility with the existing storefront and admin login format.
                $sql = 'INSERT INTO webaccounts (full_name,username,email,phone,user_level,is_active,user_password) VALUES (?,?,?,?,?,?,AES_ENCRYPT(?,?))';
                $params = [$user['full_name'],$user['username'],$user['email'],$user['phone'],$user['user_level'],$user['is_active'],$password,$password]; $types='sssssiss';
            }
            $stmt = mysqli_prepare($conn, $sql);
            if ($stmt) {
                mysqli_stmt_bind_param($stmt, $types, ...$params);
                $saved = mysqli_stmt_execute($stmt); mysqli_stmt_close($stmt);
            } else { $saved = false; }
            if ($saved) {
                if ($id === (int)($_SESSION['user_id'] ?? 0)) $_SESSION['programUser'] = $user['username'];
                header('Location: all-user.php?saved=1'); exit;
            }
            $error = 'Unable to save the account. Please try again.';
        }
    }
}
include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidenav.php';
?>
<div class="section-content-right">
<?php include __DIR__ . '/includes/topbar.php'; ?>
<div class="main-content"><div class="main-content-inner"><div class="main-content-wrap">
<div class="flex justify-between items-center mb-27"><h3><?php echo $id ? 'Edit User' : 'Add New User'; ?></h3><a class="tf-button style-1" href="all-user.php">Back to users</a></div>
<?php if ($error): ?><div class="alert alert-danger" role="alert"><?php echo jd_admin_h($error); ?></div><?php endif; ?>
<form method="post" class="wg-box">
<input type="hidden" name="csrf_token" value="<?php echo jd_admin_h(jd_admin_csrf_token()); ?>">
<?php foreach (['full_name'=>'Full name','username'=>'Username','email'=>'Email','phone'=>'Phone'] as $field=>$label): ?>
<label><?php echo $label; ?><input type="<?php echo $field==='email'?'email':'text'; ?>" name="<?php echo $field; ?>" value="<?php echo jd_admin_h($user[$field]); ?>" required maxlength="<?php echo $field==='username'?25:($field==='phone'?25:($field==='full_name'?125:155)); ?>"></label>
<?php endforeach; ?>
<label>Role<select name="user_level"><option value="normal" <?php echo $user['user_level']==='normal'?'selected':''; ?>>Customer</option><option value="admin" <?php echo $user['user_level']==='admin'?'selected':''; ?>>Administrator</option></select></label>
<div class="body-text">Administrators can access all admin pages. Customers can access their shop account.</div>
<label><input type="checkbox" name="is_active" value="1" <?php echo $user['is_active']?'checked':''; ?>> Account active</label>
<label>Password <?php echo $id?'(leave blank to keep current password)':''; ?><input type="password" name="password" minlength="8" autocomplete="new-password" <?php echo $id?'':'required'; ?>></label>
<label>Confirm password<input type="password" name="confirm_password" minlength="8" autocomplete="new-password" <?php echo $id?'':'required'; ?>></label>
<button type="submit" class="tf-button">Save user</button>
</form>
</div></div>
<?php include __DIR__ . '/includes/footer.php'; ?>
