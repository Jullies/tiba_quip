<?php
require_once __DIR__ . '/includes/bootstrap.php';
$days = (int)($_GET['days'] ?? 30);
if (!in_array($days, [7,14,30,90], true)) $days = 30;
$summary = ['orders'=>0,'revenue'=>0,'pending'=>0,'cancelled'=>0];
$result = mysqli_query($conn, "SELECT COUNT(*) AS orders, COALESCE(SUM(CASE WHEN order_status='fulfilled' THEN total_amount ELSE 0 END),0) AS revenue, COALESCE(SUM(order_status='pending'),0) AS pending, COALESCE(SUM(order_status='cancelled'),0) AS cancelled FROM shop_orders WHERE created_at >= DATE_SUB(NOW(), INTERVAL $days DAY)");
if ($result) $summary = mysqli_fetch_assoc($result);
$rows = [];
$result = mysqli_query($conn, "SELECT DATE(created_at) AS day, COUNT(*) AS orders, COALESCE(SUM(CASE WHEN order_status='fulfilled' THEN total_amount ELSE 0 END),0) AS revenue FROM shop_orders WHERE created_at >= DATE_SUB(NOW(), INTERVAL $days DAY) GROUP BY DATE(created_at) ORDER BY day DESC");
while ($result && ($row=mysqli_fetch_assoc($result))) $rows[]=$row;
include __DIR__ . '/includes/head.php';
include __DIR__ . '/includes/sidenav.php';
?>
<div class="section-content-right"><?php include __DIR__ . '/includes/topbar.php'; ?>
<div class="main-content"><div class="main-content-inner"><div class="main-content-wrap">
<div class="flex items-center justify-between flex-wrap gap20 mb-27"><h3>Sales Report</h3><form method="get" class="flex gap10"><label>Period<select name="days"><?php foreach ([7,14,30,90] as $period): ?><option value="<?php echo $period; ?>" <?php echo $days===$period?'selected':''; ?>>Last <?php echo $period; ?> days</option><?php endforeach; ?></select></label><button type="submit" class="tf-button">Apply</button></form></div>
<div class="wg-box mb-24"><div class="flex gap20 flex-wrap">
<div><div class="body-text">Orders placed</div><h4><?php echo number_format($summary['orders']); ?></h4></div>
<div><div class="body-text">Completed order value (KSh)</div><h4><?php echo number_format($summary['revenue'],2); ?></h4></div>
<div><div class="body-text">Pending orders</div><h4><?php echo number_format($summary['pending']); ?></h4></div>
<div><div class="body-text">Cancelled orders</div><h4><?php echo number_format($summary['cancelled']); ?></h4></div>
</div><p>Completed order value includes fulfilled orders placed within the selected period. Profit requires recorded costs and is not calculated here.</p></div>
<div class="wg-box"><h5>Orders by day placed</h5><div style="overflow-x:auto"><table class="table"><thead><tr><th>Date</th><th>Orders</th><th>Completed order value (KSh)</th></tr></thead><tbody>
<?php if (!$rows): ?><tr><td colspan="3">No orders in this period.</td></tr><?php endif; ?>
<?php foreach ($rows as $row): ?><tr><td><?php echo jd_admin_h($row['day']); ?></td><td><?php echo (int)$row['orders']; ?></td><td><?php echo number_format($row['revenue'],2); ?></td></tr><?php endforeach; ?>
</tbody></table></div><a class="tf-button style-1" href="order-list.php">View and export orders</a></div>
</div></div><?php include __DIR__ . '/includes/footer.php'; ?>
