<?php include __DIR__ . '/includes/head.php'; ?>

<?php include __DIR__ . '/includes/sidenav.php'; ?>
                <!-- section-content-right -->
                <div class="section-content-right">
                    <?php include __DIR__ . '/includes/topbar.php'; ?>
                    <!-- main-content -->
                    <div class="main-content">
                        <!-- main-content-wrap -->
                        <div class="main-content-inner">
                            <!-- main-content-wrap -->
                            <div class="main-content-wrap">
                                <div class="flex items-center flex-wrap justify-between gap20 mb-27">
                                    <h3>Category infomation</h3>
                                    <ul class="breadcrumbs flex items-center flex-wrap justify-start gap10">
                                        <li>
                                            <a href="index.php"><div class="text-tiny">Dashboard</div></a>
                                        </li>
                                        <li>
                                            <i class="icon-chevron-right"></i>
                                        </li>
                                        <li>
                                            <a href="#"><div class="text-tiny">Category</div></a>
                                        </li>
                                        <li>
                                            <i class="icon-chevron-right"></i>
                                        </li>
                                        <li>
                                            <div class="text-tiny">New category</div>
                                        </li>
                                    </ul>
                                </div>
                                <!-- new-category -->
                                <div class="wg-box">
                                    <form class="form-new-product form-style-1" id="adminCategoryForm" enctype="multipart/form-data">
                                        <input type="hidden" name="csrf_token" value="<?php echo jd_admin_h(jd_admin_csrf_token()); ?>">
                                        <div id="adminCategoryMessage" class="alert" style="display:none" role="alert"></div>
                                        <fieldset class="name">
                                            <div class="body-title">Product name <span class="tf-color-1">*</span></div>
                                            <input class="flex-grow" type="text" placeholder="Category name" name="category_name" tabindex="0" value="" aria-required="true" required="">
                                        </fieldset>
                                        <fieldset>
                                            <div class="body-title">Upload images <span class="tf-color-1">*</span></div>
                                            <div class="upload-image flex-grow">
                                                <div class="item up-load">
                                                    <label class="uploadfile" for="myFile">
                                                        <span class="icon">
                                                            <i class="icon-upload-cloud"></i>
                                                        </span>
                                                        <span class="body-text">Drop your images here or select <span class="tf-color">click to browse</span></span>
                                                        <input type="file" id="myFile" name="category_image" accept="image/jpeg,image/png,image/gif,image/webp">
                                                    </label>
                                                </div>
                                            </div>
                                        </fieldset>
                                        <fieldset class="category">
                                            <div class="body-title">Select category icon</div>
                                            <div class="select flex-grow">
                                                <select class="">
                                                    <option>Select icon</option>
                                                    <option>icon 1</option>
                                                    <option>icon 2</option>
                                                </select>
                                            </div>
                                        </fieldset>
                                        <div class="bot">
                                            <div></div>
                                            <button class="tf-button w208" type="submit">Save</button>
                                        </div>
                                    </form>
                                    <script>
                                    document.addEventListener('DOMContentLoaded',function(){const form=document.getElementById('adminCategoryForm');const message=document.getElementById('adminCategoryMessage');form.addEventListener('submit',async function(event){event.preventDefault();const payload=new FormData(form);payload.append('add_shop_category',JSON.stringify({category:payload.get('category_name')}));try{const response=await fetch('action.php',{method:'POST',body:payload,credentials:'same-origin'});const data=await response.json();if(!response.ok||data.status!=='success')throw new Error(data.message||'Unable to save category.');window.location.href='category-list.php';}catch(error){message.className='alert alert-danger';message.textContent=error.message;message.style.display='block';}});});
                                    </script>
                                </div>
                                <!-- /new-category -->
                            </div>
                            <!-- /main-content-wrap -->
                        </div>
                        <!-- /main-content-wrap -->
                        <?php include __DIR__ . '/includes/footer.php'; ?>
