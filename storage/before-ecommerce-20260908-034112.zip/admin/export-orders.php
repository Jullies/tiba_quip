<?php
require_once __DIR__ . '/includes/bootstrap.php';

$search = trim((string)($_GET['q'] ?? ''));
$status = strtolower(trim((string)($_GET['status'] ?? '')));
$allowedStatuses = ['pending', 'shipping', 'fulfilled', 'cancelled'];
if (!in_array($status, $allowedStatuses, true)) { $status = ''; }
$where = [];
if ($status !== '') { $where[] = "so.order_status = '{$status}'"; }
if ($search !== '') { $where[] = "CONCAT_WS(' ', so.order_id, so.customer_name, so.customer_email, so.customer_phone, so.tracker) LIKE ?"; }
$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
$sql = "SELECT so.order_id, so.created_at, so.customer_name, so.customer_email, so.customer_phone, so.item_count, so.total_amount, so.order_status, so.tracker FROM shop_orders so {$whereSql} ORDER BY so.created_at DESC";
$statement = mysqli_prepare($conn, $sql);
if (!$statement) { http_response_code(500); exit('Unable to prepare order export.'); }
if ($search !== '') { $searchLike = '%' . $search . '%'; mysqli_stmt_bind_param($statement, 's', $searchLike); }
mysqli_stmt_execute($statement);
$result = mysqli_stmt_get_result($statement);

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="jd-shop-orders-' . date('Y-m-d-His') . '.csv"');
$output = fopen('php://output', 'wb');
fputcsv($output, ['Order ID', 'Date', 'Customer', 'Email', 'Phone', 'Items', 'Total (KSh)', 'Status', 'Tracker']);
while ($result && ($row = mysqli_fetch_assoc($result))) {
    foreach ($row as &$cell) { if (is_string($cell) && preg_match('/^[\s]*[=+@-]/u', $cell)) $cell = "'" . $cell; }
    unset($cell);
    fputcsv($output, [$row['order_id'], $row['created_at'], $row['customer_name'], $row['customer_email'], $row['customer_phone'], $row['item_count'], $row['total_amount'], $row['order_status'], $row['tracker']]);
}
fclose($output);
mysqli_stmt_close($statement);
exit;
