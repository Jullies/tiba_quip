<?php
require_once __DIR__ . '/includes/bootstrap.php';

$orderRows = [];
$search = trim((string)($_GET['q'] ?? ''));
$page = max(1, (int)($_GET['page'] ?? 1));
$where = $search !== '' ? " WHERE CONCAT_WS(' ',so.order_id,so.customer_name,so.customer_email,so.customer_phone,so.tracker) LIKE '%" . mysqli_real_escape_string($conn, $search) . "%'" : '';
$countResult = mysqli_query($conn, 'SELECT COUNT(*) AS total FROM shop_orders so' . $where);
$total = $countResult ? (int)mysqli_fetch_assoc($countResult)['total'] : 0;
$pages = max(1, (int)ceil($total / 20));
$page = min($page, $pages);
$offset = ($page - 1) * 20;
$orderSql = "
    SELECT so.order_id, so.total_amount, so.item_count, so.order_status, so.tracker,
           COALESCE(oi.item_name, CONCAT('Order #', so.order_id)) AS item_name,
           COALESCE(oi.quantity, 0) AS quantity, p.product_link
    FROM shop_orders so
    LEFT JOIN (
        SELECT i1.order_id, i1.item_name, i1.quantity, i1.item_type, i1.item_ref_id
        FROM shop_order_items i1
        INNER JOIN (
            SELECT order_id, MIN(item_id) AS first_item_id
            FROM shop_order_items
            GROUP BY order_id
        ) first_items ON first_items.first_item_id = i1.item_id
    ) oi ON oi.order_id = so.order_id
    LEFT JOIN my_shop_products p ON oi.item_type = 'product' AND p.product_id = oi.item_ref_id
    $where
    ORDER BY so.created_at DESC
    LIMIT 20 OFFSET $offset
";
$orderQuery = mysqli_query($conn, $orderSql);
if($orderQuery){
    while($row = mysqli_fetch_assoc($orderQuery)){
        $orderRows[] = $row;
    }
}
?>

<?php include __DIR__ . '/includes/head.php'; ?>

<?php include __DIR__ . '/includes/sidenav.php'; ?>
                <!-- section-content-right -->
                <div class="section-content-right">
                    <?php include __DIR__ . '/includes/topbar.php'; ?>
                    <!-- main-content -->
                    <div class="main-content">
                        <!-- main-content-wrap -->
                        <div class="main-content-inner">
                            <!-- main-content-wrap -->
                            <div class="main-content-wrap">
                                <div class="flex items-center flex-wrap justify-between gap20 mb-27">
                                    <h3>Order List</h3>
                                    <ul class="breadcrumbs flex items-center flex-wrap justify-start gap10">
                                        <li>
                                            <a href="index.php"><div class="text-tiny">Dashboard</div></a>
                                        </li>
                                        <li>
                                            <i class="icon-chevron-right"></i>
                                        </li>
                                        <li>
                                            <a href="#"><div class="text-tiny">Order</div></a>
                                        </li>
                                        <li>
                                            <i class="icon-chevron-right"></i>
                                        </li>
                                        <li>
                                            <div class="text-tiny">Order List</div>
                                        </li>
                                    </ul>
                                </div>
                                <!-- order-list -->
                                <div class="wg-box">
                                    <div class="flex items-center justify-between gap10 flex-wrap">
                                        <div class="wg-filter flex-grow">
                                            <form class="form-search">
                                                <fieldset class="name">
                                                    <input type="text" placeholder="Search here..." class="" name="q" value="<?php echo jd_admin_h($search); ?>">
                                                </fieldset>
                                                <div class="button-submit">
                                                    <button class="" type="submit"><i class="icon-search"></i></button>
                                                </div>
                                            </form>
                                        </div>
                                        <a class="tf-button style-1 w208" href="export-orders.php?<?php echo jd_admin_h(http_build_query(['q'=>$search])); ?>"><i class="icon-file-text"></i>Export orders</a>
                                    </div>
                                    <div class="wg-table table-all-category">
                                        <ul class="table-title flex gap20 mb-14">
                                            <li>
                                                <div class="body-title">Product</div>
                                            </li>    
                                            <li>
                                                <div class="body-title">Order ID</div>
                                            </li>
                                            <li>
                                                <div class="body-title">Price</div>
                                            </li>
                                            <li>
                                                <div class="body-title">Quantity</div>
                                            </li>
                                            <li>
                                                <div class="body-title">Payment</div>
                                            </li>
                                            <li>
                                                <div class="body-title">Status</div>
                                            </li>
                                            <li>
                                                <div class="body-title">Tracking</div>
                                            </li>
                                            <li>
                                                <div class="body-title">Action</div>
                                            </li>
                                        </ul>
                                        <ul class="flex flex-column">
                                            <?php if(empty($orderRows)): ?>
                                            <li class="product-item gap14">
                                                <div class="flex items-center justify-center flex-grow">
                                                    <div class="body-text">No orders found.</div>
                                                </div>
                                            </li>
                                            <?php else: ?>
                                            <?php foreach($orderRows as $order): ?>
                                            <?php
                                                $status = (string)($order['order_status'] ?? 'pending');
                                                $statusClass = 'block-pending';
                                                $statusText = 'Ordered';
                                                if($status === 'shipping') { $statusClass = 'block-processing'; $statusText = 'Being shipped'; }
                                                if($status === 'fulfilled') { $statusClass = 'block-available'; $statusText = 'Completed'; }
                                                if($status === 'cancelled') { $statusClass = 'block-not-available'; $statusText = 'Cancel'; }
                                                $itemName = htmlspecialchars((string)($order['item_name'] ?? 'Order item'), ENT_QUOTES, 'UTF-8');
                                                $orderId = (int)($order['order_id'] ?? 0);
                                                $amount = (float)($order['total_amount'] ?? 0);
                                                $qty = (float)($order['quantity'] ?? 0);
                                                if($qty <= 0){ $qty = (float)($order['item_count'] ?? 0); }
                                                $tracker = trim((string)($order['tracker'] ?? ''));
                                            ?>
                                            <li class="product-item gap14">
                                                <div class="image no-bg">
                                                    <?php if(!empty($order['product_link'])): ?><img data-product-image src="<?php echo jd_admin_h(jd_admin_image_url($order['product_link'])); ?>" alt="<?php echo $itemName; ?>"><?php else: ?><i class="icon-image"></i><?php endif; ?>
                                                </div>
                                                <div class="flex items-center justify-between gap20 flex-grow">
                                                    <div class="name">
                                                        <a href="product-list.php" class="body-title-2"><?php echo $itemName; ?></a>
                                                    </div>
                                                    <div class="body-text">#<?php echo $orderId; ?></div>
                                                    <div class="body-text">KSh <?php echo number_format($amount, 2); ?></div>
                                                    <div class="body-text"><?php echo number_format($qty, 0); ?></div>
                                                    <div class="body-text">COD</div>
                                                    <div>
                                                        <div class="<?php echo $statusClass; ?>"><?php echo $statusText; ?></div>
                                                    </div>
                                                    <div>
                                                        <div class="block-tracking"><?php echo $tracker !== '' ? htmlspecialchars($tracker, ENT_QUOTES, 'UTF-8') : 'Tracking'; ?></div>
                                                    </div>
                                                    <div class="list-icon-function">
                                                        <a class="item eye" href="order-detail.php?order_id=<?php echo $orderId; ?>"><i class="icon-eye"></i></a>
                                                        <button type="button" class="item edit admin-edit-order-status" data-order-id="<?php echo $orderId; ?>" data-current-status="<?php echo htmlspecialchars($status, ENT_QUOTES, 'UTF-8'); ?>" style="border:0"><i class="icon-edit-3"></i></button>
                                                        <a class="item trash" href="order-tracking.php?order_id=<?php echo $orderId; ?>"><i class="icon-truck"></i></a>
                                                    </div>
                                                </div>
                                            </li>
                                            <?php endforeach; ?>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                    <div class="divider"></div>
                                    <div class="flex items-center justify-between flex-wrap gap10">
                                        <div class="text-tiny">Showing <?php echo count($orderRows); ?> entries</div>
                                        <div class="flex gap10">
<?php if ($page > 1): ?><a href="?<?php echo jd_admin_h(http_build_query(['q'=>$search,'page'=>$page-1])); ?>">Previous</a><?php endif; ?>
<span>Page <?php echo $page; ?> of <?php echo $pages; ?> · <?php echo $total; ?> orders</span>
<?php if ($page < $pages): ?><a href="?<?php echo jd_admin_h(http_build_query(['q'=>$search,'page'=>$page+1])); ?>">Next</a><?php endif; ?>
<a href="orders.php">Manage order notes</a>
</div>
                                    </div>
                                </div>
                                <script>
                                document.addEventListener('click',async function(event){const button=event.target.closest('.admin-edit-order-status');if(!button)return;const status=prompt('Enter status: pending (ordered), shipping, fulfilled (completed), or cancelled',button.dataset.currentStatus);if(!status||!['pending','shipping','fulfilled','cancelled'].includes(status.toLowerCase()))return;const payload=new FormData();payload.append('csrf_token',document.querySelector('meta[name="csrf-token"]').content);payload.append('update_shop_order_status',JSON.stringify({order_id:Number(button.dataset.orderId),order_status:status.toLowerCase()}));try{const response=await fetch('action.php',{method:'POST',body:payload,credentials:'same-origin'});const data=await response.json();if(!response.ok||data.status!=='success')throw new Error(data.message||'Unable to update order.');location.reload();}catch(error){alert(error.message);}});
                                </script>
                                <!-- /order-list -->
                            </div>
                            <!-- /main-content-wrap -->
                        </div>
                        <!-- /main-content-wrap -->
                        <?php include __DIR__ . '/includes/footer.php'; ?>
