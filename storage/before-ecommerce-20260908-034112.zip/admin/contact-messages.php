<?php
require_once __DIR__ . '/includes/bootstrap.php';

mysqli_query($conn, "CREATE TABLE IF NOT EXISTS shop_contact_messages (
    message_id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(160) NOT NULL, customer_email VARCHAR(190) NOT NULL, customer_phone VARCHAR(40) DEFAULT NULL,
    message TEXT NOT NULL, page_path VARCHAR(190) DEFAULT NULL,
    status ENUM('new','contacted','closed') NOT NULL DEFAULT 'new', created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_contact_status (status, created_at), KEY idx_contact_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

$statusTable = 'shop_contact_messages';
$statusPrimaryKey = 'message_id';
require __DIR__ . '/includes/request-status.php';
$messages = [];
$result = mysqli_query($conn, "SELECT message_id, customer_name, customer_email, customer_phone, message, page_path, status, created_at FROM shop_contact_messages ORDER BY FIELD(status, 'new', 'contacted', 'closed'), created_at DESC LIMIT 250");
while ($result && ($row = mysqli_fetch_assoc($result))) $messages[] = $row;
?>
<?php include __DIR__ . '/includes/head.php'; ?>
<?php include __DIR__ . '/includes/sidenav.php'; ?>
<div class="section-content-right">
    <?php include __DIR__ . '/includes/topbar.php'; ?>
    <div class="main-content"><div class="main-content-inner"><div class="main-content-wrap">
<?php if (!empty($statusError)): ?><div class="alert alert-danger" role="alert"><?php echo jd_admin_h($statusError); ?></div><?php endif; ?>
        <div class="flex items-center justify-between flex-wrap gap20 mb-27"><div><h3>Contact Messages</h3><div class="body-text">Messages submitted through the public Contact page.</div></div><div class="body-title-2"><?php echo number_format(count($messages)); ?> messages</div></div>
        <div class="wg-box"><div class="wg-table table-all-user"><ul class="table-title flex gap20 mb-14"><li><div class="body-title">Customer</div></li><li><div class="body-title">Contact</div></li><li><div class="body-title">Message</div></li><li><div class="body-title">Received</div></li></ul><ul class="flex flex-column gap14">
            <?php if (empty($messages)): ?><li class="product-item gap14"><div class="body-text">No contact messages have been received yet.</div></li><?php else: foreach ($messages as $message): ?>
                <li class="product-item gap14"><div class="flex items-center justify-between flex-grow gap20 jd-contact-row"><div><div class="body-title-2"><?php echo jd_admin_h($message['customer_name']); ?></div><div class="text-tiny">#<?php echo (int)$message['message_id']; ?> · <?php echo jd_admin_h($message['status']); ?></div></div><div><a class="body-text" href="mailto:<?php echo rawurlencode((string)$message['customer_email']); ?>"><?php echo jd_admin_h($message['customer_email']); ?></a><?php if (!empty($message['customer_phone'])): ?><br><a class="text-tiny" href="tel:<?php echo rawurlencode((string)$message['customer_phone']); ?>"><?php echo jd_admin_h($message['customer_phone']); ?></a><?php endif; ?></div><div class="text-tiny jd-contact-row__message"><?php echo nl2br(jd_admin_h($message['message'])); ?></div><div class="text-tiny"><?php echo !empty($message['created_at']) ? date('M d, Y H:i', strtotime($message['created_at'])) : '—'; ?><?php jd_admin_status_form($message['message_id'], $message['status']); ?></div></div></li>
            <?php endforeach; endif; ?>
        </ul></div></div>
        <style>.jd-contact-row>div{min-width:0}.jd-contact-row__message{max-width:390px;line-height:1.5}@media(max-width:991px){.jd-contact-row{align-items:flex-start!important;flex-direction:column}}</style>
    </div></div></div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
