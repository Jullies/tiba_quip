<?php
require_once __DIR__ . '/includes/bootstrap.php';

$trackingTableCheck = mysqli_query($conn, "SHOW TABLES LIKE 'shop_order_tracking_events'");
$trackingTableAvailable = $trackingTableCheck && mysqli_num_rows($trackingTableCheck) > 0;

$orderId = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;
$orders = [];
$ordersRes = mysqli_query($conn, "SELECT order_id, customer_name, total_amount, order_status, created_at FROM shop_orders ORDER BY created_at DESC LIMIT 100");
if ($ordersRes) { while ($row = mysqli_fetch_assoc($ordersRes)) { $orders[] = $row; } }
$order = null;
if($orderId > 0){
    $res = mysqli_query($conn, "SELECT * FROM shop_orders WHERE order_id = $orderId LIMIT 1");
    if($res){ $order = mysqli_fetch_assoc($res); }
}
if(!$order && $orderId <= 0){
    $res = mysqli_query($conn, "SELECT * FROM shop_orders ORDER BY created_at DESC LIMIT 1");
    if($res){ $order = mysqli_fetch_assoc($res); }
}
if($order){ $orderId = (int)$order['order_id']; }

$orderItem = null;
if($orderId > 0){
    $itemRes = mysqli_query($conn, "SELECT oi.item_name, oi.quantity, oi.item_type, oi.item_ref_id, p.product_link FROM shop_order_items oi LEFT JOIN my_shop_products p ON oi.item_type = 'product' AND p.product_id = oi.item_ref_id WHERE oi.order_id = $orderId ORDER BY oi.item_id ASC LIMIT 1");
    if($itemRes){ $orderItem = mysqli_fetch_assoc($itemRes); }
}
$events = [];
if($orderId > 0 && $trackingTableAvailable){
    $evRes = mysqli_query($conn, "SELECT event_status, event_description, event_location, event_time FROM shop_order_tracking_events WHERE order_id = $orderId ORDER BY event_time ASC, event_id ASC");
    if($evRes){ while($r=mysqli_fetch_assoc($evRes)){ $events[] = $r; } }
}

$orderStatus = strtolower((string)($order['order_status'] ?? ''));
$statusUpdatedAt = $order['status_updated_at'] ?? ($order['created_at'] ?? null);
if ($order && empty($events)) {
    $events[] = [
        'event_status' => 'Order received',
        'event_description' => 'Order received and recorded.',
        'event_location' => 'Online shop',
        'event_time' => $order['created_at'] ?? null
    ];
    $statusDescription = $orderStatus === 'fulfilled' ? 'Order marked as completed.' : ($orderStatus === 'shipping' ? 'Order is currently being shipped.' : ($orderStatus === 'cancelled' ? 'Order was cancelled.' : 'Order is awaiting shipment.'));
    $events[] = [
        'event_status' => ucfirst($orderStatus ?: 'pending'),
        'event_description' => $statusDescription,
        'event_location' => 'Jullies Develops',
        'event_time' => $statusUpdatedAt
    ];
}
$trackingStages = [
    ['label' => 'Receiving orders', 'active' => (bool)$order, 'value' => !empty($order['created_at']) ? date('g:i A', strtotime($order['created_at'])) : '—'],
    ['label' => 'Order processing', 'active' => in_array($orderStatus, ['pending', 'shipping', 'fulfilled'], true), 'value' => $orderStatus === 'pending' ? 'Ordered' : 'Complete'],
    ['label' => 'Being shipped', 'active' => in_array($orderStatus, ['shipping', 'fulfilled'], true), 'value' => $orderStatus === 'shipping' ? 'In transit' : ($orderStatus === 'fulfilled' ? 'Delivered' : 'Waiting')],
    ['label' => 'Completed', 'active' => $orderStatus === 'fulfilled', 'value' => $orderStatus === 'fulfilled' && $statusUpdatedAt ? date('g:i A', strtotime($statusUpdatedAt)) : 'Pending'],
    ['label' => 'Cancelled', 'active' => $orderStatus === 'cancelled', 'value' => $orderStatus === 'cancelled' && $statusUpdatedAt ? date('g:i A', strtotime($statusUpdatedAt)) : 'Not cancelled']
];
?>

<?php include __DIR__ . '/includes/head.php'; ?>

<?php include __DIR__ . '/includes/sidenav.php'; ?>
                <!-- section-content-right -->
                <div class="section-content-right">
                    <?php include __DIR__ . '/includes/topbar.php'; ?>
                    <!-- main-content -->
                    <div class="main-content">
                        <!-- main-content-wrap -->
                        <div class="main-content-inner">
                            <!-- main-content-wrap -->
                            <div class="main-content-wrap">
                                <div class="flex items-center flex-wrap justify-between gap20 mb-27">
                                    <div><h3>Track Order</h3><div class="text-tiny mt-8">Live fulfilment status from your order records.</div></div>
                                    <ul class="breadcrumbs flex items-center flex-wrap justify-start gap10">
                                        <li>
                                            <a href="index.php"><div class="text-tiny">Dashboard</div></a>
                                        </li>
                                        <li>
                                            <i class="icon-chevron-right"></i>
                                        </li>
                                        <li>
                                            <a href="#"><div class="text-tiny">Order</div></a>
                                        </li>
                                        <li>
                                            <i class="icon-chevron-right"></i>
                                        </li>
                                        <li>
                                            <div class="text-tiny">Track Order</div>
                                        </li>
                                    </ul>
                                </div>
                                <div class="wg-box mb-20">
                                    <form method="get" action="order-tracking.php" class="flex items-center gap10 flex-wrap">
                                        <label class="body-title" for="trackingOrderSelect">Select order</label>
                                        <div class="select" style="min-width:260px"><select id="trackingOrderSelect" name="order_id" onchange="this.form.submit()">
                                            <?php if (empty($orders)): ?><option value="">No orders available</option><?php else: ?>
                                            <?php foreach ($orders as $orderOption): ?><option value="<?php echo (int)$orderOption['order_id']; ?>" <?php echo (int)$orderOption['order_id'] === $orderId ? 'selected' : ''; ?>>#<?php echo (int)$orderOption['order_id']; ?> — <?php echo htmlspecialchars((string)($orderOption['customer_name'] ?: 'Customer'), ENT_QUOTES, 'UTF-8'); ?> (<?php echo ucfirst((string)$orderOption['order_status']); ?>)</option><?php endforeach; ?>
                                            <?php endif; ?>
                                        </select></div>
                                    </form>
                                </div>
                                <!-- order-track -->
                                <div class="wg-box mb-20">
                                    <div class="order-track">
                                        <div class="image">
                                            <?php if(!empty($orderItem['product_link'])): ?><img data-product-image src="<?php echo jd_admin_h(jd_admin_image_url($orderItem['product_link'])); ?>" alt="<?php echo htmlspecialchars((string)($orderItem['item_name'] ?? 'Product'), ENT_QUOTES, 'UTF-8'); ?>"><?php else: ?><i class="icon-image"></i><?php endif; ?>
                                        </div>
                                        <div class="content">
                                            <h5 class="mb-20"><?php echo htmlspecialchars((string)($orderItem['item_name'] ?? 'Order Item'), ENT_QUOTES, 'UTF-8'); ?></h5>
                                            <div class="infor mb-10">
                                                <div class="body-text">Order ID</div>
                                                <div class="body-title-2">#<?php echo (int)$orderId; ?></div>
                                            </div>
                                            <div class="infor mb-10">
                                                <div class="body-text">Customer:</div>
                                                <div class="body-title-2"><?php echo htmlspecialchars((string)($order['customer_name'] ?? '—'), ENT_QUOTES, 'UTF-8'); ?></div>
                                            </div>
                                            <div class="infor mb-10">
                                                <div class="body-text">Order Placed:</div>
                                                <div class="body-title-2"><?php echo !empty($order['created_at']) ? date('d M Y', strtotime($order['created_at'])) : '-'; ?></div>
                                            </div>
                                            <div class="infor mb-20">
                                                <div class="body-text">Quantity:</div>
                                                <div class="body-title-2"><?php echo number_format((float)($orderItem['quantity'] ?? ($order['item_count'] ?? 0)), 0); ?></div>
                                            </div>
                                            <div class="flex gap10 flex-wrap">
                                                <a class="tf-button style-1 w230" href="order-detail.php?order_id=<?php echo (int)$orderId; ?>">View order</a>
                                                <a class="tf-button w230" href="<?php echo !empty($orderItem['item_type']) && $orderItem['item_type'] === 'product' ? 'product-edit.php?id='.(int)$orderItem['item_ref_id'] : 'product-list.php'; ?>">View product</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- /order-track -->
                                <!-- detail -->
                                <div class="wg-box mb-20">
                                    <div>
                                        <h6 class="mb-10">Detail</h6>
                                        <div class="body-text"><?php echo $order ? 'Tracking is based on the current order status and recorded fulfilment events.' : 'No order is available to track yet.'; ?></div>
                                    </div>
                                    <div class="road-map">
                                        <?php foreach ($trackingStages as $stage): ?>
                                        <div class="road-map-item<?php echo $stage['active'] ? ' active' : ''; ?>">
                                            <div class="icon"><i class="icon-check"></i></div>
                                            <h6><?php echo htmlspecialchars($stage['label'], ENT_QUOTES, 'UTF-8'); ?></h6>
                                            <div class="body-text"><?php echo htmlspecialchars($stage['value'], ENT_QUOTES, 'UTF-8'); ?></div>
                                        </div>
                                        <?php endforeach; ?>
                                    </div>

                                </div>
                                <!-- /detail -->
                                <!-- table -->
                                <div class="wg-box">
                                    <div class="wg-table table-order-track">
                                        <ul class="table-title flex mb-24 gap20">
                                            <li>
                                                <div class="body-title">Date</div>
                                            </li>    
                                            <li>
                                                <div class="body-title">Time</div>
                                            </li>    
                                            <li>
                                                <div class="body-title">Description</div>
                                            </li>   
                                            <li>
                                                <div class="body-title">Location</div>
                                            </li>   
                                        </ul>
                                        <ul class="flex flex-column gap14">
                                            <?php if(empty($events)): ?>
                                            <li class="cart-totals-item">
                                                <div class="body-text">-</div>
                                                <div class="body-text">-</div>
                                                <div class="body-text">No tracking events yet</div>
                                                <div class="body-text">-</div>
                                            </li>
                                            <?php else: ?>
                                            <?php foreach($events as $event): ?>
                                            <li class="cart-totals-item">
                                                <div class="body-text"><?php echo !empty($event['event_time']) ? date('d M Y', strtotime($event['event_time'])) : '-'; ?></div>
                                                <div class="body-text"><?php echo !empty($event['event_time']) ? date('g:i A', strtotime($event['event_time'])) : '-'; ?></div>
                                                <div class="body-text"><?php echo htmlspecialchars((string)($event['event_description'] ?? $event['event_status'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></div>
                                                <div class="body-text"><?php echo htmlspecialchars((string)($event['event_location'] ?? '-'), ENT_QUOTES, 'UTF-8'); ?></div>
                                            </li>
                                            <li class="divider"></li>
                                            <?php endforeach; ?>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                </div>
                                <!-- /table -->
                            </div>
                            <!-- /main-content-wrap -->
                        </div>
                        <!-- /main-content-wrap -->
                        <?php include __DIR__ . '/includes/footer.php'; ?>
