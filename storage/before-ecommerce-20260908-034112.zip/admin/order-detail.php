<?php
require_once __DIR__ . '/includes/bootstrap.php';

$orderId = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;
$order = null;
$orderItems = [];

if($orderId > 0){
    $orderRes = mysqli_query($conn, "SELECT * FROM shop_orders WHERE order_id = $orderId LIMIT 1");
    if($orderRes){ $order = mysqli_fetch_assoc($orderRes); }
}
if(!$order && $orderId <= 0){
    $orderRes = mysqli_query($conn, "SELECT * FROM shop_orders ORDER BY created_at DESC LIMIT 1");
    if($orderRes){ $order = mysqli_fetch_assoc($orderRes); }
}
if($order){
    $orderId = (int)$order['order_id'];
    $itemsRes = mysqli_query($conn, "SELECT oi.item_name, oi.quantity, oi.unit_price, oi.total_price, p.product_link FROM shop_order_items oi LEFT JOIN my_shop_products p ON oi.item_type = 'product' AND p.product_id = oi.item_ref_id WHERE oi.order_id = $orderId ORDER BY oi.item_id ASC");
    if($itemsRes){
        while($row = mysqli_fetch_assoc($itemsRes)){
            $orderItems[] = $row;
        }
    }
}

$displayId = $order ? (int)$order['order_id'] : 0;
$displayDate = (!empty($order['created_at'])) ? date('d M Y', strtotime($order['created_at'])) : '-';
$displayTotal = $order ? (float)$order['total_amount'] : 0.0;
$subtotal = 0.0;
foreach($orderItems as $it){ $subtotal += (float)($it['total_price'] ?? 0); }
if($subtotal <= 0){ $subtotal = $displayTotal; }
$shipping = 0.0;
$tax = 0.0;
$expectedDate = (!empty($order['created_at'])) ? date('d M Y', strtotime($order['created_at'].' +3 days')) : '-';

$shippingAddressText = 'No shipping address available';
if($order){
    $namePart = trim((string)($order['customer_name'] ?? ''));
    $phonePart = trim((string)($order['customer_phone'] ?? ''));
    $combined = trim($namePart . ($phonePart !== '' ? ', ' . $phonePart : ''));
    if($combined !== ''){ $shippingAddressText = $combined; }
}
?>

<?php include __DIR__ . '/includes/head.php'; ?>

<?php include __DIR__ . '/includes/sidenav.php'; ?>
                <!-- section-content-right -->
                <div class="section-content-right">
                    <?php include __DIR__ . '/includes/topbar.php'; ?>
                    <!-- main-content -->
                    <div class="main-content">
                        <!-- main-content-wrap -->
                        <div class="main-content-inner">
                            <!-- main-content-wrap -->
                            <div class="main-content-wrap">
                                <div class="flex items-center flex-wrap justify-between gap20 mb-27">
                                    <h3>Order #<?php echo $displayId; ?></h3>
                                    <ul class="breadcrumbs flex items-center flex-wrap justify-start gap10">
                                        <li>
                                            <a href="index.php"><div class="text-tiny">Dashboard</div></a>
                                        </li>
                                        <li>
                                            <i class="icon-chevron-right"></i>
                                        </li>
                                        <li>
                                            <a href="#"><div class="text-tiny">Order</div></a>
                                        </li>
                                        <li>
                                            <i class="icon-chevron-right"></i>
                                        </li>
                                        <li>
                                            <a href="#"><div class="text-tiny">Order detail</div></a>
                                        </li>
                                        <li>
                                            <i class="icon-chevron-right"></i>
                                        </li>
                                        <li>
                                            <div class="text-tiny">Order #<?php echo $displayId; ?></div>
                                        </li>
                                    </ul>
                                </div>
                                <!-- order-detail -->
                                <div class="wg-order-detail">
                                    <div class="left flex-grow">
                                        <div class="wg-box mb-20">
                                            <div class="wg-table table-order-detail">
                                                <ul class="table-title flex items-center justify-between gap20 mb-24">
                                                    <li>
                                                        <div class="body-title">All item</div>
                                                    </li>    
                                                    <li>
                                                        <div class="dropdown default">
                                                            <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                <span class="body-title-2 flex items-center gap8">Sort<i class="h6 icon-chevron-down"></i></span>
                                                            </button>
                                                            <ul class="dropdown-menu">
                                                                <li>  
                                                                    <a href="javascript:void(0);">Name</a>
                                                                </li>
                                                                <li>  
                                                                    <a href="javascript:void(0);">Quantity</a>
                                                                </li>
                                                                <li>  
                                                                    <a href="javascript:void(0);">Price</a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </li>
                                                </ul>
                                                <ul class="flex flex-column">
                                                    <?php if(empty($orderItems)): ?>
                                                    <li class="product-item gap14">
                                                        <div class="flex items-center justify-center flex-grow">
                                                            <div class="body-title-2">No order items found.</div>
                                                        </div>
                                                    </li>
                                                    <?php else: ?>
                                                    <?php foreach($orderItems as $item): ?>
                                                    <li class="product-item gap14">
                                                        <div class="image no-bg">
                                                            <?php if(!empty($item['product_link'])): ?><img data-product-image src="<?php echo jd_admin_h(jd_admin_image_url($item['product_link'])); ?>" alt="<?php echo htmlspecialchars((string)$item['item_name'], ENT_QUOTES, 'UTF-8'); ?>"><?php else: ?><i class="icon-image"></i><?php endif; ?>
                                                        </div>
                                                        <div class="flex items-center justify-between gap40 flex-grow">
                                                            <div class="name">
                                                                <div class="text-tiny mb-1">Product name</div>
                                                                <a href="product-list.php" class="body-title-2"><?php echo htmlspecialchars((string)($item['item_name'] ?? 'Item'), ENT_QUOTES, 'UTF-8'); ?></a>
                                                            </div>
                                                            <div class="name">
                                                                <div class="text-tiny mb-1">Quantity</div>
                                                                <div class="body-title-2"><?php echo number_format((float)($item['quantity'] ?? 0), 0); ?></div>
                                                            </div>
                                                            <div class="name">
                                                                <div class="text-tiny mb-1">Price</div>
                                                                <div class="body-title-2">KSh <?php echo number_format((float)($item['unit_price'] ?? 0), 2); ?></div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <?php endforeach; ?>
                                                    <?php endif; ?>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="wg-box">
                                            <div class="wg-table table-cart-totals">
                                                <ul class="table-title flex mb-24">
                                                    <li>
                                                        <div class="body-title">Cart Totals</div>
                                                    </li>    
                                                    <li>
                                                        <div class="body-title">Price</div>
                                                    </li>    
                                                </ul>
                                                <ul class="flex flex-column gap14">
                                                    <li class="cart-totals-item">
                                                        <span class="body-text">Subtotal:</span>
                                                        <span class="body-title-2">KSh <?php echo number_format($subtotal, 2); ?></span>
                                                    </li>
                                                    <li class="divider"></li>
                                                    <li class="cart-totals-item">
                                                        <span class="body-text">Shipping:</span>
                                                        <span class="body-title-2">KSh <?php echo number_format($shipping, 2); ?></span>
                                                    </li>
                                                    <li class="divider"></li>
                                                    <li class="cart-totals-item">
                                                        <span class="body-text">Tax (GST):</span>
                                                        <span class="body-title-2">KSh <?php echo number_format($tax, 2); ?></span>
                                                    </li>
                                                    <li class="divider"></li>
                                                    <li class="cart-totals-item">
                                                        <span class="body-title">Total price:</span>
                                                        <span class="body-title tf-color-1">KSh <?php echo number_format($displayTotal, 2); ?></span>
                                                    </li>
                                                  
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="right">
                                        <div class="wg-box mb-20 gap10">
                                            <div class="body-title">Summary</div>
                                            <div class="summary-item">
                                                <div class="body-text">Order ID</div>
                                                <div class="body-title-2">#<?php echo $displayId; ?></div>
                                            </div>
                                            <div class="summary-item">
                                                <div class="body-text">Date</div>
                                                <div class="body-title-2"><?php echo $displayDate; ?></div>
                                            </div>
                                            <div class="summary-item">
                                                <div class="body-text">Total</div>
                                                <div class="body-title-2 tf-color-1">KSh <?php echo number_format($displayTotal, 2); ?></div>
                                            </div>
                                        </div>
                                        <div class="wg-box mb-20 gap10">
                                            <div class="body-title">Shipping Address</div>
                                            <div class="body-text"><?php echo htmlspecialchars($shippingAddressText, ENT_QUOTES, 'UTF-8'); ?></div>
                                        </div>
                                        <div class="wg-box mb-20 gap10">
                                            <div class="body-title">Payment Method</div>
                                            <div class="body-text"><?php echo !empty($order['customer_email']) ? htmlspecialchars((string)$order['customer_email'], ENT_QUOTES, 'UTF-8') : 'Payment method not recorded'; ?></div>
                                        </div>
                                        <div class="wg-box gap10">
                                            <div class="body-title">Expected Date Of Delivery</div>
                                            <div class="body-title-2 tf-color-2"><?php echo $expectedDate; ?></div>
                                            <a class="tf-button style-1 w-full" href="order-tracking.php?order_id=<?php echo (int)$displayId; ?>"><i class="icon-truck"></i>Track order</a>
                                        </div>
                                    </div>
                                </div>
                                <!-- /order-detail -->
                            </div>
                            <!-- /main-content-wrap -->
                        </div>
                        <!-- /main-content-wrap -->
                        <?php include __DIR__ . '/includes/footer.php'; ?>
