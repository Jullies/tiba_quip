<?php require_once __DIR__ . '/bootstrap.php'; ?>
<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie" xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<!--<![endif]-->


<!-- Mirrored from themesflat.co/html/remos/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 21 May 2026 05:32:55 GMT -->
<head>
    <!-- Basic Page Needs -->
    <meta charset="utf-8">
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <title>JD Shop Administration</title>
    <meta name="csrf-token" content="<?php echo jd_admin_h(jd_admin_csrf_token()); ?>">

    <meta name="author" content="themesflat.com">

    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- Theme Style -->
    <link rel="stylesheet" type="text/css" href="css/animate.min.css">
    <link rel="stylesheet" type="text/css" href="css/animation.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-select.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/jd-premium.css">



    <!-- Font -->
    <link rel="stylesheet" href="font/fonts.css">

    <!-- Icon -->
    <link rel="stylesheet" href="icon/style.css">

    <!-- Favicon and Touch Icons  -->
    <link rel="icon" type="image/png" href="../assets/images/logo.png">
    <link rel="shortcut icon" type="image/png" href="../assets/images/logo.png">
    <link rel="apple-touch-icon" href="../assets/images/logo.png">

    <script src="js/product-images.js"></script>
</head>

<?php $jdAdminPageClass = basename((string)($_SERVER['SCRIPT_NAME'] ?? '')) !== 'index.php' ? ' jd-admin-page' : ''; ?>
<body class="body<?php echo $jdAdminPageClass; ?>">

    <!-- #wrapper -->
    <div id="wrapper">
        <!-- #page -->
        <div id="page" class="">
            <!-- layout-wrap -->
           <div class="layout-wrap loader-off">
                <!-- preload -->
                <div id="preload" class="preload-container">
                    <div class="preloading">
                        <span></span>
                    </div>
                </div>
                <script>
                    // Never let a slow third-party resource leave the admin UI
                    // hidden behind the loading screen.
                    window.setTimeout(function () {
                        var preload = document.getElementById('preload');
                        if (preload) {
                            preload.style.opacity = '0';
                            preload.style.visibility = 'hidden';
                            preload.style.pointerEvents = 'none';
                        }
                    }, 4000);
                </script>
                <!-- /preload -->
