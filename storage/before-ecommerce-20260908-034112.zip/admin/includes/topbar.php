<?php
// Chat notifications are populated asynchronously below. A production chat-table
// lock or missing legacy index must never hold up the shared admin header.
?>
<!-- header-dashboard -->
                    <div class="header-dashboard">
                        <div class="wrap">
                            <div class="header-left">
                                <a href="index.php">
                                    <img class="" id="logo_header_mobile" alt="" src="../assets/images/logo.png" data-light="../assets/images/logo.png" data-dark="../assets/images/logo.png" data-width="154px" data-height="52px" data-retina="../assets/images/logo.png">
                                </a>
                                <div class="button-show-hide">
                                    <i class="icon-menu-left"></i>
                                </div>
                                <form class="form-search flex-grow" action="product-list.php" method="get">
                                    <fieldset class="name">
                                        <input type="text" placeholder="Search products..." name="q" tabindex="2" value="" aria-required="true" required="">
                                    </fieldset>
                                    <div class="button-submit">
                                        <button class="" type="submit"><i class="icon-search"></i></button>
                                    </div>
                                </form>
                            </div>
                            <div class="header-grid">
                                <div class="header-item country">
                                    <select class="image-select no-text">
                                        <option data-thumbnail="images/country/1.png">ENG</option>
                                        <option data-thumbnail="images/country/9.png">VIE</option>
                                    </select>
                                </div>
                                <div class="header-item button-dark-light">
                                    <i class="icon-moon"></i>
                                </div>
                                <div class="popup-wrap noti type-header">
                                    <div class="dropdown">
                                        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                                                <span class="header-item">
                                                <span class="text-tiny">1</span>
                                                <i class="icon-bell"></i>
                                            </span>
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-end has-content" aria-labelledby="dropdownMenuButton1" >
                                            <li><h6>Notifications</h6></li>
                                            <li><a href="service-requests.php" class="noti-item w-full"><div class="image"><i class="icon-noti-1"></i></div><div class="flex-grow"><div class="body-title">Service requests</div><div class="text-tiny">Review new customer requests and follow up.</div></div></a></li>
                                            <li><a href="contact-messages.php" class="noti-item w-full"><div class="image"><i class="icon-noti-3"></i></div><div class="flex-grow"><div class="body-title">Contact messages</div><div class="text-tiny">View messages sent from the website.</div></div></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="popup-wrap message type-header">
                                    <div class="dropdown">
                                        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton2" data-bs-toggle="dropdown" aria-expanded="false">
                                            <span class="header-item">
                                                <span class="text-tiny" id="jd-topbar-chat-count" hidden></span>
                                                <i class="icon-message-square"></i>
                                            </span>
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-end has-content" aria-labelledby="dropdownMenuButton2" >
                                            <li>
                                                <h6>Live chats</h6>
                                            </li>
                                            <li id="jd-topbar-chat-list"><div class="message-item item-1"><div class="image"><i class="icon-message-square"></i></div><div><div class="body-title-2">Live chats</div><div class="text-tiny">Open the inbox to view conversations.</div></div></div></li>
                                            <li><a href="live-chat.php" class="tf-button w-full">View all chats</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="header-item button-zoom-maximize">
                                    <div class="">
                                        <i class="icon-maximize"></i>
                                    </div>
                                </div>
                                <div class="popup-wrap apps type-header">
                                    <div class="dropdown">
                                        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton4" data-bs-toggle="dropdown" aria-expanded="false">
                                            <span class="header-item">
                                                <i class="icon-grid"></i>
                                            </span>
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-end has-content" aria-labelledby="dropdownMenuButton4" >
                                            <li>
                                                <h6>Related apps</h6>
                                            </li>
                                            <li>
                                                <ul class="list-apps">
                                                    <li class="item">
                                                        <div class="image">
                                                            <img src="images/apps/item-1.png" alt="">
                                                        </div>
                                                        <a href="#">
                                                            <div class="text-tiny">Photoshop</div>
                                                        </a>
                                                    </li>
                                                    <li class="item">
                                                        <div class="image">
                                                            <img src="images/apps/item-2.png" alt="">
                                                        </div>
                                                        <a href="#">
                                                            <div class="text-tiny">illustrator</div>
                                                        </a>
                                                    </li>
                                                    <li class="item">
                                                        <div class="image">
                                                            <img src="images/apps/item-3.png" alt="">
                                                        </div>
                                                        <a href="#">
                                                            <div class="text-tiny">Sheets</div>
                                                        </a>
                                                    </li>
                                                    <li class="item">
                                                        <div class="image">
                                                            <img src="images/apps/item-4.png" alt="">
                                                        </div>
                                                        <a href="#">
                                                            <div class="text-tiny">Gmail</div>
                                                        </a>
                                                    </li>
                                                    <li class="item">
                                                        <div class="image">
                                                            <img src="images/apps/item-5.png" alt="">
                                                        </div>
                                                        <a href="#">
                                                            <div class="text-tiny">Messenger</div>
                                                        </a>
                                                    </li>
                                                    <li class="item">
                                                        <div class="image">
                                                            <img src="images/apps/item-6.png" alt="">
                                                        </div>
                                                        <a href="#">
                                                            <div class="text-tiny">Youtube</div>
                                                        </a>
                                                    </li>
                                                    <li class="item">
                                                        <div class="image">
                                                            <img src="images/apps/item-7.png" alt="">
                                                        </div>
                                                        <a href="#">
                                                            <div class="text-tiny">Flaticon</div>
                                                        </a>
                                                    </li>
                                                    <li class="item">
                                                        <div class="image">
                                                            <img src="images/apps/item-8.png" alt="">
                                                        </div>
                                                        <a href="#">
                                                            <div class="text-tiny">Instagram</div>
                                                        </a>
                                                    </li>
                                                    <li class="item">
                                                        <div class="image">
                                                            <img src="images/apps/item-9.png" alt="">
                                                        </div>
                                                        <a href="#">
                                                            <div class="text-tiny">PDF</div>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </li>
                                            <li><a href="#" class="tf-button w-full">View all app</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="popup-wrap user type-header">
                                    <div class="dropdown">
                                        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton3" data-bs-toggle="dropdown" aria-expanded="false">
                                            <span class="header-user wg-user">
                                                <span class="image">
                                                    <img src="images/avatar/user-1.png" alt="">
                                                </span>
                                                <span class="flex flex-column">
                                                    <span class="body-title mb-2"><?php echo jd_admin_h($jdAdminUser['full_name'] ?? $_SESSION['programUser'] ?? 'Administrator'); ?></span>
                                                    <span class="text-tiny"><?php echo jd_admin_h(ucfirst((string)($jdAdminUser['user_level'] ?? 'admin'))); ?></span>
                                                </span>
                                            </span>
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-end has-content" aria-labelledby="dropdownMenuButton3" >
                                            <li>
                                                <a href="all-user.php" class="user-item">
                                                    <div class="icon">
                                                        <i class="icon-user"></i>
                                                    </div>
                                                    <div class="body-title-2">Account</div>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="live-chat.php" class="user-item">
                                                    <div class="icon">
                                                        <i class="icon-mail"></i>
                                                    </div>
                                                    <div class="body-title-2">Inbox</div>
                                                    <div class="number" id="jd-user-chat-count" hidden></div>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="order-list.php" class="user-item">
                                                    <div class="icon">
                                                        <i class="icon-file-text"></i>
                                                    </div>
                                                    <div class="body-title-2">Taskboard</div>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="service-requests.php" class="user-item">
                                                    <div class="icon">
                                                        <i class="icon-headphones"></i>
                                                    </div>
                                                    <div class="body-title-2">Support</div>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="logout.php?token=<?php echo rawurlencode(jd_admin_csrf_token()); ?>" class="user-item">
                                                    <div class="icon">
                                                        <i class="icon-log-out"></i>
                                                    </div>
                                                    <div class="body-title-2">Log out</div>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /header-dashboard -->
                    <script>
                        (function () {
                            var controller = typeof AbortController === 'function' ? new AbortController() : null;
                            var timer = controller ? setTimeout(function () { controller.abort(); }, 4000) : null;
                            var request = { method: 'POST', credentials: 'same-origin', body: new URLSearchParams({ action: 'agent_topbar', csrf_token: document.querySelector('meta[name="csrf-token"]').content }) };
                            if (controller) request.signal = controller.signal;
                            fetch('../actions/live-chat.php', request).then(function (response) {
                                return response.ok ? response.json() : Promise.reject();
                            }).then(function (payload) {
                                if (!payload || payload.status !== 'success') return;
                                var threads = Array.isArray(payload.threads) ? payload.threads : [];
                                var unread = Number(payload.unread || 0);
                                ['jd-topbar-chat-count', 'jd-user-chat-count'].forEach(function (id) {
                                    var badge = document.getElementById(id);
                                    if (!badge || unread < 1) return;
                                    badge.textContent = unread > 99 ? '99+' : String(unread);
                                    badge.hidden = false;
                                });
                                if (!threads.length) return;
                                var list = document.getElementById('jd-topbar-chat-list');
                                if (!list) return;
                                list.textContent = '';
                                threads.forEach(function (thread) {
                                    var link = document.createElement('a');
                                    link.className = 'message-item item-1';
                                    link.href = 'live-chat.php?thread_id=' + encodeURIComponent(Number(thread.thread_id) || 0);
                                    var image = document.createElement('div');
                                    image.className = 'image';
                                    image.innerHTML = '<i class="icon-message-square"></i>';
                                    var copy = document.createElement('div');
                                    var title = document.createElement('div');
                                    title.className = 'body-title-2';
                                    title.textContent = thread.visitor_name || 'Website Visitor';
                                    var detail = document.createElement('div');
                                    detail.className = 'text-tiny';
                                    detail.textContent = Number(thread.unread_admin || 0) > 0 ? 'New message waiting' : 'Open conversation';
                                    copy.appendChild(title);
                                    copy.appendChild(detail);
                                    link.appendChild(image);
                                    link.appendChild(copy);
                                    list.appendChild(link);
                                });
                            }).catch(function () {}).finally(function () { if (timer) clearTimeout(timer); });
                        })();
                    </script>
