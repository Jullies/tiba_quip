<!-- bottom-page --><div class="bottom-page">
                        <div class="body-text">© <?php echo date('Y'); ?> Jullies Develops. All rights reserved.</div>
                        </div>
                        <!-- /bottom-page -->
                    </div>
                    <!-- /main-content -->
                </div>
                <!-- /section-content-right -->
            </div>
            <!-- /layout-wrap -->
        </div>
        <!-- /#page -->
    </div>
    <!-- /#wrapper -->

    <!-- Javascript -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/bootstrap-select.min.js"></script>
    <script src="js/zoom.js"></script>
    <script src="js/apexcharts/apexcharts.js"></script>
    <script src="js/apexcharts/line-chart-1.js"></script>
    <script src="js/apexcharts/line-chart-2.js"></script>
    <script src="js/apexcharts/line-chart-3.js"></script>
    <script src="js/apexcharts/line-chart-4.js"></script>
    <script src="js/apexcharts/line-chart-5.js"></script>
    <script src="js/apexcharts/line-chart-6.js"></script>
    <script src="js/theme-settings.js"></script>
    <script src="js/main.js"></script>
    <script>
        (function () {
            var navRoot = document.querySelector('.section-menu-left');
            if (!navRoot) return;

            var current = window.location.pathname.split('/').pop() || 'index.php';

            navRoot.querySelectorAll('.menu-list a.active').forEach(function (el) {
                el.classList.remove('active');
            });
            navRoot.querySelectorAll('.menu-list li.menu-item.active').forEach(function (el) {
                el.classList.remove('active');
            });
            navRoot.querySelectorAll('.menu-list ul.sub-menu').forEach(function (el) {
                el.style.display = '';
            });

            var activeLink = navRoot.querySelector('.menu-list a[href="' + current + '"]');
            if (!activeLink) return;

            activeLink.classList.add('active');

            var subItem = activeLink.closest('li.sub-menu-item');
            if (subItem) {
                var parentSubMenu = subItem.closest('ul.sub-menu');
                if (parentSubMenu) {
                    parentSubMenu.style.display = 'block';
                    var parentMenuItem = parentSubMenu.closest('li.menu-item');
                    if (parentMenuItem) parentMenuItem.classList.add('active');
                }
            }

            var directMenuItem = activeLink.closest('li.menu-item');
            if (directMenuItem) directMenuItem.classList.add('active');
        })();
    </script>

</body>


<!-- Mirrored from themesflat.co/html/remos/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 21 May 2026 05:33:54 GMT -->
</html>
