<?php
/** Resolve database product image paths consistently from any admin page. */
function jd_admin_image_url($value): string
{
    $appPath = rtrim(str_replace('\\', '/', dirname(dirname($_SERVER['SCRIPT_NAME'] ?? '/admin/index.php'))), '/.');
    $fallback = $appPath . '/admin/images/product-placeholder.svg';
    $value = trim(str_replace('\\', '/', (string)$value));
    if ($value === '') return $fallback;
    if (preg_match('~^https?://~i', $value)) return filter_var($value, FILTER_VALIDATE_URL) ? $value : $fallback;
    if (preg_match('~^(?:[a-z][a-z0-9+.-]*:|//)~i', $value)) return $fallback;
    $path = rawurldecode(explode('?', explode('#', $value, 2)[0], 2)[0]);
    if (strpos($path, "\0") !== false) return $fallback;
    if ($appPath !== '' && strpos($path, $appPath . '/') === 0) $path = substr($path, strlen($appPath) + 1);
    while (strpos($path, '../') === 0) $path = substr($path, 3);
    $path = ltrim($path, '/');
    $root = realpath(dirname(__DIR__, 2));
    $file = realpath($root . '/' . $path);
    if (!$file || !is_file($file) || strncasecmp($file, $root . DIRECTORY_SEPARATOR, strlen($root) + 1) !== 0) return $fallback;
    if (!in_array(strtolower(pathinfo($file, PATHINFO_EXTENSION)), ['jpg','jpeg','png','gif','webp','svg'], true)) return $fallback;
    return $appPath . '/' . implode('/', array_map('rawurlencode', explode('/', $path)));
}
