<?php
// Included after the request/message table has been ensured, before rendering.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    $status = $_POST['status'] ?? '';
    $recordId = (int)($_POST['record_id'] ?? 0);
    if (!is_string($token) || !hash_equals(jd_admin_csrf_token(), $token)) {
        http_response_code(403); $statusError = 'Refresh the page and try again.';
    } elseif ($recordId <= 0 || !in_array($status, ['new','contacted','closed'], true)) {
        http_response_code(422); $statusError = 'Choose a valid record and status.';
    } else {
        $stmt = mysqli_prepare($conn, "UPDATE `$statusTable` SET status=? WHERE `$statusPrimaryKey`=? LIMIT 1");
        if ($stmt) { mysqli_stmt_bind_param($stmt, 'si', $status, $recordId); $saved = mysqli_stmt_execute($stmt); mysqli_stmt_close($stmt); }
        if (!empty($saved)) { header('Location: ' . basename($_SERVER['SCRIPT_NAME'])); exit; }
        $statusError = 'Unable to update status. Please try again.';
    }
}
function jd_admin_status_form($id, $status) {
    echo '<form method="post"><input type="hidden" name="csrf_token" value="'.jd_admin_h(jd_admin_csrf_token()).'"><input type="hidden" name="record_id" value="'.(int)$id.'"><label class="text-tiny">Status<select name="status">';
    foreach (['new'=>'New','contacted'=>'Contacted','closed'=>'Closed'] as $value=>$label) echo '<option value="'.$value.'"'.($status===$value?' selected':'').'>'.$label.'</option>';
    echo '</select></label><button class="tf-button style-1" type="submit">Save status</button></form>';
}
