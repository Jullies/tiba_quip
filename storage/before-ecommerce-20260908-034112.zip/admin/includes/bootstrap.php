<?php
if (!isset($conn)) {
    require_once __DIR__ . '/../../control/core/init.php';
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!jd_is_active_admin($conn)) {
    $returnTo = basename((string)($_SERVER['PHP_SELF'] ?? 'index.php'));
    header('Location: login.php?return=' . rawurlencode($returnTo));
    exit;
}

if (empty($_SESSION['admin_csrf_token'])) {
    $_SESSION['admin_csrf_token'] = bin2hex(random_bytes(32));
}

if (!function_exists('jd_admin_h')) {
    function jd_admin_h($value): string
    {
        return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('jd_admin_csrf_token')) {
    function jd_admin_csrf_token(): string
    {
        return (string)($_SESSION['admin_csrf_token'] ?? '');
    }
}

require_once __DIR__ . '/media.php';
$jdAdminUser = current_user_profile($conn);
