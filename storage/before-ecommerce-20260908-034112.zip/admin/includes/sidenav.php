<style>
    .layout-wrap .section-menu-left .center .menu-item.has-children .sub-menu a.jd-ecommerce-link {
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .layout-wrap .section-menu-left .center .menu-item.has-children .sub-menu a.jd-ecommerce-link::before {
        display: none;
    }
    .layout-wrap .section-menu-left .center .menu-item.has-children .sub-menu a.jd-ecommerce-link > i {
        width: 16px;
        color: #94a3b8;
        font-size: 15px;
        transition: color .2s ease, transform .2s ease;
    }
    .layout-wrap .section-menu-left .center .menu-item.has-children .sub-menu a.jd-ecommerce-link:hover > i,
    .layout-wrap .section-menu-left .center .menu-item.has-children .sub-menu a.jd-ecommerce-link.active > i {
        color: var(--Main);
        transform: translateX(2px);
    }
</style>
<!-- section-menu-left -->
                <div class="section-menu-left">
                    <div class="box-logo">
                        <a href="index.php" id="site-logo-inner">
                            <img class="admin-brand-logo" id="logo_header" alt="" src="../assets/images/logo.png" data-light="../assets/images/logo.png" data-dark="../assets/images/logo.png" width="52" height="52">
                        </a>
                        <div class="button-show-hide">
                            <i class="icon-menu-left"></i>
                        </div>
                    </div>
                    <div class="section-menu-left-wrap">
                        <div class="center">
                            <div class="center-item">
                                <div class="center-heading">Main Home</div>
                                <ul class="menu-list">
                                    <li class="menu-item">
                                        <a href="index.php" class="">
                                            <div class="icon"><i class="icon-grid"></i></div>
                                            <div class="text">Dashboard</div>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <div class="center-item">
                                <div class="center-heading">All page</div>
                                <ul class="menu-list">
                                    <li class="menu-item has-children">
                                        <a href="javascript:void(0);" class="menu-item-button">
                                            <div class="icon"><i class="icon-shopping-cart"></i></div>
                                            <div class="text">Ecommerce</div>
                                        </a>
                                        <ul class="sub-menu">
                                            <li class="sub-menu-item">
                                                <a href="product-list.php" class="jd-ecommerce-link">
                                                    <i class="icon-package" aria-hidden="true"></i>
                                                    <div class="text">Products</div>
                                                </a>
                                            </li>
                                            <li class="sub-menu-item">
                                                <a href="category-list.php" class="jd-ecommerce-link">
                                                    <i class="icon-folder" aria-hidden="true"></i>
                                                    <div class="text">Categories</div>
                                                </a>
                                            </li>
                                            <li class="sub-menu-item">
                                                <a href="subcategory-list.php" class="jd-ecommerce-link">
                                                    <i class="icon-layers" aria-hidden="true"></i>
                                                    <div class="text">Subcategories</div>
                                                </a>
                                            </li>
                                            <li class="sub-menu-item">
                                                <a href="order-list.php" class="jd-ecommerce-link">
                                                    <i class="icon-shopping-bag" aria-hidden="true"></i>
                                                    <div class="text">Orders</div>
                                                </a>
                                            </li>
                                            <li class="sub-menu-item">
                                                <a href="order-tracking.php" class="jd-ecommerce-link">
                                                    <i class="icon-truck" aria-hidden="true"></i>
                                                    <div class="text">Order Tracking</div>
                                                </a>
                                            </li>
                                            <li class="sub-menu-item">
                                                <a href="service-requests.php" class="jd-ecommerce-link">
                                                    <i class="icon-clipboard" aria-hidden="true"></i>
                                                    <div class="text">Service Requests</div>
                                                </a>
                                            </li>
                                            <li class="sub-menu-item">
                                                <a href="contact-messages.php" class="jd-ecommerce-link">
                                                    <i class="icon-mail" aria-hidden="true"></i>
                                                    <div class="text">Contact Messages</div>
                                                </a>
                                            </li>
                                            <li class="sub-menu-item">
                                                <a href="live-chat.php" class="jd-ecommerce-link">
                                                    <i class="icon-message-circle" aria-hidden="true"></i>
                                                    <div class="text">Live Chat</div>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="menu-item has-children">
                                        <a href="javascript:void(0);" class="menu-item-button">
                                            <div class="icon"><i class="icon-file-text"></i></div>
                                            <div class="text">Blogs</div>
                                        </a>
                                        <ul class="sub-menu">
                                            <li class="sub-menu-item">
                                                <a href="blogs.php" class="">
                                                    <div class="text">Posts &amp; Comments</div>
                                                </a>
                                            </li>
                                            <li class="sub-menu-item">
                                                <a href="categories.php" class="">
                                                    <div class="text">Post Categories</div>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="menu-item has-children">
                                        <a href="javascript:void(0);" class="menu-item-button">
                                            <div class="icon"><i class="icon-user"></i></div>
                                            <div class="text">User</div>
                                        </a>
                                        <ul class="sub-menu">
                                            <li class="sub-menu-item">
                                                <a href="all-user.php" class="">
                                                    <div class="text">All user</div>
                                                </a>
                                            </li>
                                            <li class="sub-menu-item">
                                                <a href="add-new-user.php" class="">
                                                    <div class="text">Add new user</div>
                                                </a>
                                            </li>
                                            <li class="sub-menu-item">
                                                <a href="login.php" class="">
                                                    <div class="text">Login</div>
                                                </a>
                                            </li>
                                            <li class="sub-menu-item">
                                                <a href="all-roles.php" class="">
                                                    <div class="text">All roles</div>
                                                </a>
                                            </li>

                                        </ul>
                                    </li>
                                    <li class="menu-item">
                                        <a href="report.php" class="">
                                            <div class="icon"><i class="icon-pie-chart"></i></div>
                                            <div class="text">Report</div>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <div class="center-item">
                                <ul class="menu-list">
                                    <li class="menu-item">
                                        <a href="../index.php" class="">
                                            <div class="icon"><i class="icon-external-link"></i></div>
                                            <div class="text">View Website</div>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /section-menu-left -->
