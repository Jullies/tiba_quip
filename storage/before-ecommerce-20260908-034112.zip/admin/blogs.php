<?php
	require_once __DIR__ . '/includes/bootstrap.php';

	$subcategories = [];
	$subSql = "
		SELECT sc.subcatg_id, sc.sub_category, bc.category 
		FROM blog_sub_category sc 
		LEFT JOIN blog_category bc ON bc.catg_id = sc.catg_id 
		ORDER BY bc.category ASC, sc.sub_category ASC
	";
	$subQuery = mysqli_query($conn, $subSql);
	if($subQuery){
		while($row = mysqli_fetch_assoc($subQuery)){
			$subcategories[] = $row;
		}
	}

	$blogs = [];
	$blogSql = "
		SELECT 
			b.blog_id,
			b.subcatg_id,
			b.blog_title,
			b.blog_content,
			b.blog_views,
			b.blog_likes,
			b.blog_image_link,
			b.published_by,
			b.last_modified,
			sc.sub_category,
			bc.category,
			COUNT(c.comment_id) AS comment_count
		FROM blogs b
		LEFT JOIN blog_sub_category sc ON sc.subcatg_id = b.subcatg_id
		LEFT JOIN blog_category bc ON bc.catg_id = sc.catg_id
		LEFT JOIN blogs_comments c ON c.blog_id = b.blog_id
		GROUP BY b.blog_id
		ORDER BY b.last_modified DESC
	";
	$blogQuery = mysqli_query($conn, $blogSql);
	if($blogQuery){
		while($row = mysqli_fetch_assoc($blogQuery)){
			$blogs[] = $row;
		}
	}

	$comments = [];
	$commentSql = "
		SELECT 
			c.comment_id,
			c.blog_id,
			c.comment,
			c.comment_likes,
			c.published_by,
			c.last_modified,
			b.blog_title,
			(
				SELECT COUNT(ac.admcomment_id)
				FROM admin_comments ac
				WHERE ac.comment_id = c.comment_id
			) AS admin_reply_count,
			(
				SELECT ac2.comment
				FROM admin_comments ac2
				WHERE ac2.comment_id = c.comment_id
				ORDER BY ac2.last_modified DESC
				LIMIT 1
			) AS latest_admin_reply,
			(
				SELECT ac3.last_modified
				FROM admin_comments ac3
				WHERE ac3.comment_id = c.comment_id
				ORDER BY ac3.last_modified DESC
				LIMIT 1
			) AS latest_admin_reply_at
		FROM blogs_comments c
		INNER JOIN blogs b ON b.blog_id = c.blog_id
		ORDER BY c.last_modified DESC
	";
	$commentQuery = mysqli_query($conn, $commentSql);
	if($commentQuery){
		while($row = mysqli_fetch_assoc($commentQuery)){
			$comments[] = $row;
		}
	}
?>
<?php include __DIR__ . '/includes/head.php'; ?>
<?php include __DIR__ . '/includes/sidenav.php'; ?>
                <div class="section-content-right">
                    <?php include __DIR__ . '/includes/topbar.php'; ?>
                    <div class="main-content">
                        <div class="main-content-inner">
                            <div class="main-content-wrap blog-admin-page">
                                <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/summernote@0.8.20/dist/summernote-lite.min.css">
                                <style>
                                    .blog-admin-page .blog-summary { display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:20px; margin-bottom:28px; }
                                    .blog-admin-page .blog-summary .wg-box { padding:22px; }
                                    .blog-admin-page .blog-summary .label { color:#6b7280; font-size:14px; margin-bottom:8px; }
                                    .blog-admin-page .blog-summary .number { color:#111827; font-size:30px; font-weight:700; }
                                    .blog-admin-page .card { border:0; border-radius:14px; box-shadow:none; background:transparent; }
                                    .blog-admin-page .card-body { padding:0; }
                                    .blog-admin-page .blog-section { padding:28px; }
                                    .blog-admin-page .table { margin-bottom:0; }
                                    .blog-admin-page .table th { color:#111827; font-size:14px; white-space:nowrap; }
                                    .blog-admin-page .table td { vertical-align:middle; }
                                    .blog-admin-page .form-control, .blog-admin-page .form-select { min-height:46px; border:1px solid #e5e7eb; border-radius:8px; }
                                    .blog-admin-page textarea.form-control { min-height:auto; }
                                    .blog-admin-page .note-editor.note-frame { border-color:#e5e7eb; border-radius:8px; overflow:hidden; }
                                    .blog-admin-page .btn-success { background:#1d5eff; border-color:#1d5eff; }
                                    .blog-admin-page .btn-outline-primary { color:#1d5eff; border-color:#1d5eff; }
                                    .blog-admin-page .btn-outline-danger { color:#e5484d; border-color:#e5484d; }
                                    @media (max-width: 767px) { .blog-admin-page .blog-summary { grid-template-columns:1fr; gap:12px; } .blog-admin-page .blog-section { padding:18px; } }
                                </style>
                                <div class="flex items-center flex-wrap justify-between gap20 mb-27">
                                    <div>
                                        <h3>Blogs</h3>
                                        <div class="text-tiny mt-8">Publish articles, maintain posts, and respond to customer comments.</div>
                                    </div>
                                    <ul class="breadcrumbs flex items-center flex-wrap justify-start gap10">
                                        <li><a href="index.php"><div class="text-tiny">Dashboard</div></a></li>
                                        <li><i class="icon-chevron-right"></i></li>
                                        <li><div class="text-tiny">Blogs</div></li>
                                    </ul>
                                </div>
                                <div class="blog-summary">
                                    <div class="wg-box"><div class="label">Published posts</div><div class="number"><?php echo count($blogs); ?></div></div>
                                    <div class="wg-box"><div class="label">Reader comments</div><div class="number"><?php echo count($comments); ?></div></div>
                                    <div class="wg-box"><div class="label">Available subcategories</div><div class="number"><?php echo count($subcategories); ?></div></div>
                                </div>
			<div class="wg-box blog-section">
				<div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-4">
					<div><h4 class="mb-1">Blog editor</h4><p class="text-muted mb-0">Create a new article or select an existing article to update it.</p></div>
					<span class="badge text-bg-primary" id="blogFormMode">Create</span>
				</div>

			<div class="row g-4">
				<div class="col-12">
					<div class="card">
						<div class="card-body">
							<div id="blogMessage" class="alert d-none" role="alert"></div>
							<form class="row g-3" id="blogForm" enctype="multipart/form-data">
								<input type="hidden" name="blog_id" id="blogId">
								<div class="col-12">
									<label class="form-label">Title</label>
									<input type="text" class="form-control" name="blog_title" placeholder="Enter headline" required>
								</div>
								<div class="col-12">
									<label class="form-label">Subcategory</label>
									<select class="form-select" name="subcatg_id">
										<option value="">Uncategorized</option>
										<?php foreach ($subcategories as $sub): ?>
											<option value="<?php echo (int)$sub['subcatg_id']; ?>">
												<?php echo htmlspecialchars(trim(($sub['category'] ? $sub['category'].' • ' : '').$sub['sub_category'])); ?>
											</option>
										<?php endforeach; ?>
									</select>
								</div>
								<div class="col-12">
									<label class="form-label">Author</label>
									<input type="text" class="form-control" name="published_by" placeholder="e.g. Field Agronomist">
								</div>
								<div class="col-12">
									<label class="form-label">Feature image</label>
									<input type="file" class="form-control" name="blog_image" accept="image/*">
									<div class="form-text">JPEG, PNG, GIF, or WebP up to 2MB. Leave empty to keep the current image.</div>
								</div>
								<div class="col-12 d-none" id="blogImagePreview">
									<p class="text-muted small mb-1">Image preview</p>
									<img src="" alt="Blog preview" class="img-thumbnail mb-2" width="200" height="140" style="object-fit: cover;">
									<div>
										<a href="#" target="_blank" rel="noopener" class="small text-decoration-underline" id="blogImagePreviewLink">Open full image</a>
									</div>
								</div>
								<div class="col-12">
									<label class="form-label">Content</label>
									<textarea class="form-control" id="blogContent" name="blog_content" rows="8" placeholder="Share the full story..." required></textarea>
								</div>
								<div class="col-12 d-flex flex-wrap gap-2">
									<button class="btn btn-success" type="submit">
										<i class="fa fa-save me-1"></i>
										<span id="blogSubmitLabel">Publish Post</span>
									</button>
									<button class="btn btn-outline-secondary" type="reset">Reset</button>
									<button class="btn btn-outline-warning d-none" type="button" id="cancelBlogEdit">Cancel Edit</button>
								</div>
							</form>
						</div>
					</div>
				</div>
				<div class="col-12">
					<div class="card">
						<div class="card-body">
							<div class="d-flex justify-content-between align-items-center mb-3">
								<h5 class="card-title mb-0">Published Posts</h5>
								<span class="text-muted small"><?php echo count($blogs); ?> total</span>
							</div>
							<div class="table-responsive">
								<table class="table align-middle mb-0">
									<thead class="table-light">
										<tr>
											<th>Title</th>
											<th>Category</th>
											<th>Comments</th>
											<th>Updated</th>
											<th></th>
										</tr>
									</thead>
									<tbody id="blogTable">
										<?php if(empty($blogs)): ?>
											<tr>
												<td colspan="5" class="text-center text-muted py-4">No posts yet. Start by creating one.</td>
											</tr>
										<?php else: ?>
											<?php foreach ($blogs as $blog): 
												$categoryLabel = 'Uncategorized';
												if(!empty($blog['category']) || !empty($blog['sub_category'])){
													$parts = [];
													if(!empty($blog['category'])){ $parts[] = $blog['category']; }
													if(!empty($blog['sub_category'])){ $parts[] = $blog['sub_category']; }
													$categoryLabel = implode(' • ', $parts);
												}
												$blogData = [
													'id' => (int)$blog['blog_id'],
													'title' => $blog['blog_title'] ?? '',
													'content' => $blog['blog_content'] ?? '',
													'subcatg_id' => $blog['subcatg_id'] ? (int)$blog['subcatg_id'] : null,
													'author' => $blog['published_by'] ?? '',
													'image_link' => $blog['blog_image_link'] ?? ''
												];
											?>
												<tr>
													<td>
														<p class="fw-semibold mb-1"><?php echo htmlspecialchars($blog['blog_title']); ?></p>
														<small class="text-muted">Views: <?php echo (int)$blog['blog_views']; ?> • Likes: <?php echo (int)$blog['blog_likes']; ?></small>
														<?php if(!empty($blog['blog_image_link'])):
															$imageHref = '../'.ltrim($blog['blog_image_link'], '/\\');
														?>
															<div><a href="<?php echo htmlspecialchars($imageHref); ?>" target="_blank" rel="noopener" class="small text-decoration-underline">View image</a></div>
														<?php endif; ?>
													</td>
													<td><?php echo htmlspecialchars($categoryLabel); ?></td>
													<td><span class="badge text-bg-primary"><?php echo (int)$blog['comment_count']; ?></span></td>
													<td><?php echo $blog['last_modified'] ? date('M d, Y H:i', strtotime($blog['last_modified'])) : 'N/A'; ?></td>
													<td class="text-end">
														<button class="btn btn-sm btn-outline-primary edit-blog" data-blog="<?php echo htmlspecialchars(json_encode($blogData), ENT_QUOTES, 'UTF-8'); ?>">
															<i class="fa fa-pen"></i>
														</button>
														<button class="btn btn-sm btn-outline-danger delete-blog" data-blog-id="<?php echo (int)$blog['blog_id']; ?>">
															<i class="fa fa-trash"></i>
														</button>
													</td>
												</tr>
											<?php endforeach; ?>
										<?php endif; ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>

			<section class="mt-5">
				<div class="card h-100">
					<div class="card-body">
						<div class="d-flex justify-content-between align-items-center mb-3">
							<h5 class="card-title mb-0">Recent Comments</h5>
							<span class="text-muted small"><?php echo count($comments); ?> total</span>
						</div>
						<div id="commentMessage" class="alert d-none" role="alert"></div>
						<div class="table-responsive">
							<table class="table align-middle mb-0">
								<thead class="table-light">
									<tr>
										<th>Excerpt</th>
										<th>Post</th>
										<th>Author</th>
										<th>Updated</th>
										<th></th>
									</tr>
								</thead>
								<tbody id="commentTable">
									<?php if(empty($comments)): ?>
										<tr>
											<td colspan="5" class="text-center text-muted py-4">No comments recorded.</td>
										</tr>
									<?php else: ?>
										<?php foreach ($comments as $comment): 
											$hasReply = !empty($comment['admin_reply_count']);
											$commentData = [
												'id' => (int)$comment['comment_id'],
												'comment' => $comment['comment'] ?? '',
												'blog' => $comment['blog_title'] ?? ''
											];
										?>
											<tr>
												<td>
													<div><?php echo htmlspecialchars(mb_strimwidth($comment['comment'], 0, 80, '...')); ?></div>
													<?php if(!empty($comment['latest_admin_reply'])): ?>
														<div class="small text-success mt-1">
															<i class="fa fa-reply me-1"></i>Latest reply: <?php echo htmlspecialchars(mb_strimwidth($comment['latest_admin_reply'], 0, 60, '...')); ?>
														</div>
													<?php endif; ?>
												</td>
												<td><?php echo htmlspecialchars($comment['blog_title']); ?></td>
												<td>
													<?php echo htmlspecialchars($comment['published_by'] ?? 'Guest'); ?>
													<?php if($hasReply): ?>
														<span class="badge bg-success ms-2">Replied</span>
													<?php endif; ?>
												</td>
												<td><?php echo $comment['last_modified'] ? date('M d, Y H:i', strtotime($comment['last_modified'])) : 'N/A'; ?></td>
												<td class="text-end">
													<button class="btn btn-sm btn-outline-primary me-1 reply-comment" data-comment="<?php echo htmlspecialchars(json_encode($commentData), ENT_QUOTES, 'UTF-8'); ?>">
														<i class="fa fa-reply"></i>
													</button>
													<button class="btn btn-sm btn-outline-danger delete-comment" data-comment-id="<?php echo (int)$comment['comment_id']; ?>">
														<i class="fa fa-trash"></i>
													</button>
												</td>
											</tr>
										<?php endforeach; ?>
									<?php endif; ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</section>
			</div>

	<div class="modal fade" id="adminReplyModal" tabindex="-1" aria-labelledby="adminReplyModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-lg modal-dialog-centered">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="adminReplyModalLabel">Reply to Comment</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<form id="adminReplyForm">
					<div class="modal-body">
						<div class="mb-3">
							<p class="text-muted small mb-1">Post</p>
							<h6 class="mb-2" id="replyCommentBlogTitle">Selected blog</h6>
							<p class="text-muted small mb-1">Comment excerpt</p>
							<p class="mb-0" id="replyCommentExcerpt">Comment details...</p>
						</div>
						<div id="replyMessage" class="alert d-none" role="alert"></div>
						<input type="hidden" id="replyCommentId">
						<div class="mb-3">
							<label class="form-label" for="replyCommentText">Your reply</label>
							<textarea class="form-control" id="replyCommentText" rows="4" placeholder="Write an official response" required></textarea>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
						<button type="submit" class="btn btn-success" id="replySubmitBtn">
							<i class="fa fa-paper-plane me-1"></i>Post Reply
						</button>
					</div>
				</form>
			</div>
		</div>
	</div>

	<!-- The current admin shell loads its scripts in the footer; these editor dependencies
	     are loaded here so the existing post editor and reply modal are ready before setup. -->
	<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.20/dist/summernote-lite.min.js"></script>
	<script>
		const blogForm = document.getElementById('blogForm');
		const blogMessage = document.getElementById('blogMessage');
		const blogFormMode = document.getElementById('blogFormMode');
		const blogSubmitLabel = document.getElementById('blogSubmitLabel');
		const cancelBlogEdit = document.getElementById('cancelBlogEdit');
		const commentMessage = document.getElementById('commentMessage');
		const replyModalEl = document.getElementById('adminReplyModal');
		const replyForm = document.getElementById('adminReplyForm');
		const replyCommentIdInput = document.getElementById('replyCommentId');
		const replyCommentText = document.getElementById('replyCommentText');
		const replyCommentBlogTitle = document.getElementById('replyCommentBlogTitle');
		const replyCommentExcerpt = document.getElementById('replyCommentExcerpt');
		const replyMessage = document.getElementById('replyMessage');
		const blogContentInput = blogForm ? blogForm.querySelector('[name="blog_content"]') : null;
		const blogContentEditor = (window.jQuery && blogContentInput) ? window.jQuery(blogContentInput) : null;
		const blogImageInput = blogForm ? blogForm.querySelector('[name="blog_image"]') : null;
		const blogImagePreview = document.getElementById('blogImagePreview');
		const blogImagePreviewImg = blogImagePreview ? blogImagePreview.querySelector('img') : null;
		const blogImagePreviewLink = document.getElementById('blogImagePreviewLink');
		let blogImagePreviewObjectUrl = null;
		const BLOG_DRAFT_STORAGE_KEY = 'JulliesDevelops_blog_draft';
		const blogTitleInput = blogForm ? blogForm.querySelector('[name="blog_title"]') : null;
		const blogAuthorInput = blogForm ? blogForm.querySelector('[name="published_by"]') : null;
		const blogSubcatSelect = blogForm ? blogForm.querySelector('[name="subcatg_id"]') : null;

		if(blogContentEditor && blogContentEditor.length){
			blogContentEditor.summernote({
				placeholder: blogContentInput.getAttribute('placeholder') || 'Share the full story...',
				tabsize: 2,
				height: 320,
				toolbar: [
					['style', ['style']],
					['font', ['bold', 'underline', 'clear']],
					['color', ['color']],
					['para', ['ul', 'ol', 'paragraph']],
					['insert', ['link', 'picture', 'video']],
					['view', ['codeview', 'help']]
				],
				callbacks: {
					onChange: function(){
						saveBlogDraft();
					}
				}
			});
		} else if(blogContentInput){
			blogContentInput.addEventListener('input', saveBlogDraft);
		}

		function showMessage(el, type, text){
			if(!el) return;
			el.textContent = text;
			el.classList.remove('d-none', 'alert-success', 'alert-danger');
			el.classList.add(type === 'success' ? 'alert-success' : 'alert-danger');
		}

		function resetMessage(el){
			if(!el) return;
			el.classList.add('d-none');
			el.textContent = '';
		}

		function resolveMediaPath(path){
			if(!path){
				return '';
			}
			if(/^https?:\/\//i.test(path)){
				return path;
			}
			return '../' + path.replace(/^[./\\]+/, '');
		}

		function hideBlogImagePreview(){
			if(blogImagePreview){
				blogImagePreview.classList.add('d-none');
			}
			if(blogImagePreviewImg){
				blogImagePreviewImg.src = '';
			}
			if(blogImagePreviewLink){
				blogImagePreviewLink.href = '#';
			}
			if(blogImagePreviewObjectUrl){
				URL.revokeObjectURL(blogImagePreviewObjectUrl);
				blogImagePreviewObjectUrl = null;
			}
		}

		function showBlogImagePreview(path){
			if(!blogImagePreview || !blogImagePreviewImg || !blogImagePreviewLink){
				return;
			}
			const resolved = resolveMediaPath(path);
			if(!resolved){
				hideBlogImagePreview();
				return;
			}
			if(blogImagePreviewObjectUrl){
				URL.revokeObjectURL(blogImagePreviewObjectUrl);
				blogImagePreviewObjectUrl = null;
			}
			blogImagePreviewImg.src = resolved;
			blogImagePreviewLink.href = resolved;
			blogImagePreview.classList.remove('d-none');
		}

		function showBlogImagePreviewFromFile(file){
			if(!blogImagePreview || !blogImagePreviewImg || !blogImagePreviewLink){
				return;
			}
			if(blogImagePreviewObjectUrl){
				URL.revokeObjectURL(blogImagePreviewObjectUrl);
				blogImagePreviewObjectUrl = null;
			}
			if(!file){
				hideBlogImagePreview();
				return;
			}
			blogImagePreviewObjectUrl = URL.createObjectURL(file);
			blogImagePreviewImg.src = blogImagePreviewObjectUrl;
			blogImagePreviewLink.href = blogImagePreviewObjectUrl;
			blogImagePreview.classList.remove('d-none');
		}

		function getBlogDraft(){
			if(!window.localStorage){
				return null;
			}
			try {
				const raw = localStorage.getItem(BLOG_DRAFT_STORAGE_KEY);
				return raw ? JSON.parse(raw) : null;
			} catch (err){
				return null;
			}
		}

		function saveBlogDraft(){
			if(!blogForm || !window.localStorage){
				return;
			}
			const blogIdValue = document.getElementById('blogId') ? document.getElementById('blogId').value : '';
			if(blogIdValue){
				return;
			}
			const title = blogForm.querySelector('[name="blog_title"]')?.value || '';
			const author = blogForm.querySelector('[name="published_by"]')?.value || '';
			const subcatg = blogForm.querySelector('[name="subcatg_id"]')?.value || '';
			const content = (blogContentEditor && blogContentEditor.length)
				? (blogContentEditor.summernote('code') || '')
				: (blogContentInput ? blogContentInput.value : '');
			if(!title && !author && !content && !subcatg){
				localStorage.removeItem(BLOG_DRAFT_STORAGE_KEY);
				return;
			}
			const payload = {
				title,
				author,
				subcatg_id: subcatg || '',
				content
			};
			try {
				localStorage.setItem(BLOG_DRAFT_STORAGE_KEY, JSON.stringify(payload));
			} catch (err){
				/* ignore storage errors */
			}
		}

		function clearBlogDraft(){
			if(window.localStorage){
				localStorage.removeItem(BLOG_DRAFT_STORAGE_KEY);
			}
		}

		function restoreBlogDraft(){
			if(!blogForm || !window.localStorage){
				return;
			}
			const blogIdValue = document.getElementById('blogId') ? document.getElementById('blogId').value : '';
			if(blogIdValue){
				return;
			}
			const saved = getBlogDraft();
			if(!saved){
				return;
			}
			if(saved.title){
				blogForm.querySelector('[name="blog_title"]').value = saved.title;
			}
			if(saved.author){
				blogForm.querySelector('[name="published_by"]').value = saved.author;
			}
			if(typeof saved.subcatg_id !== 'undefined' && blogForm.querySelector('[name="subcatg_id"]')){
				blogForm.querySelector('[name="subcatg_id"]').value = saved.subcatg_id || '';
			}
			if(saved.content){
				if(blogContentEditor && blogContentEditor.length){
					blogContentEditor.summernote('code', saved.content);
				} else if(blogContentInput){
					blogContentInput.value = saved.content;
				}
			}
		}

		function sendAdminRequest(key, payload, messageEl, button, opts = {}){
			const requestOptions = { method: 'POST' };
			const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
			if(payload instanceof FormData){
				payload.append('csrf_token', csrfToken);
				payload.append(key, '1');
				requestOptions.body = payload;
			} else {
				requestOptions.headers = {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'};
				requestOptions.body = new URLSearchParams({ csrf_token: csrfToken, [key]: JSON.stringify(payload) });
			}
			fetch('action.php', requestOptions)
				.then(res => res.json())
				.then(data => {
					showMessage(messageEl, data.status === 'success' ? 'success' : 'error', data.message || '');
					if(data.status === 'success'){
						if(typeof opts.onSuccess === 'function'){
							opts.onSuccess(data);
						}
						setTimeout(() => window.location.reload(), 800);
					}
				})
				.catch(() => {
					showMessage(messageEl, 'error', 'Something went wrong. Please try again.');
				})
				.finally(() => {
					if(button){ button.disabled = false; }
				});
		}

		function resetBlogFormState(){
			if(!blogForm) return;
			blogForm.reset();
			if(blogContentEditor && blogContentEditor.length){
				blogContentEditor.summernote('code', '');
			} else if(blogContentInput){
				blogContentInput.value = '';
			}
			document.getElementById('blogId').value = '';
			blogFormMode.textContent = 'Create';
			blogSubmitLabel.textContent = 'Publish Post';
			cancelBlogEdit.classList.add('d-none');
			resetMessage(blogMessage);
			if(blogImageInput){
				blogImageInput.value = '';
			}
			hideBlogImagePreview();
			clearBlogDraft();
		}

		if(blogForm){
			blogForm.addEventListener('submit', function(e){
				e.preventDefault();
				const formData = new FormData(blogForm);
				const title = (formData.get('blog_title') || '').trim();
				const content = (blogContentEditor && blogContentEditor.length)
					? (blogContentEditor.summernote('code') || '').trim()
					: (formData.get('blog_content') || '').trim();
				const subcatgId = formData.get('subcatg_id');
				const author = (formData.get('published_by') || '').trim();
				if(!title || !content){
					showMessage(blogMessage, 'error', 'Title and content are required.');
					return;
				}
				formData.set('blog_title', title);
				formData.set('blog_content', content);
				if(subcatgId){
					formData.set('subcatg_id', subcatgId);
				} else {
					formData.delete('subcatg_id');
				}
				if(author){
					formData.set('published_by', author);
				} else {
					formData.delete('published_by');
				}
				const blogId = formData.get('blog_id');
				const submitBtn = blogForm.querySelector('button[type="submit"]');
				if(submitBtn){ submitBtn.disabled = true; }
				let key = 'add_blog_post';
				if(blogId){
					key = 'update_blog_post';
				}
				sendAdminRequest(
					key,
					formData,
					blogMessage,
					submitBtn,
					{
						onSuccess: () => clearBlogDraft()
					}
				);
			});

			blogForm.addEventListener('reset', () => {
				setTimeout(() => resetBlogFormState(), 0);
			});
		}

		if(blogTitleInput){
			blogTitleInput.addEventListener('input', saveBlogDraft);
		}
		if(blogAuthorInput){
			blogAuthorInput.addEventListener('input', saveBlogDraft);
		}
		if(blogSubcatSelect){
			blogSubcatSelect.addEventListener('change', saveBlogDraft);
		}

		if(blogImageInput){
			blogImageInput.addEventListener('change', function(){
				const file = this.files && this.files.length ? this.files[0] : null;
				if(file){
					showBlogImagePreviewFromFile(file);
				} else {
					hideBlogImagePreview();
				}
			});
		}

		restoreBlogDraft();

		let replyModalInstance = null;
		if(replyModalEl && window.bootstrap){
			replyModalInstance = bootstrap.Modal.getOrCreateInstance(replyModalEl);
		}

		if(cancelBlogEdit){
			cancelBlogEdit.addEventListener('click', resetBlogFormState);
		}

		document.querySelectorAll('.edit-blog').forEach(button => {
			button.addEventListener('click', () => {
				const blogData = JSON.parse(button.dataset.blog);
				document.getElementById('blogId').value = blogData.id || '';
				blogForm.querySelector('[name="blog_title"]').value = blogData.title || '';
				if(blogContentEditor && blogContentEditor.length){
					blogContentEditor.summernote('code', blogData.content || '');
				} else if(blogContentInput){
					blogContentInput.value = blogData.content || '';
				}
				blogForm.querySelector('[name="published_by"]').value = blogData.author || '';
				const subcatgSelect = blogForm.querySelector('[name="subcatg_id"]');
				if(subcatgSelect){
					subcatgSelect.value = blogData.subcatg_id ? blogData.subcatg_id : '';
				}
				if(blogImageInput){
					blogImageInput.value = '';
				}
				if(blogData.image_link){
					showBlogImagePreview(blogData.image_link);
				} else {
					hideBlogImagePreview();
				}
				blogFormMode.textContent = 'Editing';
				blogSubmitLabel.textContent = 'Update Post';
				cancelBlogEdit.classList.remove('d-none');
				resetMessage(blogMessage);
				blogForm.scrollIntoView({ behavior: 'smooth', block: 'start' });
			});
		});

		document.querySelectorAll('.delete-blog').forEach(button => {
			button.addEventListener('click', () => {
				const blogId = parseInt(button.dataset.blogId, 10);
				if(!blogId || !confirm('Delete this blog post? This cannot be undone.')){
					return;
				}
				button.disabled = true;
				sendAdminRequest('delete_blog_post', { blog_id: blogId }, blogMessage, button);
			});
		});

		document.querySelectorAll('.delete-comment').forEach(button => {
			button.addEventListener('click', () => {
				const commentId = parseInt(button.dataset.commentId, 10);
				if(!commentId || !confirm('Delete this comment?')){
					return;
				}
				button.disabled = true;
				sendAdminRequest('delete_blog_comment', { comment_id: commentId }, commentMessage, button);
			});
		});

		document.querySelectorAll('.reply-comment').forEach(button => {
			button.addEventListener('click', () => {
				if(!replyForm || !replyCommentIdInput || !replyCommentBlogTitle || !replyCommentExcerpt){
					return;
				}
				let payload = null;
				try {
					payload = button.dataset.comment ? JSON.parse(button.dataset.comment) : null;
				} catch (err){
					payload = null;
				}
				if(!payload){
					return;
				}
				replyCommentIdInput.value = payload.id || '';
				replyCommentBlogTitle.textContent = payload.blog || 'Selected blog';
				replyCommentExcerpt.textContent = payload.comment || 'No comment available.';
				if(replyCommentText){
					replyCommentText.value = '';
				}
				resetMessage(replyMessage);
				if(replyModalEl && window.bootstrap){
					replyModalInstance = bootstrap.Modal.getOrCreateInstance(replyModalEl);
				}
				if(replyModalInstance){
					replyModalInstance.show();
				}
			});
		});

		if(replyForm){
			replyForm.addEventListener('submit', function(e){
				e.preventDefault();
				if(!replyCommentIdInput || !replyCommentText){
					return;
				}
				const commentId = parseInt(replyCommentIdInput.value, 10);
				const replyTextValue = replyCommentText.value.trim();
				if(!commentId || replyTextValue === ''){
					showMessage(replyMessage, 'error', 'Reply cannot be empty.');
					return;
				}
				const submitBtn = document.getElementById('replySubmitBtn');
				if(submitBtn){
					submitBtn.disabled = true;
				}
				sendAdminRequest('add_admin_comment_reply', { comment_id: commentId, comment: replyTextValue }, replyMessage, submitBtn, {
					onSuccess: () => {
						if(replyCommentText){
							replyCommentText.value = '';
						}
						if(replyModalInstance){
							setTimeout(() => replyModalInstance.hide(), 400);
						}
					}
				});
			});
		}
	</script>
							</div>
						</div>
						<?php include __DIR__ . '/includes/footer.php'; ?>
