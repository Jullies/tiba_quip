<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['programUser'], $_SESSION['programUserLevel']) || $_SESSION['programUserLevel'] !== 'admin') {
    http_response_code(401);
    echo json_encode(['status' => 'error', 'message' => 'Your admin session has expired. Please sign in again.']);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') { http_response_code(405); header('Allow: POST'); echo json_encode(['status'=>'error','message'=>'Use POST for admin actions.']); exit; }
$submittedToken = $_POST['csrf_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
$sessionToken = (string)($_SESSION['admin_csrf_token'] ?? '');
if (!is_string($submittedToken) || $submittedToken === '' || $sessionToken === '' || !hash_equals($sessionToken, $submittedToken)) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Security validation failed. Refresh the page and try again.']);
    exit;
}

require __DIR__ . '/../actions/action.php';


http_response_code(400);
echo json_encode(['status'=>'error','message'=>'Unknown admin action.']);
