<?php
require_once __DIR__ . '/includes/bootstrap.php';

$users = [];
$search = trim((string)($_GET['q'] ?? ''));
$page = max(1, (int)($_GET['page'] ?? 1));
$where = $search !== '' ? " WHERE CONCAT_WS(' ',full_name,username,email,phone) LIKE '%" . mysqli_real_escape_string($conn, $search) . "%'" : '';
$countResult = mysqli_query($conn, 'SELECT COUNT(*) AS total FROM webaccounts' . $where);
$total = $countResult ? (int)mysqli_fetch_assoc($countResult)['total'] : 0;
$pages = max(1, (int)ceil($total / 20));
$page = min($page, $pages);
$offset = ($page - 1) * 20;
$userSql = "
    SELECT user_id, full_name, username, email, phone, user_level, is_active, last_modified
    FROM webaccounts $where
    ORDER BY last_modified DESC, user_id DESC
    LIMIT 20 OFFSET $offset
";
$userQuery = mysqli_query($conn, $userSql);
if($userQuery){
    while($row = mysqli_fetch_assoc($userQuery)){
        $users[] = $row;
    }
}
?>

<?php include __DIR__ . '/includes/head.php'; ?>

<?php include __DIR__ . '/includes/sidenav.php'; ?>
                <!-- section-content-right -->
                <div class="section-content-right">
                    <?php include __DIR__ . '/includes/topbar.php'; ?>
                    <!-- main-content -->
                    <div class="main-content">
                        <!-- main-content-wrap -->
                        <div class="main-content-inner">
                            <!-- main-content-wrap -->
                            <div class="main-content-wrap">
                                <div class="flex items-center flex-wrap justify-between gap20 mb-27">
                                    <h3>All User</h3>
                                    <ul class="breadcrumbs flex items-center flex-wrap justify-start gap10">
                                        <li>
                                            <a href="index.php"><div class="text-tiny">Dashboard</div></a>
                                        </li>
                                        <li>
                                            <i class="icon-chevron-right"></i>
                                        </li>
                                        <li>
                                            <a href="#"><div class="text-tiny">User</div></a>
                                        </li>
                                        <li>
                                            <i class="icon-chevron-right"></i>
                                        </li>
                                        <li>
                                            <div class="text-tiny">All User</div>
                                        </li>
                                    </ul>
                                </div>
                                <!-- all-user -->
                                <div class="wg-box">
                                    <div class="flex items-center justify-between gap10 flex-wrap">
                                        <div class="wg-filter flex-grow">
                                            <form class="form-search">
                                                <fieldset class="name">
                                                    <input type="text" placeholder="Search here..." class="" name="q" value="<?php echo jd_admin_h($search); ?>">
                                                </fieldset>
                                                <div class="button-submit">
                                                    <button class="" type="submit"><i class="icon-search"></i></button>
                                                </div>
                                            </form>
                                        </div>
                                        <a class="tf-button style-1 w208" href="add-new-user.php"><i class="icon-plus"></i>Add new</a>
                                    </div>
                                    <div class="wg-table table-all-user">
                                        <ul class="table-title flex gap20 mb-14">
                                            <li>
                                                <div class="body-title">User</div>
                                            </li>    
                                            <li>
                                                <div class="body-title">Phone</div>
                                            </li>
                                            <li>
                                                <div class="body-title">Email</div>
                                            </li>
                                            <li>
                                                <div class="body-title">Action</div>
                                            </li>
                                        </ul>
                                        <ul class="flex flex-column">
                                            <?php if(empty($users)): ?>
                                            <li class="user-item gap14">
                                                <div class="flex items-center justify-center flex-grow">
                                                    <div class="body-text">No users found.</div>
                                                </div>
                                            </li>
                                            <?php else: ?>
                                            <?php foreach($users as $user): ?>
                                            <?php
                                                $fullName = htmlspecialchars((string)($user['full_name'] ?? 'User'), ENT_QUOTES, 'UTF-8');
                                                $username = htmlspecialchars((string)($user['username'] ?? ''), ENT_QUOTES, 'UTF-8');
                                                $email = htmlspecialchars((string)($user['email'] ?? ''), ENT_QUOTES, 'UTF-8');
                                                $phone = htmlspecialchars((string)($user['phone'] ?? ''), ENT_QUOTES, 'UTF-8');
                                            ?>
                                            <li class="user-item gap14">
                                                <div class="image">
                                                    <img src="images/avatar/user-6.png" alt="">
                                                </div>
                                                <div class="flex items-center justify-between gap20 flex-grow">
                                                    <div class="name">
                                                        <a href="add-new-user.php?id=<?php echo (int)$user['user_id']; ?>" class="body-title-2"><?php echo $fullName; ?></a>
                                                        <div class="text-tiny mt-3"><?php echo $username !== '' ? $username : '-'; ?></div>
                                                    </div>
                                                    <div class="body-text"><?php echo $phone !== '' ? $phone : '-'; ?></div>
                                                    <div class="body-text"><?php echo $email !== '' ? $email : '-'; ?></div>
                                                    <a href="add-new-user.php?id=<?php echo (int)$user['user_id']; ?>" class="body-text">Edit account</a>
                                                </div>
                                            </li>
                                            <?php endforeach; ?>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                    <div class="divider"></div>
                                    <div class="flex items-center justify-between flex-wrap gap10">
                                        <div class="text-tiny">Showing <?php echo count($users); ?> entries</div>
                                        <div class="flex gap10">
<?php if ($page > 1): ?><a href="?<?php echo jd_admin_h(http_build_query(['q'=>$search,'page'=>$page-1])); ?>">Previous</a><?php endif; ?>
<span>Page <?php echo $page; ?> of <?php echo $pages; ?> · <?php echo $total; ?> users</span>
<?php if ($page < $pages): ?><a href="?<?php echo jd_admin_h(http_build_query(['q'=>$search,'page'=>$page+1])); ?>">Next</a><?php endif; ?>
</div>
                                    </div>
                                </div>
                                <!-- /all-user -->
                            </div>
                            <!-- /main-content-wrap -->
                        </div>
                        <!-- /main-content-wrap -->
                        <?php include __DIR__ . '/includes/footer.php'; ?>
