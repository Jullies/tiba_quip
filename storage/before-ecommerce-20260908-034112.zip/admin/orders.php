<?php
	require_once __DIR__ . '/includes/bootstrap.php';
?>
<?php include __DIR__ . '/includes/head.php'; ?>
<?php include __DIR__ . '/includes/sidenav.php'; ?>
                <div class="section-content-right">
                    <?php include __DIR__ . '/includes/topbar.php'; ?>
                    <div class="main-content">
                        <div class="main-content-inner">
                            <div class="main-content-wrap">
	<style>
		.order-badge {
			font-size: 0.85rem;
			padding: 0.35rem 0.75rem;
			border-radius: 30px;
			text-transform: capitalize;
		}
		.order-item-note {
			border-left: 4px solid rgba(11, 65, 41, 0.15);
			padding-left: 12px;
			margin: 0;
		}
	</style>
								<div class="flex items-center flex-wrap justify-between gap20 mb-27">
									<div><h3>Shop Orders</h3><div class="text-tiny mt-8">Track ecommerce requests, update statuses, and keep inventory synchronized.</div></div>
									<ul class="breadcrumbs flex items-center flex-wrap justify-start gap10"><li><a href="index.php"><div class="text-tiny">Dashboard</div></a></li><li><i class="icon-chevron-right"></i></li><li><div class="text-tiny">Orders</div></li></ul>
								</div>
								<div class="legacy-admin-content">
							<div class="d-flex justify-content-end flex-wrap gap-3 mb-4">
				<div class="d-flex gap-2">
					<select class="form-select form-select-sm" id="orderStatusFilter">
						<option value="all">All statuses</option>
						<option value="pending">Ordered</option>
						<option value="shipping">Being shipped</option>
						<option value="fulfilled">Completed</option>
						<option value="cancelled">Cancelled</option>
					</select>
					<button class="btn btn-outline-primary btn-sm" id="refreshOrdersBtn">
						<i class="fa fa-rotate me-1"></i>Refresh
					</button>
				</div>
			</div>

			<div class="row g-4 mb-4">
				<div class="col-md-3">
					<div class="card border-0 shadow-sm">
						<div class="card-body">
							<p class="text-muted mb-1">Total Orders</p>
							<h3 class="mb-0" id="ordersTotalCount">0</h3>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="card border-0 shadow-sm">
						<div class="card-body">
							<p class="text-muted mb-1">Ordered</p>
							<h3 class="mb-0 text-warning" id="ordersPendingCount">0</h3>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="card border-0 shadow-sm">
						<div class="card-body">
							<p class="text-muted mb-1">Fulfilled</p>
							<h3 class="mb-0 text-success" id="ordersFulfilledCount">0</h3>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="card border-0 shadow-sm">
						<div class="card-body">
							<p class="text-muted mb-1">Cancelled</p>
							<h3 class="mb-0 text-danger" id="ordersCancelledCount">0</h3>
						</div>
					</div>
				</div>
			</div>

			<div class="card border-0 shadow-sm">
				<div class="card-body">
					<div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
						<div>
							<h5 class="mb-1">Recent Orders</h5>
							<p class="text-muted mb-0">Update fulfillment status or inspect line items.</p>
						</div>
						<span class="badge text-bg-light"><i class="fa fa-clock me-1"></i>Auto-sync every refresh</span>
					</div>
					<div id="ordersMessage" class="alert d-none" role="alert"></div>
					<div class="table-responsive">
						<table class="table align-middle table-hover">
							<thead class="table-light">
								<tr>
									<th scope="col">Order</th>
									<th scope="col">Customer</th>
									<th scope="col">Items</th>
									<th scope="col">Total</th>
									<th scope="col">Status</th>
									<th scope="col">Placed</th>
									<th scope="col" class="text-end">Actions</th>
								</tr>
							</thead>
							<tbody id="ordersTableBody">
								<tr>
									<td colspan="7" class="text-center text-muted py-4">Loading orders...</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
							</div>

	<div class="modal fade" id="orderDetailsModal" tabindex="-1" aria-hidden="true">
		<div class="modal-dialog modal-lg modal-dialog-scrollable">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title">Order Details</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<div class="modal-body" id="orderDetailsBody">
					<p class="text-muted mb-0">Select an order to view line items.</p>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>
	<div class="modal fade" id="orderNoteModal" tabindex="-1" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<form id="orderNoteForm">
					<div class="modal-header">
						<h5 class="modal-title">Admin Note</h5>
						<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
					</div>
					<div class="modal-body">
						<input type="hidden" id="orderNoteId">
						<label class="form-label">Internal notes</label>
						<textarea class="form-control" id="orderNoteTextarea" rows="4" placeholder="Log delivery updates, payment confirmations, etc."></textarea>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
						<button type="submit" class="btn btn-primary">Save Note</button>
					</div>
				</form>
			</div>
		</div>
	</div>

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
	<script>
		(function(){
			const ordersTableBody = document.getElementById('ordersTableBody');
		const ordersMessage = document.getElementById('ordersMessage');
			const statusFilter = document.getElementById('orderStatusFilter');
			const refreshBtn = document.getElementById('refreshOrdersBtn');
			const countsEls = {
				total: document.getElementById('ordersTotalCount'),
				pending: document.getElementById('ordersPendingCount'),
				shipping: null,
				fulfilled: document.getElementById('ordersFulfilledCount'),
				cancelled: document.getElementById('ordersCancelledCount')
			};
		const orderModalEl = document.getElementById('orderDetailsModal');
		const orderModalBody = document.getElementById('orderDetailsBody');
		const orderModal = orderModalEl ? new bootstrap.Modal(orderModalEl) : null;
		const noteModalEl = document.getElementById('orderNoteModal');
		const noteModal = noteModalEl ? new bootstrap.Modal(noteModalEl) : null;
		const noteForm = document.getElementById('orderNoteForm');
		const noteTextarea = document.getElementById('orderNoteTextarea');
		const noteOrderIdInput = document.getElementById('orderNoteId');
		const statusMeta = {
			pending: { label: 'Ordered', badge: 'text-bg-warning' },
			shipping: { label: 'Being shipped', badge: 'text-bg-primary' },
			fulfilled: { label: 'Completed', badge: 'text-bg-success' },
			cancelled: { label: 'Cancelled', badge: 'text-bg-danger' }
			};
			let ordersCache = [];
			let activeFilter = 'all';

			const ESCAPE_LOOKUP = {
				'&': '&amp;',
				'<': '&lt;',
				'>': '&gt;',
				'"': '&quot;',
				"'": '&#39;'
			};

			function escapeHtml(value){
				return (value ?? '').toString().replace(/[&<>"']/g, char => ESCAPE_LOOKUP[char] || char);
			}

			function formatCurrency(value){
				const amount = Math.round(Number(value || 0));
				return `KSh ${amount.toLocaleString()}`;
			}

			function formatDateLabel(value){
				if(!value){
					return 'N/A';
				}
				const parsed = new Date(value.replace(' ', 'T'));
				if(Number.isNaN(parsed.getTime())){
					return value;
				}
				return parsed.toLocaleString();
			}

			function showOrdersMessage(type, text){
				if(!ordersMessage){
					return;
				}
				ordersMessage.textContent = text;
				ordersMessage.classList.remove('d-none', 'alert-success', 'alert-danger', 'alert-warning');
				ordersMessage.classList.add(type === 'success' ? 'alert-success' : (type === 'warning' ? 'alert-warning' : 'alert-danger'));
			}

			function clearOrdersMessage(){
				if(ordersMessage){
					ordersMessage.classList.add('d-none');
					ordersMessage.textContent = '';
				}
			}

			function updateCounts(counts){
				if(!counts){
					return;
				}
				if(countsEls.total) countsEls.total.textContent = counts.total ?? 0;
				if(countsEls.pending) countsEls.pending.textContent = counts.pending ?? 0;
				if(countsEls.fulfilled) countsEls.fulfilled.textContent = counts.fulfilled ?? 0;
				if(countsEls.cancelled) countsEls.cancelled.textContent = counts.cancelled ?? 0;
			}

			function buildItemsPreview(items){
				if(!Array.isArray(items) || !items.length){
					return '<span class="text-muted">No line items</span>';
				}
				const previewItems = items.slice(0, 2).map(item => {
					const name = escapeHtml(item.item_name || (item.item_type === 'service' ? 'Service' : 'Product'));
					const qty = Math.round(Number(item.quantity || 0)).toLocaleString();
					const type = escapeHtml(item.item_type || '');
					return `<span class="d-block">${name} <span class="text-muted small">(${qty} ${type})</span></span>`;
				});
				if(items.length > 2){
					previewItems.push(`<span class="text-muted small">+${items.length - 2} moreâ€¦</span>`);
				}
				return previewItems.join('');
			}

			function renderOrdersTable(orders){
				if(!ordersTableBody){
					return;
				}
				ordersTableBody.innerHTML = '';
				if(!orders.length){
					const row = document.createElement('tr');
					row.innerHTML = '<td colspan=\"7\" class=\"text-center text-muted py-4\">No orders match your filters.</td>';
					ordersTableBody.appendChild(row);
					return;
				}
				orders.forEach(order => {
					const tr = document.createElement('tr');

					const orderTd = document.createElement('td');
					orderTd.innerHTML = `<strong>#${order.order_id}</strong><div class=\"small text-muted\">Tracker: ${order.tracker || 'N/A'}</div>`;
					tr.appendChild(orderTd);

					const customerTd = document.createElement('td');
					customerTd.innerHTML = `
						<div class=\"fw-semibold\">${escapeHtml(order.customer_name || 'Customer')}</div>
						<div class=\"small text-muted\">${escapeHtml(order.customer_phone || 'No phone')}</div>
						<div class=\"small text-muted\">${order.customer_email ? escapeHtml(order.customer_email) : 'No email'}</div>
					`;
					tr.appendChild(customerTd);

					const itemsTd = document.createElement('td');
					const previewMarkup = buildItemsPreview(order.items || []);
					itemsTd.innerHTML = `
						<strong>${Math.round(Number(order.item_count || 0)).toLocaleString()}</strong> items
						<div class=\"small text-muted\">${previewMarkup}</div>
						<div class=\"small text-muted mt-1\">Last update: ${order.status_updated_at ? formatDateLabel(order.status_updated_at) : 'N/A'}</div>
					`;
					tr.appendChild(itemsTd);

					const totalTd = document.createElement('td');
					totalTd.innerHTML = `<span class=\"fw-semibold\">${formatCurrency(order.total_amount)}</span>`;
					tr.appendChild(totalTd);

					const statusTd = document.createElement('td');
					const statusInfo = statusMeta[order.order_status] || statusMeta.pending;
					statusTd.innerHTML = `<span class=\"badge ${statusInfo.badge} order-badge\">${statusInfo.label}</span>`;
					tr.appendChild(statusTd);

					const createdTd = document.createElement('td');
					createdTd.innerHTML = `<div>${formatDateLabel(order.created_at)}</div>`;
					tr.appendChild(createdTd);

					const actionsTd = document.createElement('td');
					actionsTd.className = 'text-end';
					const actionsWrapper = document.createElement('div');
					actionsWrapper.className = 'd-flex flex-column gap-2';

					const viewBtn = document.createElement('button');
					viewBtn.type = 'button';
					viewBtn.className = 'btn btn-sm btn-outline-primary view-order-details';
					viewBtn.innerHTML = '<i class=\"fa fa-eye me-1\"></i>Details';
					viewBtn.dataset.orderId = order.order_id;

					const noteBtn = document.createElement('button');
					noteBtn.type = 'button';
					noteBtn.className = 'btn btn-sm btn-outline-warning edit-order-note';
					noteBtn.innerHTML = '<i class=\"fa fa-sticky-note me-1\"></i>Note';
					noteBtn.dataset.orderId = order.order_id;
					noteBtn.dataset.orderNote = order.admin_notes || '';

					const statusSelect = document.createElement('select');
					statusSelect.className = 'form-select form-select-sm order-status-select';
					statusSelect.dataset.orderId = order.order_id;
					statusSelect.dataset.currentStatus = order.order_status;
					['pending','shipping','fulfilled','cancelled'].forEach(statusValue => {
						const opt = document.createElement('option');
						opt.value = statusValue;
						opt.textContent = statusMeta[statusValue]?.label || statusValue;
						if(order.order_status === statusValue){
							opt.selected = true;
						}
						statusSelect.appendChild(opt);
					});

					actionsWrapper.appendChild(viewBtn);
					actionsWrapper.appendChild(noteBtn);
					actionsWrapper.appendChild(statusSelect);
					actionsTd.appendChild(actionsWrapper);
					tr.appendChild(actionsTd);

					ordersTableBody.appendChild(tr);
				});
			}

			function buildItemsMarkup(order){
			const notes = order.order_notes ? `<div class=\"mt-3\"><p class=\"text-uppercase text-muted small mb-1\">Customer Note</p><p class=\"order-item-note\">${escapeHtml(order.order_notes)}</p></div>` : '';
			const adminNotes = order.admin_notes ? `<div class=\"mt-3\"><p class=\"text-uppercase text-muted small mb-1\">Admin Note</p><p class=\"order-item-note\">${escapeHtml(order.admin_notes)}</p></div>` : '';
			if(!order.items || !order.items.length){
				return `<p class=\"text-muted\">No items were recorded for this order.</p>${notes}${adminNotes}`;
			}
			const rows = order.items.map(item => `
				<tr>
						<td>
							<strong>${escapeHtml(item.item_name || (item.item_type === 'service' ? 'Service' : 'Product'))}</strong>
							<div class=\"small text-muted text-capitalize\">${escapeHtml(item.item_type)}</div>
						</td>
						<td>${Math.round(Number(item.quantity || 0)).toLocaleString()}</td>
						<td>${formatCurrency(item.unit_price)}</td>
						<td>${item.was_price ? `<span class=\"text-muted text-decoration-line-through\">${formatCurrency(item.was_price)}</span>` : ''}</td>
						<td>${formatCurrency(item.total_price)}</td>
					</tr>
				`).join('');
				return `
					<div class=\"table-responsive\">
						<table class=\"table table-sm\">
							<thead class=\"table-light\">
								<tr>
									<th>Item</th>
									<th>Qty</th>
									<th>Price</th>
									<th>Prev. Price</th>
									<th>Total</th>
								</tr>
							</thead>
							<tbody>
								${rows}
							</tbody>
						</table>
					</div>
					${notes}
					${adminNotes}
				`;
			}

			function openOrderDetails(orderId){
				const order = ordersCache.find(o => o.order_id === orderId);
				if(!order || !orderModal || !orderModalBody){
					return;
				}
				orderModalBody.innerHTML = `
					<div class=\"d-flex justify-content-between align-items-start flex-wrap gap-3 mb-3\">
						<div>
							<p class=\"text-muted mb-1\">Order</p>
							<h4 class=\"mb-0\">#${order.order_id}</h4>
						</div>
						<div>
							<span class=\"badge ${statusMeta[order.order_status]?.badge || 'text-bg-secondary'} order-badge\">${statusMeta[order.order_status]?.label || order.order_status}</span>
						</div>
					</div>
					<div class=\"row g-3 mb-4\">
						<div class=\"col-md-4\">
							<p class=\"text-muted small mb-1\">Customer</p>
							<p class=\"mb-0 fw-semibold\">${escapeHtml(order.customer_name || 'Customer')}</p>
							<small class=\"text-muted d-block\">${escapeHtml(order.customer_phone || 'No phone')}</small>
							<small class=\"text-muted d-block\">${order.customer_email ? escapeHtml(order.customer_email) : 'No email'}</small>
						</div>
						<div class=\"col-md-4\">
							<p class=\"text-muted small mb-1\">Placed</p>
							<p class=\"fw-semibold mb-0\">${formatDateLabel(order.created_at)}</p>
							<small class=\"text-muted d-block\">Tracker: ${order.tracker || 'N/A'}</small>
						</div>
						<div class=\"col-md-4\">
							<p class=\"text-muted small mb-1\">Summary</p>
							<p class=\"fw-semibold mb-0\">${formatCurrency(order.total_amount)}</p>
							<small class=\"text-muted d-block\">${Math.round(Number(order.item_count || 0)).toLocaleString()} total units</small>
						</div>
					</div>
					${buildItemsMarkup(order)}
				`;
				orderModal.show();
			}

			function persistOrdersCache(data){
				ordersCache = Array.isArray(data) ? data : [];
				applyFilters();
			}

			function applyFilters(){
				let filtered = ordersCache.slice();
				if(activeFilter !== 'all'){
					filtered = filtered.filter(order => order.order_status === activeFilter);
				}
				renderOrdersTable(filtered);
			}

			function setLoadingState(isLoading){
				if(refreshBtn){
					refreshBtn.disabled = isLoading;
					refreshBtn.innerHTML = isLoading ? '<span class=\"spinner-border spinner-border-sm me-1\"></span>Loading' : '<i class=\"fa fa-rotate me-1\"></i>Refresh';
				}
				if(isLoading && ordersTableBody){
					ordersTableBody.innerHTML = '<tr><td colspan=\"7\" class=\"text-center text-muted py-4\">Loading orders...</td></tr>';
				}
			}

			function fetchOrders(){
				setLoadingState(true);
				clearOrdersMessage();
				return fetch('action.php', {
					method: 'POST',
					headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'X-CSRF-Token': document.querySelector('meta[name="csrf-token"]').content },
					body: new URLSearchParams({ fetch_shop_orders: '1' })
				})
					.then(res => res.json())
					.then(response => {
						if(response.status !== 'success'){
							throw new Error(response.message || 'Failed to load orders.');
						}
						const payload = response.data || {};
						updateCounts(payload.counts || {});
						persistOrdersCache(payload.orders || []);
					})
					.catch(err => {
						console.error(err);
						showOrdersMessage('danger', err.message || 'We could not load orders.');
						renderOrdersTable([]);
					})
					.finally(() => setLoadingState(false));
			}

			function updateOrderStatus(orderId, status, selectEl, previousStatus){
				if(!orderId || !status){
					return;
				}
				clearOrdersMessage();
				if(selectEl){
					selectEl.disabled = true;
				}
				fetch('action.php', {
					method: 'POST',
					headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'X-CSRF-Token': document.querySelector('meta[name="csrf-token"]').content },
					body: new URLSearchParams({
						update_shop_order_status: JSON.stringify({
							order_id: orderId,
							order_status: status
						})
					})
				})
					.then(res => res.json())
					.then(data => {
						if(data.status !== 'success'){
							throw new Error(data.message || 'Failed to update order.');
						}
						showOrdersMessage('success', data.message || 'Order updated.');
						if(selectEl){
							selectEl.dataset.currentStatus = status;
						}
						return fetchOrders();
					})
					.catch(err => {
						showOrdersMessage('danger', err.message || 'We could not update this order.');
						if(selectEl && previousStatus){
							selectEl.value = previousStatus;
						}
					})
					.finally(() => {
						if(selectEl){
							selectEl.disabled = false;
						}
					});
			}

			document.addEventListener('change', function(event){
				const statusSelect = event.target.closest('.order-status-select');
				if(statusSelect){
					const orderId = parseInt(statusSelect.dataset.orderId, 10);
					const newStatus = statusSelect.value;
					const previous = statusSelect.dataset.currentStatus || 'pending';
					if(orderId && newStatus){
						updateOrderStatus(orderId, newStatus, statusSelect, previous);
					}
					return;
				}
				if(event.target === statusFilter){
					activeFilter = statusFilter.value || 'all';
					applyFilters();
				}
			});

			document.addEventListener('click', function(event){
				const viewBtn = event.target.closest('.view-order-details');
				if(viewBtn){
					const orderId = parseInt(viewBtn.dataset.orderId, 10);
					if(orderId){
						openOrderDetails(orderId);
					}
					return;
				}
				const noteBtn = event.target.closest('.edit-order-note');
				if(noteBtn && noteModal){
					const orderId = parseInt(noteBtn.dataset.orderId, 10);
					if(!orderId){
						return;
					}
					noteOrderIdInput.value = orderId;
					noteTextarea.value = noteBtn.dataset.orderNote || '';
					noteModal.show();
				}
			});

			if(noteForm){
				noteForm.addEventListener('submit', function(event){
					event.preventDefault();
					const orderId = parseInt(noteOrderIdInput.value, 10);
					const note = noteTextarea.value.trim();
					if(!orderId){
						return;
					}
					fetch('action.php', {
						method: 'POST',
						headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'X-CSRF-Token': document.querySelector('meta[name="csrf-token"]').content },
						body: new URLSearchParams({
							update_shop_order_note: JSON.stringify({
								order_id: orderId,
								admin_note: note
							})
						})
					})
						.then(res => res.json())
						.then(data => {
							if(data.status === 'success'){
								showOrdersMessage('success', data.message || 'Note saved.');
								if(noteModal){
									noteModal.hide();
								}
								return fetchOrders();
							}
							throw new Error(data.message || 'Failed to save note.');
						})
						.catch(err => showOrdersMessage('danger', err.message || 'Failed to save note.'));
				});
			}

			if(refreshBtn){
				refreshBtn.addEventListener('click', fetchOrders);
			}

			fetchOrders();
		})();
	</script>
							</div>
						</div>
						<?php include __DIR__ . '/includes/footer.php'; ?>
