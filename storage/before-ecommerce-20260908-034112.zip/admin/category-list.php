<?php
require_once __DIR__ . '/includes/bootstrap.php';

$categories = [];
$searchTerm = trim((string)($_GET['q'] ?? ''));
$perPage = (int)($_GET['per_page'] ?? 10);
if (!in_array($perPage, [10, 20, 30], true)) {
    $perPage = 10;
}
$currentPage = max(1, (int)($_GET['page'] ?? 1));
$whereClause = '';
if ($searchTerm !== '') {
    $searchEsc = mysqli_real_escape_string($conn, $searchTerm);
    $whereClause = " WHERE c.product_category LIKE '%{$searchEsc}%' OR CAST(c.product_catg_id AS CHAR) LIKE '%{$searchEsc}%'";
}
$totalCategories = 0;
$countQuery = mysqli_query($conn, "SELECT COUNT(*) AS total FROM my_shop_categories c{$whereClause}");
if ($countQuery && ($countRow = mysqli_fetch_assoc($countQuery))) {
    $totalCategories = (int)($countRow['total'] ?? 0);
}
$totalPages = max(1, (int)ceil($totalCategories / $perPage));
$currentPage = min($currentPage, $totalPages);
$offset = ($currentPage - 1) * $perPage;
$sql = "
    SELECT c.product_catg_id, c.product_category, c.catg_img_link, c.last_modified,
           COALESCE(product_stats.qty, 0) AS qty,
           COALESCE(stock_stats.stock_qty, 0) AS stock_qty
    FROM my_shop_categories c
    LEFT JOIN (
        SELECT sc.product_catg_id, COUNT(p.product_id) AS qty
        FROM my_shop_sub_categories sc
        LEFT JOIN my_shop_products p ON p.product_sub_catg_id = sc.product_sub_catg_id
        GROUP BY sc.product_catg_id
    ) product_stats ON product_stats.product_catg_id = c.product_catg_id
    LEFT JOIN (
        SELECT sc.product_catg_id, SUM(st.stock_qty) AS stock_qty
        FROM my_shop_sub_categories sc
        LEFT JOIN my_shop_products p ON p.product_sub_catg_id = sc.product_sub_catg_id
        LEFT JOIN my_shop_stock st ON st.product_id = p.product_id
        GROUP BY sc.product_catg_id
    ) stock_stats ON stock_stats.product_catg_id = c.product_catg_id
    {$whereClause}
    ORDER BY c.last_modified DESC
    LIMIT {$perPage} OFFSET {$offset}
";
$q = mysqli_query($conn, $sql);
if($q){ while($r = mysqli_fetch_assoc($q)){ $categories[] = $r; } }
?>

<?php include __DIR__ . '/includes/head.php'; ?>

<?php include __DIR__ . '/includes/sidenav.php'; ?>
                <!-- section-content-right -->
                <div class="section-content-right">
                    <?php include __DIR__ . '/includes/topbar.php'; ?>
                    <!-- main-content -->
                    <div class="main-content">
                        <!-- main-content-wrap -->
                        <div class="main-content-inner">
                            <!-- main-content-wrap -->
                            <div class="main-content-wrap">
                                <div class="flex items-center flex-wrap justify-between gap20 mb-27">
                                    <h3>All category</h3>
                                    <ul class="breadcrumbs flex items-center flex-wrap justify-start gap10">
                                        <li>
                                            <a href="index.php"><div class="text-tiny">Dashboard</div></a>
                                        </li>
                                        <li>
                                            <i class="icon-chevron-right"></i>
                                        </li>
                                        <li>
                                            <a href="#"><div class="text-tiny">Category</div></a>
                                        </li>
                                        <li>
                                            <i class="icon-chevron-right"></i>
                                        </li>
                                        <li>
                                            <div class="text-tiny">All category</div>
                                        </li>
                                    </ul>
                                </div>
                                <!-- all-category -->
                                <div class="wg-box">
                                    <div class="flex items-center justify-between gap10 flex-wrap">
                                        <div class="wg-filter flex-grow">
                                            <form class="show" method="get" action="category-list.php">
                                                <?php if ($searchTerm !== ''): ?><input type="hidden" name="q" value="<?php echo jd_admin_h($searchTerm); ?>"><?php endif; ?>
                                                <div class="text-tiny">Showing</div>
                                                <div class="select">
                                                    <select name="per_page" onchange="this.form.submit()">
                                                        <option value="10" <?php echo $perPage === 10 ? 'selected' : ''; ?>>10</option>
                                                        <option value="20" <?php echo $perPage === 20 ? 'selected' : ''; ?>>20</option>
                                                        <option value="30" <?php echo $perPage === 30 ? 'selected' : ''; ?>>30</option>
                                                    </select>
                                                </div>
                                                <div class="text-tiny">entries</div>
                                            </form>
                                            <form class="form-search" method="get" action="category-list.php">
                                                <input type="hidden" name="per_page" value="<?php echo $perPage; ?>">
                                                <fieldset class="name">
                                                    <input type="text" placeholder="Search by category or ID..." class="" name="q" tabindex="2" value="<?php echo jd_admin_h($searchTerm); ?>">
                                                </fieldset>
                                                <div class="button-submit">
                                                    <button class="" type="submit"><i class="icon-search"></i></button>
                                                </div>
                                            </form>
                                        </div>
                                        <button type="button" class="tf-button style-1 w208" id="openCategoryModal"><i class="icon-plus"></i>Add new</button>
                                    </div>
                                    <div class="wg-table table-all-category">
                                        <ul class="table-title flex gap20 mb-14">
                                            <li>
                                                <div class="body-title">Category</div>
                                            </li>    
                                            <li>
                                                <div class="body-title">Icon</div>
                                            </li>
                                            <li>
                                                <div class="body-title">Quantity</div>
                                            </li>
                                                <li>
                                                    <div class="body-title">Stock units</div>
                                                </li>
                                            <li>
                                                <div class="body-title">Start date</div>
                                            </li>
                                            <li>
                                                <div class="body-title">Action</div>
                                            </li>
                                        </ul>
                                        <ul class="flex flex-column">
                                            <?php if(empty($categories)): ?>
                                            <li class="product-item gap14">
                                                <div class="flex items-center justify-center flex-grow"><div class="body-text">No categories found.</div></div>
                                            </li>
                                            <?php else: ?>
                                            <?php foreach($categories as $cat): ?>
                                            <li class="product-item gap14">
                                                <div class="image no-bg">
                                                    <img data-product-image src="<?php echo jd_admin_h(jd_admin_image_url($cat['catg_img_link'] ?? '')); ?>" alt="Category image">
                                                </div>
                                                <div class="flex items-center justify-between gap20 flex-grow">
                                                    <div class="name"><a href="product-list.php" class="body-title-2"><?php echo htmlspecialchars((string)($cat['product_category'] ?? 'Category'), ENT_QUOTES, 'UTF-8'); ?></a></div>
                                                    <div>
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M3 12h18M12 3v18" stroke="#111111" stroke-width="1"/></svg>
                                                    </div>
                                                    <div class="body-text"><?php echo number_format((float)($cat['qty'] ?? 0), 0); ?></div>
                                                    <div class="body-text"><?php echo number_format((float)($cat['stock_qty'] ?? 0), 0); ?></div>
                                                    <div class="body-text"><?php echo !empty($cat['last_modified']) ? date('d M Y', strtotime($cat['last_modified'])) : '-'; ?></div>
                                                    <div class="list-icon-function">
                                                        <a class="item eye" href="product-list.php?category_id=<?php echo (int)$cat['product_catg_id']; ?>"><i class="icon-eye"></i></a>
                                                        <button type="button" class="item edit admin-edit-category" data-category-id="<?php echo (int)$cat['product_catg_id']; ?>" data-category-name="<?php echo jd_admin_h($cat['product_category']); ?>" style="border:0"><i class="icon-edit-3"></i></button>
                                                        <button type="button" class="item trash admin-delete-category" data-category-id="<?php echo (int)$cat['product_catg_id']; ?>" data-category-name="<?php echo htmlspecialchars((string)$cat['product_category'], ENT_QUOTES, 'UTF-8'); ?>" style="border:0"><i class="icon-trash-2"></i></button>
                                                    </div>
                                                </div>
                                            </li>
                                            <?php endforeach; ?>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                    <div class="divider"></div>
                                    <div class="flex items-center justify-between flex-wrap gap10">
                                        <div class="text-tiny">Showing <?php echo count($categories); ?> of <?php echo $totalCategories; ?> entries</div>
                                        <ul class="wg-pagination">
                                            <li>
                                                <a href="?<?php echo http_build_query(['q' => $searchTerm, 'per_page' => $perPage, 'page' => max(1, $currentPage - 1)]); ?>"><i class="icon-chevron-left"></i></a>
                                            </li>
                                            <?php for ($pageNumber = max(1, $currentPage - 2); $pageNumber <= min($totalPages, $currentPage + 2); $pageNumber++): ?>
                                            <li<?php echo $pageNumber === $currentPage ? ' class="active"' : ''; ?>><a href="?<?php echo http_build_query(['q' => $searchTerm, 'per_page' => $perPage, 'page' => $pageNumber]); ?>"><?php echo $pageNumber; ?></a></li>
                                            <?php endfor; ?>
                                            <li>
                                                <a href="?<?php echo http_build_query(['q' => $searchTerm, 'per_page' => $perPage, 'page' => min($totalPages, $currentPage + 1)]); ?>"><i class="icon-chevron-right"></i></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="modal fade" id="categoryManagerModal" tabindex="-1" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered"><div class="modal-content">
                                        <form id="categoryManagerForm" enctype="multipart/form-data">
                                            <div class="modal-header"><h5 class="modal-title" id="categoryModalTitle">Add category</h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
                                            <div class="modal-body">
                                                <input type="hidden" id="categoryManagerId">
                                                <div id="categoryManagerMessage" class="alert" style="display:none"></div>
                                                <div class="mb-3"><label class="body-title" for="categoryManagerName">Category name <span class="tf-color-1">*</span></label><input class="form-control" id="categoryManagerName" name="category_name" required></div>
                                                <div><label class="body-title" for="categoryManagerImage">Category image <span class="text-tiny">(optional)</span></label><input class="form-control" id="categoryManagerImage" name="category_image" type="file" accept="image/jpeg,image/png,image/gif,image/webp"></div>
                                            </div>
                                            <div class="modal-footer"><button type="button" class="tf-button style-3" data-bs-dismiss="modal">Cancel</button><button type="submit" class="tf-button" id="categoryManagerSubmit">Save category</button></div>
                                        </form>
                                    </div></div>
                                </div>
                                <script>
                                document.addEventListener('DOMContentLoaded',function(){
                                    const modalElement=document.getElementById('categoryManagerModal'), modal=bootstrap.Modal.getOrCreateInstance(modalElement), form=document.getElementById('categoryManagerForm'), id=document.getElementById('categoryManagerId'), name=document.getElementById('categoryManagerName'), title=document.getElementById('categoryModalTitle'), submit=document.getElementById('categoryManagerSubmit'), message=document.getElementById('categoryManagerMessage');
                                    const showMessage=(text,type)=>{message.className='alert alert-'+type;message.textContent=text;message.style.display='block';};
                                    const open=(category)=>{form.reset();message.style.display='none';id.value=category?category.id:'';name.value=category?category.name:'';title.textContent=category?'Edit category':'Add category';submit.textContent=category?'Save changes':'Save category';modal.show();};
                                    document.getElementById('openCategoryModal').addEventListener('click',()=>open(null));
                                    document.addEventListener('click',async function(event){
                                        const edit=event.target.closest('.admin-edit-category');if(edit){open({id:edit.dataset.categoryId,name:edit.dataset.categoryName});return;}
                                        const remove=event.target.closest('.admin-delete-category');if(!remove||!confirm('Delete category "'+remove.dataset.categoryName+'"? It must have no products or subcategories.'))return;
                                        const payload=new FormData();payload.append('csrf_token',document.querySelector('meta[name="csrf-token"]').content);payload.append('delete_shop_category',JSON.stringify({category_id:Number(remove.dataset.categoryId)}));
                                        try{const response=await fetch('action.php',{method:'POST',body:payload,credentials:'same-origin'});const data=await response.json();if(!response.ok||data.status!=='success')throw new Error(data.message||'Unable to delete category.');location.reload();}catch(error){alert(error.message);}
                                    });
                                    form.addEventListener('submit',async function(event){event.preventDefault();const payload=new FormData(form), editing=Number(id.value)>0;payload.append('csrf_token',document.querySelector('meta[name="csrf-token"]').content);payload.append(editing?'update_shop_category':'add_shop_category',JSON.stringify(editing?{category_id:Number(id.value),category:name.value.trim()}:{category:name.value.trim()}));submit.disabled=true;try{const response=await fetch('action.php',{method:'POST',body:payload,credentials:'same-origin'});const data=await response.json();if(!response.ok||data.status!=='success')throw new Error(data.message||'Unable to save category.');location.reload();}catch(error){showMessage(error.message,'danger');}finally{submit.disabled=false;}});
                                });
                                </script>
                                <!-- /all-category -->
                            </div>
                            <!-- /main-content-wrap -->
                        </div>
                        <!-- /main-content-wrap -->
                        <?php include __DIR__ . '/includes/footer.php'; ?>
