<?php
// Retired combined product page. Keep this lightweight redirect for bookmarks.
$productId = max(0, (int)($_GET['edit_product_id'] ?? 0));
header('Location: ' . ($productId ? 'product-edit.php?id=' . $productId : 'product-list.php'), true, 302);
exit;
