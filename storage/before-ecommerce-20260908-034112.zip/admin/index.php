<?php
require_once __DIR__ . '/includes/bootstrap.php';

$currentMonthKey = date('Y-m');
$requestedMonthKey = isset($_GET['month']) ? trim((string)$_GET['month']) : '';
$selectedMonthKey = preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $requestedMonthKey) ? $requestedMonthKey : $currentMonthKey;
if($selectedMonthKey > $currentMonthKey){
    $selectedMonthKey = $currentMonthKey;
}
$selectedMonthStart = $selectedMonthKey . '-01';
$selectedMonthEnd = date('Y-m-d', strtotime($selectedMonthStart . ' +1 month'));
$previousMonthStart = date('Y-m-d', strtotime($selectedMonthStart . ' -1 month'));
$previousMonthKey = date('Y-m', strtotime($previousMonthStart));
$nextMonthKey = date('Y-m', strtotime($selectedMonthStart . ' +1 month'));
$selectedMonthLabel = date('F Y', strtotime($selectedMonthStart));
$isCurrentDashboardMonth = $selectedMonthKey === $currentMonthKey;
$selectedChartDays = $isCurrentDashboardMonth ? (int)date('j') : (int)date('t', strtotime($selectedMonthStart));
$selectedMonthSqlStart = mysqli_real_escape_string($conn, $selectedMonthStart);
$selectedMonthSqlEnd = mysqli_real_escape_string($conn, $selectedMonthEnd);
$previousMonthSqlStart = mysqli_real_escape_string($conn, $previousMonthStart);

$dashboardTotals = [
    'sales_count' => 0,
    'total_income' => 0.0,
    'orders_paid' => 0,
    'visitors' => 0
];
$topProducts = [];
$recentOrders = [];

$totalSalesQuery = mysqli_query($conn, "SELECT COALESCE(SUM(oi.quantity), 0) AS total FROM shop_order_items oi INNER JOIN shop_orders so ON so.order_id = oi.order_id WHERE so.order_status <> 'cancelled' AND so.created_at >= '$selectedMonthSqlStart' AND so.created_at < '$selectedMonthSqlEnd'");
if($totalSalesQuery){
    $row = mysqli_fetch_assoc($totalSalesQuery);
    $dashboardTotals['sales_count'] = (int)($row['total'] ?? 0);
}
$totalIncomeQuery = mysqli_query($conn, "SELECT COALESCE(SUM(total_amount), 0) AS total FROM shop_orders WHERE order_status <> 'cancelled' AND created_at >= '$selectedMonthSqlStart' AND created_at < '$selectedMonthSqlEnd'");
if($totalIncomeQuery){
    $row = mysqli_fetch_assoc($totalIncomeQuery);
    $dashboardTotals['total_income'] = (float)($row['total'] ?? 0);
}
$paidOrdersQuery = mysqli_query($conn, "SELECT COUNT(*) AS total FROM shop_orders WHERE order_status = 'fulfilled' AND created_at >= '$selectedMonthSqlStart' AND created_at < '$selectedMonthSqlEnd'");
if($paidOrdersQuery){
    $row = mysqli_fetch_assoc($paidOrdersQuery);
    $dashboardTotals['orders_paid'] = (int)($row['total'] ?? 0);
}
$trafficViewsTable = mysqli_query($conn, "SHOW TABLES LIKE 'site_traffic_page_views'");
$hasTrafficViews = $trafficViewsTable && mysqli_num_rows($trafficViewsTable) > 0;
$visitorQuery = $hasTrafficViews
    ? mysqli_query($conn, "SELECT COUNT(DISTINCT tracker) AS total FROM site_traffic_page_views WHERE viewed_at >= '$selectedMonthSqlStart' AND viewed_at < '$selectedMonthSqlEnd'")
    : mysqli_query($conn, "SELECT COUNT(DISTINCT tracker) AS total FROM site_visit_logs WHERE visit_date >= '$selectedMonthSqlStart' AND visit_date < '$selectedMonthSqlEnd'");
if($visitorQuery){
    $row = mysqli_fetch_assoc($visitorQuery);
    $dashboardTotals['visitors'] = (int)($row['total'] ?? 0);
}

$topProductsSql = "
    SELECT p.product_id, p.product_name, p.product_link, p.selling_price, p.was_selling_price,
           COALESCE(st.stock_qty, 0) AS stock_qty,
           COALESCE(SUM(CASE WHEN oi.item_type = 'product' THEN oi.quantity ELSE 0 END), 0) AS sold_qty
    FROM my_shop_products p
    LEFT JOIN (
        SELECT product_id, SUM(stock_qty) AS stock_qty
        FROM my_shop_stock
        GROUP BY product_id
    ) st ON st.product_id = p.product_id
    LEFT JOIN shop_order_items oi ON oi.item_type = 'product' AND oi.item_ref_id = p.product_id
    GROUP BY p.product_id, p.product_name, p.product_link, p.selling_price, p.was_selling_price, st.stock_qty, p.last_modified
    ORDER BY sold_qty DESC, p.last_modified DESC
    LIMIT 5
";
$topProductsQuery = mysqli_query($conn, $topProductsSql);
if($topProductsQuery){
    while($row = mysqli_fetch_assoc($topProductsQuery)){
        $topProducts[] = $row;
    }
}

$recentOrdersSql = "
    SELECT so.order_id, so.total_amount, so.created_at,
           COALESCE(oi.item_name, CONCAT('Order #', so.order_id)) AS item_name, p.product_link
    FROM shop_orders so
    LEFT JOIN (
        SELECT i1.order_id, i1.item_name, i1.item_type, i1.item_ref_id
        FROM shop_order_items i1
        INNER JOIN (
            SELECT order_id, MIN(item_id) AS first_item
            FROM shop_order_items
            GROUP BY order_id
        ) pick ON pick.first_item = i1.item_id
    ) oi ON oi.order_id = so.order_id
    LEFT JOIN my_shop_products p ON oi.item_type = 'product' AND p.product_id = oi.item_ref_id
    ORDER BY so.created_at DESC
    LIMIT 5
";
$recentOrdersQuery = mysqli_query($conn, $recentOrdersSql);
if($recentOrdersQuery){
    while($row = mysqli_fetch_assoc($recentOrdersQuery)){
        $recentOrders[] = $row;
    }
}

$fulfillmentQueue = [];
$fulfillmentQueueSql = "
    SELECT so.order_id, so.customer_name, so.item_count, so.total_amount, so.order_status, so.created_at,
           COALESCE(first_item.item_name, CONCAT('Order #', so.order_id)) AS item_name,
           first_item.item_type, first_item.item_ref_id, p.product_link
    FROM shop_orders so
    LEFT JOIN (
        SELECT oi.order_id, oi.item_name, oi.item_type, oi.item_ref_id
        FROM shop_order_items oi
        INNER JOIN (SELECT order_id, MIN(item_id) AS first_item_id FROM shop_order_items GROUP BY order_id) pick
            ON pick.order_id = oi.order_id AND pick.first_item_id = oi.item_id
    ) first_item ON first_item.order_id = so.order_id
    LEFT JOIN my_shop_products p ON first_item.item_type = 'product' AND p.product_id = first_item.item_ref_id
    WHERE so.order_status IN ('pending', 'fulfilled')
    ORDER BY CASE WHEN so.order_status = 'pending' THEN 0 ELSE 1 END, so.created_at DESC
    LIMIT 6
";
$fulfillmentQueueQuery = mysqli_query($conn, $fulfillmentQueueSql);
if ($fulfillmentQueueQuery) {
    while ($row = mysqli_fetch_assoc($fulfillmentQueueQuery)) {
        $fulfillmentQueue[] = $row;
    }
}

$lowStockAlerts = [];
$lowStockSql = "
    SELECT p.product_id, p.product_name, p.product_link, COALESCE(SUM(st.stock_qty), 0) AS stock_qty, MAX(st.last_modified) AS stock_updated_at
    FROM my_shop_products p
    LEFT JOIN my_shop_stock st ON st.product_id = p.product_id
    GROUP BY p.product_id, p.product_name, p.product_link
    HAVING COALESCE(SUM(st.stock_qty), 0) <= 5
    ORDER BY stock_qty ASC, p.product_name ASC
    LIMIT 6
";
$lowStockQuery = mysqli_query($conn, $lowStockSql);
if ($lowStockQuery) {
    while ($row = mysqli_fetch_assoc($lowStockQuery)) {
        $lowStockAlerts[] = $row;
    }
}


$productOverview = [];
$productOverviewSql = "
    SELECT p.product_id, p.product_name, p.product_link, p.selling_price,
           COALESCE(st.stock_qty, 0) AS stock_qty,
           COALESCE(SUM(oi.quantity), 0) AS sold_qty,
           COALESCE(SUM(oi.total_price), 0) AS gross_sales
    FROM my_shop_products p
    LEFT JOIN (
        SELECT product_id, SUM(stock_qty) AS stock_qty
        FROM my_shop_stock
        GROUP BY product_id
    ) st ON st.product_id = p.product_id
    LEFT JOIN shop_order_items oi ON oi.item_type = 'product' AND oi.item_ref_id = p.product_id
    GROUP BY p.product_id, p.product_name, p.product_link, p.selling_price, st.stock_qty, p.last_modified
    ORDER BY p.last_modified DESC
    LIMIT 5
";
$productOverviewQuery = mysqli_query($conn, $productOverviewSql);
if($productOverviewQuery){
    while($row = mysqli_fetch_assoc($productOverviewQuery)){
        $productOverview[] = $row;
    }
}

$newComments = [];
$newCommentsSql = "
    SELECT bc.comment, bc.published_by, bc.last_modified, b.blog_title
    FROM blogs_comments bc
    LEFT JOIN blogs b ON b.blog_id = bc.blog_id
    ORDER BY bc.last_modified DESC
    LIMIT 8
";
$newCommentsQuery = mysqli_query($conn, $newCommentsSql);
if($newCommentsQuery){
    while($row = mysqli_fetch_assoc($newCommentsQuery)){
        $newComments[] = $row;
    }
}

$earningsRevenue = $dashboardTotals['total_income'];
// Profit requires verified product cost data. Do not estimate it from revenue.
$earningsProfit = null;

// Compare the selected calendar month with the immediately preceding month.
$dashboardTrends = ['sales' => 0.0, 'income' => 0.0, 'fulfilled' => 0.0, 'visitors' => 0.0];
$trendSql = "
    SELECT
        COALESCE(SUM(CASE WHEN so.created_at >= '$selectedMonthSqlStart' AND so.created_at < '$selectedMonthSqlEnd' THEN so.item_count ELSE 0 END), 0) AS current_sales,
        COALESCE(SUM(CASE WHEN so.created_at >= '$previousMonthSqlStart' AND so.created_at < '$selectedMonthSqlStart' THEN so.item_count ELSE 0 END), 0) AS previous_sales,
        COALESCE(SUM(CASE WHEN so.created_at >= '$selectedMonthSqlStart' AND so.created_at < '$selectedMonthSqlEnd' THEN so.total_amount ELSE 0 END), 0) AS current_income,
        COALESCE(SUM(CASE WHEN so.created_at >= '$previousMonthSqlStart' AND so.created_at < '$selectedMonthSqlStart' THEN so.total_amount ELSE 0 END), 0) AS previous_income,
        COALESCE(SUM(CASE WHEN so.created_at >= '$selectedMonthSqlStart' AND so.created_at < '$selectedMonthSqlEnd' AND so.order_status = 'fulfilled' THEN 1 ELSE 0 END), 0) AS current_fulfilled,
        COALESCE(SUM(CASE WHEN so.created_at >= '$previousMonthSqlStart' AND so.created_at < '$selectedMonthSqlStart' AND so.order_status = 'fulfilled' THEN 1 ELSE 0 END), 0) AS previous_fulfilled
    FROM shop_orders so
    WHERE so.order_status <> 'cancelled' AND so.created_at >= '$previousMonthSqlStart' AND so.created_at < '$selectedMonthSqlEnd'
";
$trendQuery = mysqli_query($conn, $trendSql);
if ($trendQuery && ($trendRow = mysqli_fetch_assoc($trendQuery))) {
    foreach ([['sales', 'current_sales', 'previous_sales'], ['income', 'current_income', 'previous_income'], ['fulfilled', 'current_fulfilled', 'previous_fulfilled']] as $trendDefinition) {
        [$trendKey, $currentKey, $previousKey] = $trendDefinition;
        $previousValue = (float)($trendRow[$previousKey] ?? 0);
        $currentValue = (float)($trendRow[$currentKey] ?? 0);
        $dashboardTrends[$trendKey] = $previousValue > 0 ? (($currentValue - $previousValue) / $previousValue) * 100 : 0.0;
    }
}
$visitorTrendQuery = $hasTrafficViews
    ? mysqli_query($conn, "SELECT COUNT(DISTINCT CASE WHEN viewed_at >= '$selectedMonthSqlStart' AND viewed_at < '$selectedMonthSqlEnd' THEN tracker END) AS current_visitors, COUNT(DISTINCT CASE WHEN viewed_at >= '$previousMonthSqlStart' AND viewed_at < '$selectedMonthSqlStart' THEN tracker END) AS previous_visitors FROM site_traffic_page_views WHERE viewed_at >= '$previousMonthSqlStart' AND viewed_at < '$selectedMonthSqlEnd'")
    : mysqli_query($conn, "SELECT COUNT(DISTINCT CASE WHEN visit_date >= '$selectedMonthSqlStart' AND visit_date < '$selectedMonthSqlEnd' THEN tracker END) AS current_visitors, COUNT(DISTINCT CASE WHEN visit_date >= '$previousMonthSqlStart' AND visit_date < '$selectedMonthSqlStart' THEN tracker END) AS previous_visitors FROM site_visit_logs WHERE visit_date >= '$previousMonthSqlStart' AND visit_date < '$selectedMonthSqlEnd'");
if ($visitorTrendQuery && ($visitorTrendRow = mysqli_fetch_assoc($visitorTrendQuery))) {
    $previousVisitors = (float)($visitorTrendRow['previous_visitors'] ?? 0);
    $currentVisitors = (float)($visitorTrendRow['current_visitors'] ?? 0);
    $dashboardTrends['visitors'] = $previousVisitors > 0 ? (($currentVisitors - $previousVisitors) / $previousVisitors) * 100 : 0.0;
}
$trendText = static function (string $key) use (&$dashboardTrends): string {
    return number_format((float)($dashboardTrends[$key] ?? 0), 2) . '%';
};
$trendClass = static function (string $key) use (&$dashboardTrends): string {
    $value = (float)($dashboardTrends[$key] ?? 0);
    return $value > 0 ? 'up' : ($value < 0 ? 'down' : '');
};
$trendIcon = static function (string $key) use (&$dashboardTrends): string {
    return (float)($dashboardTrends[$key] ?? 0) < 0 ? 'icon-trending-down' : 'icon-trending-up';
};

$dashboardChartData = [
    'sales' => array_fill(0, $selectedChartDays, 0),
    'income' => array_fill(0, $selectedChartDays, 0),
    'fulfilled' => array_fill(0, $selectedChartDays, 0),
    'visitors' => array_fill(0, $selectedChartDays, 0),
    'monthlyRevenue' => array_fill(0, 12, 0),
    'earningsRevenue' => array_fill(0, 8, 0),
    'earningsProfit' => array_fill(0, 8, 0),
    'monthLabels' => []
];
$dailyKeys = [];
for($dayNumber = 1; $dayNumber <= $selectedChartDays; $dayNumber++){
    $dailyKeys[sprintf('%s-%02d', $selectedMonthKey, $dayNumber)] = $dayNumber - 1;
}
$dailyOrderQuery = mysqli_query($conn, "
    SELECT DATE(so.created_at) AS activity_date,
           COALESCE(SUM(so.item_count), 0) AS sales_count,
           COALESCE(SUM(CASE WHEN so.order_status <> 'cancelled' THEN so.total_amount ELSE 0 END), 0) AS income,
           SUM(CASE WHEN so.order_status = 'fulfilled' THEN 1 ELSE 0 END) AS fulfilled_count
    FROM shop_orders so
    WHERE so.created_at >= '$selectedMonthSqlStart' AND so.created_at < '$selectedMonthSqlEnd'
    GROUP BY DATE(so.created_at)
");
while($dailyOrderQuery && ($chartRow = mysqli_fetch_assoc($dailyOrderQuery))){
    $chartDate = (string)($chartRow['activity_date'] ?? '');
    if(isset($dailyKeys[$chartDate])){
        $chartIndex = $dailyKeys[$chartDate];
        $dashboardChartData['sales'][$chartIndex] = (float)($chartRow['sales_count'] ?? 0);
        $dashboardChartData['income'][$chartIndex] = (float)($chartRow['income'] ?? 0);
        $dashboardChartData['fulfilled'][$chartIndex] = (int)($chartRow['fulfilled_count'] ?? 0);
    }
}
$visitTableCheck = $hasTrafficViews ? $trafficViewsTable : mysqli_query($conn, "SHOW TABLES LIKE 'site_visit_logs'");
if($visitTableCheck && mysqli_num_rows($visitTableCheck) > 0){
    $dailyVisitQuery = $hasTrafficViews
        ? mysqli_query($conn, "SELECT DATE(viewed_at) AS visit_date, COUNT(DISTINCT tracker) AS visitors FROM site_traffic_page_views WHERE viewed_at >= '$selectedMonthSqlStart' AND viewed_at < '$selectedMonthSqlEnd' GROUP BY DATE(viewed_at)")
        : mysqli_query($conn, "SELECT visit_date, COUNT(DISTINCT tracker) AS visitors FROM site_visit_logs WHERE visit_date >= '$selectedMonthSqlStart' AND visit_date < '$selectedMonthSqlEnd' GROUP BY visit_date");
    while($dailyVisitQuery && ($chartRow = mysqli_fetch_assoc($dailyVisitQuery))){
        $chartDate = date('Y-m-d', strtotime((string)($chartRow['visit_date'] ?? '')));
        if(isset($dailyKeys[$chartDate])){
            $dashboardChartData['visitors'][$dailyKeys[$chartDate]] = (int)($chartRow['visitors'] ?? 0);
        }
    }
}
for($monthOffset = 11; $monthOffset >= 0; $monthOffset--){
    $monthDate = strtotime($selectedMonthStart . " -{$monthOffset} months");
    $dashboardChartData['monthLabels'][] = date('M', $monthDate);
}
$monthlyRevenueStart = date('Y-m-d', strtotime($selectedMonthStart . ' -11 months'));
$monthlyRevenueStartSql = mysqli_real_escape_string($conn, $monthlyRevenueStart);
$monthlyOrderQuery = mysqli_query($conn, "SELECT DATE_FORMAT(created_at, '%Y-%m') AS activity_month, COALESCE(SUM(total_amount), 0) AS revenue FROM shop_orders WHERE order_status <> 'cancelled' AND created_at >= '$monthlyRevenueStartSql' AND created_at < '$selectedMonthSqlEnd' GROUP BY DATE_FORMAT(created_at, '%Y-%m')");
$monthlyRevenueMap = [];
while($monthlyOrderQuery && ($chartRow = mysqli_fetch_assoc($monthlyOrderQuery))){ $monthlyRevenueMap[(string)$chartRow['activity_month']] = (float)$chartRow['revenue']; }
for($monthOffset = 11; $monthOffset >= 0; $monthOffset--){
    $monthKey = date('Y-m', strtotime($selectedMonthStart . " -{$monthOffset} months"));
    $dashboardChartData['monthlyRevenue'][11 - $monthOffset] = $monthlyRevenueMap[$monthKey] ?? 0;
}
$dashboardChartData['earningsRevenue'] = array_slice($dashboardChartData['monthlyRevenue'], -8);
$dashboardChartData['earningsLabels'] = array_slice($dashboardChartData['monthLabels'], -8);

$dashboardPanelData = [
    'hasComments' => !empty($newComments),
    'products' => array_map(static function (array $product): array {
        return [
            'id' => (int)($product['product_id'] ?? 0),
            'name' => (string)($product['product_name'] ?? 'Untitled product'),
            'image' => jd_admin_image_url($product['product_link'] ?? ''),
            'price' => (float)($product['selling_price'] ?? 0),
            'wasPrice' => (float)($product['was_selling_price'] ?? 0),
            'quantity' => (float)($product['stock_qty'] ?? 0),
            'sold' => (float)($product['sold_qty'] ?? 0),
            'revenue' => (float)($product['gross_sales'] ?? 0),
        ];
    }, $productOverview),
];
?>

<?php include __DIR__ . '/includes/head.php'; ?>

<?php include __DIR__ . '/includes/sidenav.php'; ?>
                <!-- section-content-right -->
                <div class="section-content-right">
                    <?php include __DIR__ . '/includes/topbar.php'; ?>
                    <!-- main-content -->
                    <div class="main-content">
                        <!-- main-content-wrap -->
                        <div class="main-content-inner">
                            <!-- main-content-wrap -->
                            <div class="main-content-wrap">
                                <div class="jd-dashboard-month-bar mb-20">
                                    <div>
                                        <span class="jd-dashboard-month-bar__eyebrow">Dashboard period</span>
                                        <h4><?php echo jd_admin_h($selectedMonthLabel); ?></h4>
                                        <small>Summary totals and mini charts for this calendar month</small>
                                    </div>
                                    <nav class="jd-dashboard-month-bar__nav" aria-label="Dashboard month navigation">
                                        <a href="index.php?month=<?php echo rawurlencode($previousMonthKey); ?>" aria-label="View <?php echo jd_admin_h(date('F Y', strtotime($previousMonthStart))); ?>" title="Previous month"><i class="icon-chevron-left"></i></a>
                                        <?php if(!$isCurrentDashboardMonth): ?><a class="jd-dashboard-month-bar__current" href="index.php">Current month</a><?php endif; ?>
                                        <?php if($nextMonthKey <= $currentMonthKey): ?>
                                            <a href="index.php?month=<?php echo rawurlencode($nextMonthKey); ?>" aria-label="View <?php echo jd_admin_h(date('F Y', strtotime($selectedMonthStart . ' +1 month'))); ?>" title="Next month"><i class="icon-chevron-right"></i></a>
                                        <?php else: ?>
                                            <span class="is-disabled" aria-disabled="true" title="No future data"><i class="icon-chevron-right"></i></span>
                                        <?php endif; ?>
                                    </nav>
                                </div>
                                <style>
                                    .jd-dashboard-month-bar{display:flex;align-items:center;justify-content:space-between;gap:20px;padding:16px 18px;background:#fff;border:1px solid #e7edf5;border-radius:12px}.jd-dashboard-month-bar__eyebrow{display:block;margin-bottom:3px;color:#7b8798;font-size:10px;font-weight:700;letter-spacing:.07em;text-transform:uppercase}.jd-dashboard-month-bar h4{margin:0;color:#17243a;font-size:20px}.jd-dashboard-month-bar small{display:block;margin-top:3px;color:#7b8798;font-size:11px}.jd-dashboard-month-bar__nav{display:flex;align-items:center;gap:8px}.jd-dashboard-month-bar__nav a,.jd-dashboard-month-bar__nav span{display:inline-flex;min-width:38px;height:38px;align-items:center;justify-content:center;color:#344054;background:#f6f8fb;border:1px solid #e4e9f0;border-radius:8px}.jd-dashboard-month-bar__nav a:hover{color:#fff;background:#2377fc;border-color:#2377fc}.jd-dashboard-month-bar__nav .jd-dashboard-month-bar__current{padding:0 13px;color:#2377fc;background:#eef5ff;font-size:11px;font-weight:700}.jd-dashboard-month-bar__nav .is-disabled{color:#b7c0cc;cursor:not-allowed}@media(max-width:575px){.jd-dashboard-month-bar{align-items:flex-start;flex-direction:column}.jd-dashboard-month-bar__nav{width:100%;justify-content:space-between}}
                                </style>
                                <div class="tf-section-4 mb-30">
                                    <!-- chart-default -->
                                    <div class="wg-chart-default">
                                        <div class="flex items-center justify-between">
                                            <div class="flex items-center gap14">
                                                <div class="image type-white">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="48" height="52" viewBox="0 0 48 52" fill="none">
                                                        <path d="M19.1094 2.12943C22.2034 0.343099 26.0154 0.343099 29.1094 2.12943L42.4921 9.85592C45.5861 11.6423 47.4921 14.9435 47.4921 18.5162V33.9692C47.4921 37.5418 45.5861 40.8431 42.4921 42.6294L29.1094 50.3559C26.0154 52.1423 22.2034 52.1423 19.1094 50.3559L5.72669 42.6294C2.63268 40.8431 0.726688 37.5418 0.726688 33.9692V18.5162C0.726688 14.9435 2.63268 11.6423 5.72669 9.85592L19.1094 2.12943Z" fill="#22C55E"/>
                                                    </svg>
                                                    <i class="icon-shopping-bag"></i>
                                                </div>
                                                <div>
                                                    <div class="body-text mb-2">Total Sales</div>
                                                    <h4><?php echo number_format($dashboardTotals['sales_count']); ?></h4>
                                                </div>
                                            </div>
                                            <div class="box-icon-trending <?php echo $trendClass('sales'); ?>">
                                                <i class="<?php echo $trendIcon('sales'); ?>"></i>
                                                <div class="body-title number"><?php echo $trendText('sales'); ?></div>
                                            </div>
                                        </div>
                                        <div class="wrap-chart">
                                            <div id="line-chart-1"></div>
                                        </div>
                                    </div>
                                    <!-- /chart-default -->
                                    <!-- chart-default -->
                                    <div class="wg-chart-default">
                                        <div class="flex items-center justify-between">
                                            <div class="flex items-center gap14">
                                                <div class="image type-white">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="48" height="52" viewBox="0 0 48 52" fill="none">
                                                        <path d="M19.1094 2.12943C22.2034 0.343099 26.0154 0.343099 29.1094 2.12943L42.4921 9.85592C45.5861 11.6423 47.4921 14.9435 47.4921 18.5162V33.9692C47.4921 37.5418 45.5861 40.8431 42.4921 42.6294L29.1094 50.3559C26.0154 52.1423 22.2034 52.1423 19.1094 50.3559L5.72669 42.6294C2.63268 40.8431 0.726688 37.5418 0.726688 33.9692V18.5162C0.726688 14.9435 2.63268 11.6423 5.72669 9.85592L19.1094 2.12943Z" fill="#FF5200"/>
                                                    </svg>
                                                    <i class="icon-credit-card"></i>
                                                </div>
                                                <div>
                                                    <div class="body-text mb-2">Total Income</div>
                                                    <h4>KSh <?php echo number_format($dashboardTotals['total_income'], 2); ?></h4>
                                                </div>
                                            </div>
                                            <div class="box-icon-trending <?php echo $trendClass('income'); ?>">
                                                <i class="<?php echo $trendIcon('income'); ?>"></i>
                                                <div class="body-title number"><?php echo $trendText('income'); ?></div>
                                            </div>
                                        </div>
                                        <div class="wrap-chart">
                                            <div id="line-chart-2"></div>
                                        </div>
                                    </div>
                                    <!-- /chart-default -->
                                    <!-- chart-default -->
                                    <div class="wg-chart-default">
                                        <div class="flex items-center justify-between">
                                            <div class="flex items-center gap14">
                                                <div class="image type-white">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="48" height="52" viewBox="0 0 48 52" fill="none">
                                                        <path d="M19.1094 2.12943C22.2034 0.343099 26.0154 0.343099 29.1094 2.12943L42.4921 9.85592C45.5861 11.6423 47.4921 14.9435 47.4921 18.5162V33.9692C47.4921 37.5418 45.5861 40.8431 42.4921 42.6294L29.1094 50.3559C26.0154 52.1423 22.2034 52.1423 19.1094 50.3559L5.72669 42.6294C2.63268 40.8431 0.726688 37.5418 0.726688 33.9692V18.5162C0.726688 14.9435 2.63268 11.6423 5.72669 9.85592L19.1094 2.12943Z" fill="#CBD5E1"/>
                                                    </svg>
                                                    <i class="icon-file"></i>
                                                </div>
                                                <div>
                                                    <div class="body-text mb-2">Orders Paid</div>
                                                    <h4><?php echo number_format($dashboardTotals['orders_paid']); ?></h4>
                                                </div>
                                            </div>
                                            <div class="box-icon-trending <?php echo $trendClass('fulfilled'); ?>">
                                                <i class="<?php echo $trendIcon('fulfilled'); ?>"></i>
                                                <div class="body-title number"><?php echo $trendText('fulfilled'); ?></div>
                                            </div>
                                        </div>
                                        <div class="wrap-chart">
                                            <div id="line-chart-3"></div>
                                        </div>
                                    </div>
                                    <!-- /chart-default -->
                                    <!-- chart-default -->
                                    <div class="wg-chart-default">
                                        <div class="flex items-center justify-between">
                                            <div class="flex items-center gap14">
                                                <div class="image type-white">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="48" height="52" viewBox="0 0 48 52" fill="none">
                                                        <path d="M19.1094 2.12943C22.2034 0.343099 26.0154 0.343099 29.1094 2.12943L42.4921 9.85592C45.5861 11.6423 47.4921 14.9435 47.4921 18.5162V33.9692C47.4921 37.5418 45.5861 40.8431 42.4921 42.6294L29.1094 50.3559C26.0154 52.1423 22.2034 52.1423 19.1094 50.3559L5.72669 42.6294C2.63268 40.8431 0.726688 37.5418 0.726688 33.9692V18.5162C0.726688 14.9435 2.63268 11.6423 5.72669 9.85592L19.1094 2.12943Z" fill="#2377FC"/>
                                                    </svg>
                                                    <i class="icon-users"></i>
                                                </div>
                                                <div>
                                                    <div class="body-text mb-2">Total Visitors</div>
                                                    <h4><?php echo number_format($dashboardTotals['visitors']); ?></h4>
                                                </div>
                                            </div>
                                            <div class="box-icon-trending <?php echo $trendClass('visitors'); ?>">
                                                <i class="<?php echo $trendIcon('visitors'); ?>"></i>
                                                <div class="body-title number"><?php echo $trendText('visitors'); ?></div>
                                            </div>
                                        </div>
                                        <div class="wrap-chart">
                                            <div id="line-chart-4"></div>
                                        </div>
                                    </div>
                                    <!-- /chart-default -->
                                </div>
                                <div class="tf-section-5 mb-30">
                                    <!-- chart -->
                                    <div class="wg-box">
                                        <div class="flex items-center justify-between">
                                            <h5>Recent Order</h5>
                                            <div class="dropdown default">
                                                <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                   <span class="icon-more"><i class="icon-more-horizontal"></i></span>
                                                </button>
                                                <ul class="dropdown-menu dropdown-menu-end">
                                                    <li>  
                                                        <a href="javascript:void(0);">This Week</a>
                                                    </li>
                                                    <li>  
                                                        <a href="javascript:void(0);">Last Week</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div id="line-chart-5"></div>
                                    </div>
                                    <!-- /chart -->
                                    <!-- top-product -->
                                    <div class="wg-box">
                                        <div class="flex items-center justify-between">
                                            <h5>Top Products</h5>
                                            <div class="dropdown default">
                                                <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <span class="view-all">View all<i class="icon-chevron-down"></i></span>
                                                </button>
                                                <ul class="dropdown-menu dropdown-menu-end">
                                                    <li>  
                                                        <a href="javascript:void(0);">3 days</a>
                                                    </li>
                                                    <li>  
                                                        <a href="javascript:void(0);">7 days</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="wg-table table-top-product">
                                            <ul class="flex flex-column gap14">
                                                <?php if(empty($topProducts)): ?>
                                                <li class="product-item">
                                                    <div class="flex items-center justify-between flex-grow">
                                                        <div class="name"><span class="body-title-2">No products found.</span></div>
                                                    </div>
                                                </li>
                                                <?php else: ?>
                                                <?php foreach($topProducts as $product): ?>
                                                <?php
                                                    $productName = jd_admin_h($product['product_name'] ?? 'Untitled product');
                                                    $stockQty = (float)($product['stock_qty'] ?? 0);
                                                    $soldQty = (float)($product['sold_qty'] ?? 0);
                                                    $price = (float)($product['selling_price'] ?? 0);
                                                    $wasPrice = isset($product['was_selling_price']) && $product['was_selling_price'] !== null ? (float)$product['was_selling_price'] : 0;
                                                    $sale = ($wasPrice > $price && $wasPrice > 0) ? round((($wasPrice - $price) / $wasPrice) * 100) : 0;
                                                    $productImage = jd_admin_image_url($product['product_link'] ?? '');
                                                ?>
                                                <li class="product-item">
                                                    <div class="image">
                                                        <?php if($productImage !== ''): ?><img data-product-image src="<?php echo jd_admin_h($productImage); ?>" alt="<?php echo $productName; ?>"><?php else: ?><i class="icon-image"></i><?php endif; ?>
                                                    </div>
                                                    <div class="flex items-center justify-between flex-grow">
                                                        <div class="name">
                                                            <a href="product-list.php" class="body-title-2"><?php echo $productName; ?></a>
                                                            <div class="text-tiny mt-3"><?php echo number_format($soldQty, 0); ?> sold · <?php echo number_format($stockQty, 0); ?> in stock</div>
                                                        </div>
                                                        <div>
                                                            <div class="text-tiny mb-3">Product ID</div>
                                                            <div class="body-text">#<?php echo (int)($product['product_id'] ?? 0); ?></div>
                                                        </div>
                                                        <div class="country">
                                                            <img src="images/country/2.png" alt="">
                                                        </div>
                                                        <div>
                                                            <div class="body-title-2 mb-3">-<?php echo (int)$sale; ?>%</div>
                                                            <div class="text-tiny">KSh <?php echo number_format($price, 2); ?></div>
                                                        </div>
                                                    </div>
                                                </li>
                                                <?php endforeach; ?>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                    <!-- /top-product -->
                                    <!-- top-countries -->
                                    <div class="wg-box">
                                        <div class="flex items-center justify-between">
                                            <h5>Top Countries By Sales</h5>
                                            <div class="dropdown default">
                                                <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <span class="view-all">View all<i class="icon-chevron-down"></i></span>
                                                </button>
                                                <ul class="dropdown-menu dropdown-menu-end">
                                                    <li>  
                                                        <a href="javascript:void(0);">3 days</a>
                                                    </li>
                                                    <li>  
                                                        <a href="javascript:void(0);">7 days</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="flex items-center gap10">
                                            <h4 id="dashboard-country-total">KSh 0.00</h4>
                                            <div class="box-icon-trending up">
                                                <i class="icon-trending-up"></i>
                                                <div class="body-title number">0.00%</div>
                                            </div>
                                            <div class="text-tiny">since last weekend</div>
                                        </div>
                                        <ul id="dashboard-country-list" class="flex flex-column justify-between gap10 h-full">
                                            <li class="country-item">
                                                <div class="image">
                                                    <img src="images/country/6.png" alt="">
                                                </div>
                                                <div class="flex-grow flex items-center justify-between">
                                                    <div class="body-text name">Turkish Flag</div>
                                                    <div class="box-icon-trending up">
                                                        <i class="icon-trending-up"></i>
                                                    </div>
                                                    <div class="body-text number">6,972</div>
                                                </div>
                                            </li>
                                            <li class="country-item">
                                                <div class="image">
                                                    <img src="images/country/7.png" alt="">
                                                </div>
                                                <div class="flex-grow flex items-center justify-between">
                                                    <div class="body-text name">Belgium</div>
                                                    <div class="box-icon-trending up">
                                                        <i class="icon-trending-up"></i>
                                                    </div>
                                                    <div class="body-text number">6,972</div>
                                                </div>
                                            </li>
                                            <li class="country-item">
                                                <div class="image">
                                                    <img src="images/country/8.png" alt="">
                                                </div>
                                                <div class="flex-grow flex items-center justify-between">
                                                    <div class="body-text name">Sweden</div>
                                                    <div class="box-icon-trending down">
                                                        <i class="icon-trending-down"></i>
                                                    </div>
                                                    <div class="body-text number">6,972</div>
                                                </div>
                                            </li>
                                            <li class="country-item">
                                                <div class="image">
                                                    <img src="images/country/9.png" alt="">
                                                </div>
                                                <div class="flex-grow flex items-center justify-between">
                                                    <div class="body-text name">Vietnamese</div>
                                                    <div class="box-icon-trending up">
                                                        <i class="icon-trending-up"></i>
                                                    </div>
                                                    <div class="body-text number">6,972</div>
                                                </div>
                                            </li>
                                            <li class="country-item">
                                                <div class="image">
                                                    <img src="images/country/10.png" alt="">
                                                </div>
                                                <div class="flex-grow flex items-center justify-between">
                                                    <div class="body-text name">Australia</div>
                                                    <div class="box-icon-trending down">
                                                        <i class="icon-trending-down"></i>
                                                    </div>
                                                    <div class="body-text number">6,972</div>
                                                </div>
                                            </li>
                                            <li class="country-item">
                                                <div class="image">
                                                    <img src="images/country/11.png" alt="">
                                                </div>
                                                <div class="flex-grow flex items-center justify-between">
                                                    <div class="body-text name">Saudi Arabia</div>
                                                    <div class="box-icon-trending down">
                                                        <i class="icon-trending-down"></i>
                                                    </div>
                                                    <div class="body-text number">6,972</div>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                    <!-- /top-countries -->
                                </div>
                                <div class="tf-section-6 mb-30">
                                    <!-- best-shop-sellers -->
                                    <div class="wg-box">
                                        <div class="flex items-center justify-between">
                                            <h5>Best Shop Sellers</h5>
                                            <div class="dropdown default">
                                                <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <span class="view-all">View all<i class="icon-chevron-down"></i></span>
                                                </button>
                                                <ul class="dropdown-menu dropdown-menu-end">
                                                    <li>  
                                                        <a href="javascript:void(0);">3 days</a>
                                                    </li>
                                                    <li>  
                                                        <a href="javascript:void(0);">7 days</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="wg-table table-best-shop-sellers">
                                            <ul class="table-title flex gap20 mb-14">
                                                <li>
                                                    <div class="body-title">Shop</div>
                                                </li>    
                                                <li>
                                                    <div class="body-title">Categories</div>
                                                </li>
                                                <li>
                                                    <div class="body-title">Total</div>
                                                </li>
                                                <li>
                                                    <div class="body-title">Status</div>
                                                </li>
                                            </ul>
                                            <ul id="dashboard-seller-list" class="flex flex-column gap18">
                                                <li class="shop-item">
                                                    <div class="image">
                                                        <img src="images/shop/1.png" alt="">
                                                    </div>
                                                    <div class="flex-grow flex items-center justify-between gap20">
                                                        <div>
                                                            <a href="#" class="body-text name">Robert</a>
                                                            <div class="text-tiny mt-4">73 Purchases</div>
                                                        </div>
                                                        <div class="body-text">Kitchen, Pets</div>
                                                        <div class="body-text">KSh 1,000</div>
                                                        <div class="flex items-center justify-between gap10">
                                                            <div class="progress-level-bar">
                                                                <span data-progress="29" data-max="70" class=""></span>
                                                            </div>
                                                            <div class="text-tiny">100%</div>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="shop-item">
                                                    <div class="image">
                                                        <img src="images/shop/2.png" alt="">
                                                    </div>
                                                    <div class="flex-grow flex items-center justify-between gap20">
                                                        <div>
                                                            <a href="#" class="body-text name">Calvin</a>
                                                            <div class="text-tiny mt-4">66 Purchases</div>
                                                        </div>
                                                        <div class="body-text">Health, Grocery</div>
                                                        <div class="body-text">KSh 4,000</div>
                                                        <div class="flex items-center justify-between gap10">
                                                            <div class="progress-level-bar t1">
                                                                <span data-progress="59" data-max="70" class=""></span>
                                                            </div>
                                                            <div class="text-tiny">100%</div>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="shop-item">
                                                    <div class="image">
                                                        <img src="images/shop/3.png" alt="">
                                                    </div>
                                                    <div class="flex-grow flex items-center justify-between gap20">
                                                        <div>
                                                            <a href="#" class="body-text name">Dwight</a>
                                                            <div class="text-tiny mt-4">15,890 Purchases</div>
                                                        </div>
                                                        <div class="body-text">Electronics</div>
                                                        <div class="body-text">KSh 2,700</div>
                                                        <div class="flex items-center justify-between gap10">
                                                            <div class="progress-level-bar t2">
                                                                <span data-progress="29" data-max="70" class=""></span>
                                                            </div>
                                                            <div class="text-tiny">100%</div>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="shop-item">
                                                    <div class="image">
                                                        <img src="images/shop/4.png" alt="">
                                                    </div>
                                                    <div class="flex-grow flex items-center justify-between gap20">
                                                        <div>
                                                            <a href="#" class="body-text name">Cody</a>
                                                            <div class="text-tiny mt-4">15 Purchases</div>
                                                        </div>
                                                        <div class="body-text">Movies, Music</div>
                                                        <div class="body-text">KSh 2,100</div>
                                                        <div class="flex items-center justify-between gap10">
                                                            <div class="progress-level-bar">
                                                                <span data-progress="25" data-max="70" class=""></span>
                                                            </div>
                                                            <div class="text-tiny">100%</div>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="shop-item">
                                                    <div class="image">
                                                        <img src="images/shop/5.png" alt="">
                                                    </div>
                                                    <div class="flex-grow flex items-center justify-between gap20">
                                                        <div>
                                                            <a href="#" class="body-text name">Bruce</a>
                                                            <div class="text-tiny mt-4">127 Purchases</div>
                                                        </div>
                                                        <div class="body-text">Sports, Fitness</div>
                                                        <div class="body-text">KSh 4,400</div>
                                                        <div class="flex items-center justify-between gap10">
                                                            <div class="progress-level-bar t3">
                                                                <span data-progress="52" data-max="70" class=""></span>
                                                            </div>
                                                            <div class="text-tiny">100%</div>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="shop-item">
                                                    <div class="image">
                                                        <img src="images/shop/6.png" alt="">
                                                    </div>
                                                    <div class="flex-grow flex items-center justify-between gap20">
                                                        <div>
                                                            <a href="#" class="body-text name">Jorge</a>
                                                            <div class="text-tiny mt-4">30 Purchases</div>
                                                        </div>
                                                        <div class="body-text">Toys, Baby</div>
                                                        <div class="body-text">KSh 4,750</div>
                                                        <div class="flex items-center justify-between gap10">
                                                            <div class="progress-level-bar t4">
                                                                <span data-progress="23" data-max="70" class=""></span>
                                                            </div>
                                                            <div class="text-tiny">100%</div>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="shop-item">
                                                    <div class="image">
                                                        <img src="images/shop/7.png" alt="">
                                                    </div>
                                                    <div class="flex-grow flex items-center justify-between gap20">
                                                        <div>
                                                            <a href="#" class="body-text name">Kristin Watson</a>
                                                            <div class="text-tiny mt-4">93 Purchases</div>
                                                        </div>
                                                        <div class="body-text">Gift Cards</div>
                                                        <div class="body-text">KSh 1,000</div>
                                                        <div class="flex items-center justify-between gap10">
                                                            <div class="progress-level-bar t5">
                                                                <span data-progress="45" data-max="70" class=""></span>
                                                            </div>
                                                            <div class="text-tiny">100%</div>
                                                        </div>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <!-- /best-shop-sellers -->
                                    <!-- product-overview -->
                                    <div class="wg-box">
                                        <div class="flex items-center justify-between">
                                            <h5>Product overview</h5>
                                            <div class="dropdown default">
                                                <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <span class="view-all">View all<i class="icon-chevron-down"></i></span>
                                                </button>
                                                <ul class="dropdown-menu dropdown-menu-end">
                                                    <li>  
                                                        <a href="javascript:void(0);">3 days</a>
                                                    </li>
                                                    <li>  
                                                        <a href="javascript:void(0);">7 days</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="wg-table table-product-overview">
                                            <ul class="table-title flex gap20 mb-14">
                                                <li>
                                                    <div class="body-title">Name</div>
                                                </li>    
                                                <li>
                                                    <div class="body-title">Product ID</div>
                                                </li>
                                                <li>
                                                    <div class="body-title">Price</div>
                                                </li>
                                                <li>
                                                    <div class="body-title">Quantity</div>
                                                </li>
                                                <li>
                                                    <div class="body-title">Sale</div>
                                                </li>
                                                <li>
                                                    <div class="body-title">Revenue</div>
                                                </li>
                                                <li>
                                                    <div class="body-title">Status</div>
                                                </li>
                                            </ul>
                                            <ul id="dashboard-product-overview-list" class="flex flex-column gap10"></ul>
                                        </div>
                                        <div class="divider"></div>
                                        <div class="flex items-center justify-between flex-wrap gap10">
                                            <div class="text-tiny">Showing <?php echo count($productOverview); ?> entries</div>
                                            <ul class="wg-pagination">
                                                <li>
                                                    <a href="#"><i class="icon-chevron-left"></i></a>
                                                </li>
                                                <li>
                                                    <a href="#">1</a>
                                                </li>
                                                <li class="active">
                                                    <a href="#">2</a>
                                                </li>
                                                <li>
                                                    <a href="#">3</a>
                                                </li>
                                                <li>
                                                    <a href="#"><i class="icon-chevron-right"></i></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <!-- /product-overview -->
                                </div>
                                <div class="tf-section-3">
                                    <!-- orders -->
                                    <div class="wg-box">
                                        <div class="flex items-center justify-between">
                                            <h5>Orders</h5>
                                            <div class="dropdown default">
                                                <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <span class="icon-more"><i class="icon-more-horizontal"></i></span>
                                                </button>
                                                <ul class="dropdown-menu dropdown-menu-end">
                                                    <li>  
                                                        <a href="javascript:void(0);">This Week</a>
                                                    </li>
                                                    <li>  
                                                        <a href="javascript:void(0);">Last Week</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="wg-table table-orders">
                                            <ul class="table-title flex gap10 mb-14">
                                                <li>
                                                    <div class="body-title">Product</div>
                                                </li>    
                                                <li>
                                                    <div class="body-title">Price</div>
                                                </li>
                                                <li>
                                                    <div class="body-title">Order date</div>
                                                </li>
                                            </ul>
                                            <ul class="flex flex-column gap18">
                                                <?php if(empty($recentOrders)): ?>
                                                <li class="product-item gap14">
                                                    <div class="flex items-center justify-between flex-grow gap10">
                                                        <div class="name"><span class="body-text">No recent orders.</span></div>
                                                    </div>
                                                </li>
                                                <?php else: ?>
                                                <?php foreach($recentOrders as $order): ?>
                                                <li class="product-item gap14">
                                                    <div class="image small">
                                                        <img data-product-image src="<?php echo jd_admin_h(jd_admin_image_url($order['product_link'] ?? '')); ?>" alt="<?php echo jd_admin_h($order['item_name'] ?? 'Ordered product'); ?>">
                                                    </div>
                                                    <div class="flex items-center justify-between flex-grow gap10">
                                                        <div class="name">
                                                            <a href="order-detail.php?order_id=<?php echo (int)$order['order_id']; ?>" class="body-text"><?php echo jd_admin_h($order['item_name'] ?? ('Order #' . (int)$order['order_id'])); ?></a>
                                                        </div>
                                                        <div class="body-text">KSh <?php echo number_format((float)($order['total_amount'] ?? 0), 2); ?></div>
                                                        <div class="body-text"><?php echo !empty($order['created_at']) ? date('d M Y', strtotime($order['created_at'])) : '-'; ?></div>
                                                    </div>
                                                </li>
                                                <?php endforeach; ?>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                    <!-- /orders -->
                                    <!-- earnings -->
                                    <div class="wg-box">
                                        <div class="flex items-center justify-between">
                                            <h5>Earnings</h5>
                                            <div class="dropdown default">
                                                <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                   <span class="icon-more"><i class="icon-more-horizontal"></i></span>
                                                </button>
                                                <ul class="dropdown-menu dropdown-menu-end">
                                                    <li>  
                                                        <a href="javascript:void(0);">This Week</a>
                                                    </li>
                                                    <li>  
                                                        <a href="javascript:void(0);">Last Week</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="flex flex-wrap gap40">
                                            <div>
                                                <div class="mb-2">
                                                    <div class="block-legend">
                                                        <div class="dot t1"></div>
                                                        <div class="text-tiny">Revenue</div>
                                                    </div>
                                                </div>
                                                <div class="flex items-center gap10">
                                                    <h4>KSh <?php echo number_format($earningsRevenue, 2); ?></h4>
                                                    <div class="box-icon-trending up">
                                                        <i class="icon-trending-up"></i>
                                                    <div class="body-title number"><?php echo $trendText('income'); ?></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div>
                                                <div class="mb-2">
                                                    <div class="block-legend">
                                                        <div class="dot t2"></div>
                                                        <div class="text-tiny">Profit</div>
                                                    </div>
                                                </div>
                                                <div class="flex items-center gap10">
                                                    <h4><?php echo $earningsProfit === null ? 'Not tracked' : 'KSh ' . number_format($earningsProfit, 2); ?></h4>
                                                    <div class="box-icon-trending up">
                                                        <i class="icon-trending-up"></i>
                                                    <div class="body-title number">0.00%</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="line-chart-6"></div>
                                    </div>
                                    <!-- /earnings -->
                                    <!-- new-comment -->
                                    <div class="wg-box">
                                        <div class="flex items-center justify-between">
                                            <h5>New Comments</h5>
                                            <div class="dropdown default">
                                                <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                   <span class="icon-more"><i class="icon-more-horizontal"></i></span>
                                                </button>
                                                <ul class="dropdown-menu dropdown-menu-end">
                                                    <li>  
                                                        <a href="javascript:void(0);">This Week</a>
                                                    </li>
                                                    <li>  
                                                        <a href="javascript:void(0);">Last Week</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <ul id="dashboard-comment-list" class="flex flex-column gap20 overflow-h">
                                            <?php if(!empty($newComments)): ?>
                                            <?php foreach($newComments as $comment): ?>
                                            <li class="comment-item">
                                                <div class="image"><img src="images/avatar/user-2.png" alt=""></div>
                                                <div>
                                                    <div class="mb-4 name"><a href="blogs.php" class="body-title-2"><?php echo jd_admin_h($comment['published_by'] ?: 'Customer'); ?></a></div>
                                                    <div class="text-tiny mb-4"><?php echo jd_admin_h($comment['blog_title'] ?: 'Blog comment'); ?></div>
                                                    <div class="text-tiny"><?php echo jd_admin_h($comment['comment']); ?></div>
                                                </div>
                                            </li>
                                            <?php endforeach; ?>
                                            <?php else: ?>
                                            <li class="comment-item">
                                                <div class="image">
                                                    <img src="images/avatar/user-2.png" alt="">
                                                </div>
                                                <div class="">
                                                    <div class="mb-4 name">
                                                        <a href="all-user.php" class="body-title-2">Kathryn Murphy</a>
                                                    </div>
                                                    <div class="ratings mb-10">
                                                        <i class="icon-star1 active"></i>
                                                        <i class="icon-star1 active"></i>
                                                        <i class="icon-star1 active"></i>
                                                        <i class="icon-star1 active"></i>
                                                        <i class="icon-star1"></i>
                                                    </div>
                                                    <div class="text-tiny">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras nec dolor vel est interdum</div>
                                                </div>
                                            </li>
                                            <li class="comment-item">
                                                <div class="image">
                                                    <img src="images/avatar/user-3.png" alt="">
                                                </div>
                                                <div class="">
                                                    <div class="mb-4 name">
                                                        <a href="all-user.php" class="body-title-2">Leslie Alexander</a>
                                                    </div>
                                                    <div class="ratings mb-10">
                                                        <i class="icon-star1 active"></i>
                                                        <i class="icon-star1 active"></i>
                                                        <i class="icon-star1 active"></i>
                                                        <i class="icon-star1 active"></i>
                                                        <i class="icon-star1"></i>
                                                    </div>
                                                    <div class="text-tiny">Cras nec viverra justo, a mattis lacus. Vestibulum eleifend, leo sit amet aliquam laoreet, turpis leo vulputate orci</div>
                                                </div>
                                            </li>
                                            <li class="comment-item">
                                                <div class="image">
                                                    <img src="images/avatar/user-4.png" alt="">
                                                </div>
                                                <div class="">
                                                    <div class="mb-4 name">
                                                        <a href="all-user.php" class="body-title-2">Devon Lane</a>
                                                    </div>
                                                    <div class="ratings mb-10">
                                                        <i class="icon-star1 active"></i>
                                                        <i class="icon-star1 active"></i>
                                                        <i class="icon-star1 active"></i>
                                                        <i class="icon-star1 active"></i>
                                                        <i class="icon-star1"></i>
                                                    </div>
                                                    <div class="text-tiny">Morbi eget commodo diam. Praesent dignissim purus ac turpis porta</div>
                                                </div>
                                            </li>
                                            <li class="comment-item">
                                                <div class="image">
                                                    <img src="images/avatar/user-5.png" alt="">
                                                </div>
                                                <div class="">
                                                    <div class="mb-4 name">
                                                        <a href="all-user.php" class="body-title-2">Eleanor Pena</a>
                                                    </div>
                                                    <div class="ratings mb-10">
                                                        <i class="icon-star1 active"></i>
                                                        <i class="icon-star1 active"></i>
                                                        <i class="icon-star1 active"></i>
                                                        <i class="icon-star1 active"></i>
                                                        <i class="icon-star1"></i>
                                                    </div>
                                                    <div class="text-tiny">Phasellus et eros ullamcorper, efficitur eros eget, pharetra ante. Sed blandit risus vitae dolor feugiat, eu vulputate elit rhoncus</div>
                                                </div>
                                            </li>
                                            <li class="comment-item">
                                                <div class="image">
                                                    <img src="images/avatar/user-2.png" alt="">
                                                </div>
                                                <div class="">
                                                    <div class="mb-4 name">
                                                        <a href="all-user.php" class="body-title-2">Kathryn Murphy</a>
                                                    </div>
                                                    <div class="ratings mb-10">
                                                        <i class="icon-star1 active"></i>
                                                        <i class="icon-star1 active"></i>
                                                        <i class="icon-star1 active"></i>
                                                        <i class="icon-star1 active"></i>
                                                        <i class="icon-star1"></i>
                                                    </div>
                                                    <div class="text-tiny">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras nec dolor vel est interdum</div>
                                                </div>
                                            </li>
                                            <li class="comment-item">
                                                <div class="image">
                                                    <img src="images/avatar/user-3.png" alt="">
                                                </div>
                                                <div class="">
                                                    <div class="mb-4 name">
                                                        <a href="all-user.php" class="body-title-2">Leslie Alexander</a>
                                                    </div>
                                                    <div class="ratings mb-10">
                                                        <i class="icon-star1 active"></i>
                                                        <i class="icon-star1 active"></i>
                                                        <i class="icon-star1 active"></i>
                                                        <i class="icon-star1 active"></i>
                                                        <i class="icon-star1"></i>
                                                    </div>
                                                    <div class="text-tiny">Cras nec viverra justo, a mattis lacus. Vestibulum eleifend, leo sit amet aliquam laoreet, turpis leo vulputate orci</div>
                                                </div>
                                            </li>
                                            <li class="comment-item">
                                                <div class="image">
                                                    <img src="images/avatar/user-4.png" alt="">
                                                </div>
                                                <div class="">
                                                    <div class="mb-4 name">
                                                        <a href="all-user.php" class="body-title-2">Devon Lane</a>
                                                    </div>
                                                    <div class="ratings mb-10">
                                                        <i class="icon-star1 active"></i>
                                                        <i class="icon-star1 active"></i>
                                                        <i class="icon-star1 active"></i>
                                                        <i class="icon-star1 active"></i>
                                                        <i class="icon-star1"></i>
                                                    </div>
                                                    <div class="text-tiny">Morbi eget commodo diam. Praesent dignissim purus ac turpis porta</div>
                                                </div>
                                            </li>
                                            <li class="comment-item">
                                                <div class="image">
                                                    <img src="images/avatar/user-5.png" alt="">
                                                </div>
                                                <div class="">
                                                    <div class="mb-4 name">
                                                        <a href="all-user.php" class="body-title-2">Eleanor Pena</a>
                                                    </div>
                                                    <div class="ratings mb-10">
                                                        <i class="icon-star1 active"></i>
                                                        <i class="icon-star1 active"></i>
                                                        <i class="icon-star1 active"></i>
                                                        <i class="icon-star1 active"></i>
                                                        <i class="icon-star1"></i>
                                                    </div>
                                                    <div class="text-tiny">Phasellus et eros ullamcorper, efficitur eros eget, pharetra ante. Sed blandit risus vitae dolor feugiat, eu vulputate elit rhoncus</div>
                                                </div>
                                            </li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                    <!-- /new-comment -->
                                </div>
                                <div class="tf-section-2 mb-30">
                                    <div class="wg-box">
                                        <div class="flex items-center justify-between">
                                            <div>
                                                <h5>Latest fulfillment queue</h5>
                                                <div class="text-tiny mt-4">Orders awaiting or completing fulfillment</div>
                                            </div>
                                            <a href="order-list.php" class="text-tiny">View orders <i class="icon-chevron-right"></i></a>
                                        </div>
                                        <div class="wg-table table-orders mt-20">
                                            <ul class="table-title flex gap10 mb-14">
                                                <li><div class="body-title">Order</div></li>
                                                <li><div class="body-title">Customer</div></li>
                                                <li><div class="body-title">Items</div></li>
                                                <li><div class="body-title">Total</div></li>
                                                <li><div class="body-title">Status</div></li>
                                            </ul>
                                            <ul class="flex flex-column gap18">
                                                <?php if (empty($fulfillmentQueue)): ?>
                                                <li class="product-item gap14"><div class="flex items-center justify-between flex-grow"><div class="body-text">No fulfillment tasks yet</div><div class="text-tiny">0 orders in queue</div></div></li>
                                                <?php else: ?>
                                                <?php foreach ($fulfillmentQueue as $queueOrder): ?>
                                                <?php $isPending = ($queueOrder['order_status'] ?? '') === 'pending'; ?>
                                                <?php $queueImage = jd_admin_image_url($queueOrder['product_link'] ?? ''); ?>
                                                <li class="product-item gap14">
                                                    <div class="image small"><?php if ($queueImage !== ''): ?><img data-product-image src="<?php echo jd_admin_h($queueImage); ?>" alt="<?php echo jd_admin_h($queueOrder['item_name'] ?? 'Ordered product'); ?>"><?php else: ?><i class="icon-file"></i><?php endif; ?></div>
                                                    <div class="flex items-center justify-between flex-grow gap10">
                                                        <div class="name"><a href="order-detail.php?order_id=<?php echo (int)$queueOrder['order_id']; ?>" class="body-text">#<?php echo (int)$queueOrder['order_id']; ?> · <?php echo jd_admin_h($queueOrder['item_name'] ?? 'Order'); ?></a></div>
                                                        <div class="body-text"><?php echo jd_admin_h($queueOrder['customer_name'] ?: 'Customer'); ?></div>
                                                        <div class="body-text"><?php echo number_format((int)($queueOrder['item_count'] ?? 0)); ?></div>
                                                        <div class="body-text">KSh <?php echo number_format((float)($queueOrder['total_amount'] ?? 0), 2); ?></div>
                                                        <div class="<?php echo $isPending ? 'block-not-available' : 'block-available'; ?>"><?php echo $isPending ? 'Pending' : 'Fulfilled'; ?></div>
                                                    </div>
                                                </li>
                                                <?php endforeach; ?>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="wg-box">
                                        <div class="flex items-center justify-between">
                                            <div>
                                                <h5>Inventory low stock alerts</h5>
                                                <div class="text-tiny mt-4">Products at 5 units or below</div>
                                            </div>
                                        </div>
                                        <div class="wg-table table-orders mt-20">
                                            <ul class="table-title flex gap10 mb-14">
                                                <li><div class="body-title">Product</div></li>
                                                <li><div class="body-title">Product ID</div></li>
                                                <li><div class="body-title">Available</div></li>
                                                <li><div class="body-title">Alert</div></li>
                                            </ul>
                                            <ul class="flex flex-column gap18">
                                                <?php if (empty($lowStockAlerts)): ?>
                                                <li class="product-item gap14"><div class="flex items-center justify-between flex-grow"><div class="body-text">No low-stock alerts</div><div class="text-tiny">0 products need attention</div></div></li>
                                                <?php else: ?>
                                                <?php foreach ($lowStockAlerts as $alert): ?>
                                                <?php $alertQty = (float)($alert['stock_qty'] ?? 0); ?>
                                                <?php $alertImage = jd_admin_image_url($alert['product_link'] ?? ''); ?>
                                                <li class="product-item gap14">
                                                    <div class="image small"><?php if ($alertImage !== ''): ?><img data-product-image src="<?php echo jd_admin_h($alertImage); ?>" alt="<?php echo jd_admin_h($alert['product_name'] ?? 'Product'); ?>"><?php else: ?><i class="icon-alert-triangle"></i><?php endif; ?></div>
                                                    <div class="flex items-center justify-between flex-grow gap10">
                                                        <div class="name"><a href="product-edit.php?id=<?php echo (int)$alert['product_id']; ?>" class="body-text"><?php echo jd_admin_h($alert['product_name'] ?: 'Untitled product'); ?></a></div>
                                                        <div class="body-text">#<?php echo (int)$alert['product_id']; ?></div>
                                                        <div class="body-text"><?php echo number_format($alertQty); ?></div>
                                                        <div class="<?php echo $alertQty <= 0 ? 'block-not-available' : 'block-available'; ?>"><?php echo $alertQty <= 0 ? 'Out of stock' : 'Low stock'; ?></div>
                                                    </div>
                                                </li>
                                                <?php endforeach; ?>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="tf-section-1 mb-30 jd-traffic-dashboard" aria-labelledby="live-traffic-title">
                                    <div class="wg-box">
                                        <div class="flex items-center justify-between flex-wrap gap14">
                                            <div>
                                                <h5 id="live-traffic-title">Website traffic — <?php echo jd_admin_h($selectedMonthLabel); ?></h5>
                                                <div class="text-tiny mt-4" id="jd-traffic-subtitle">Daily page views and unique visitors across the selected month</div>
                                            </div>
                                            <div class="jd-traffic-dashboard__status"><span></span><strong id="jd-traffic-live-count">0</strong> <span id="jd-traffic-status-label">live now</span></div>
                                        </div>
                                        <div class="jd-traffic-dashboard__metrics">
                                            <div><span id="jd-traffic-views-label">Views for selected day</span><strong id="jd-traffic-views-today">0</strong></div>
                                            <div><span id="jd-traffic-visitors-label">Unique visitors for selected day</span><strong id="jd-traffic-unique-today">0</strong></div>
                                            <div><span id="jd-traffic-returning-label" title="Visitors recorded before the selected day">Returning visitors for selected day</span><strong id="jd-traffic-returning-today">0</strong></div>
                                        </div>
                                        <div id="jd-live-traffic-chart" class="jd-traffic-dashboard__chart" aria-label="Website traffic chart"></div>
                                        <div class="jd-traffic-dashboard__bottom">
                                            <div><h6 id="jd-traffic-top-pages-heading">Top pages this month</h6><ul id="jd-traffic-top-pages" class="jd-traffic-dashboard__pages"><li>Loading traffic data…</li></ul></div>
                                            <div><h6>Device mix</h6><div id="jd-traffic-devices" class="jd-traffic-dashboard__devices">Loading…</div></div>
                                        </div>
                                        <div class="jd-traffic-dashboard__periods" id="jd-traffic-periods" aria-label="Traffic period statistics"></div>
                                        <section class="jd-traffic-dashboard__products" aria-labelledby="jd-product-traffic-heading">
                                            <div class="jd-traffic-dashboard__section-heading"><div><h6 id="jd-product-traffic-heading">Product traffic</h6><span>Most-viewed products and their strongest visitor location.</span></div></div>
                                            <div id="jd-product-traffic-chart" class="jd-traffic-dashboard__chart jd-traffic-dashboard__chart--products" aria-label="Most-viewed products chart"></div>
                                            <div class="table-responsive"><table><thead><tr><th>Product</th><th>Views</th><th>Unique visitors</th><th>Top location</th></tr></thead><tbody id="jd-product-traffic-table"><tr><td colspan="4">Loading product traffic…</td></tr></tbody></table></div>
                                        </section>
                                        <div class="jd-traffic-dashboard__trend-wrap"><div class="jd-traffic-dashboard__section-heading"><h6 id="jd-traffic-trend-heading">14-day traffic trend</h6><span>Views and unique visitors</span></div><div id="jd-traffic-14-day-chart" class="jd-traffic-dashboard__chart jd-traffic-dashboard__chart--compact" aria-label="Fourteen day website traffic chart"></div></div>
                                        <div class="jd-traffic-dashboard__breakdowns">
                                            <section><h6>Traffic channels</h6><div id="jd-traffic-channels"></div></section><section><h6>Traffic sources</h6><div id="jd-traffic-sources"></div></section><section><h6>Browsers</h6><div id="jd-traffic-browsers"></div></section><section><h6>Operating systems</h6><div id="jd-traffic-systems"></div></section><section><h6>Campaigns</h6><div id="jd-traffic-campaigns"></div></section><section><h6>Countries</h6><div id="jd-traffic-countries"></div></section>
                                        </div>
                                        <section class="jd-traffic-dashboard__map-card"><div class="jd-traffic-dashboard__section-heading"><div><h6>Traffic Map</h6><span id="jd-traffic-map-subtitle">Top countries for the selected month.</span></div></div><div id="jd-traffic-country-map" class="jd-traffic-dashboard__map" aria-label="Map of website traffic by country"></div></section>
                                        <div class="jd-traffic-dashboard__recent"><div class="jd-traffic-dashboard__section-heading"><h6>Recent visits</h6><span>Latest recorded pages and visit context</span></div><div class="table-responsive"><table><thead><tr><th>Visited</th><th>Page</th><th>Source</th><th>Channel</th><th>Device</th><th>Browser / OS</th><th>Country</th></tr></thead><tbody id="jd-traffic-recent"><tr><td colspan="7">Loading traffic data…</td></tr></tbody></table></div></div>
                                    </div>
                                </div>
                            </div>
                            <!-- /main-content-wrap -->
                        </div>
                        <!-- /main-content-wrap -->
                        <style>
                            .jd-traffic-dashboard .wg-box { overflow: hidden; }
                            .jd-traffic-dashboard__status { display: inline-flex; align-items: center; gap: 7px; padding: 8px 12px; color: #147448; background: #ecfdf3; border-radius: 999px; font-size: 12px; }
                            .jd-traffic-dashboard__status > span { width: 8px; height: 8px; background: #22c55e; border-radius: 50%; box-shadow: 0 0 0 4px rgba(34, 197, 94, .14); }
                            .jd-traffic-dashboard__metrics { margin: 21px 0 8px; display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); border: 1px solid #edf0f4; border-radius: 10px; }
                            .jd-traffic-dashboard__metrics > div { min-width: 0; padding: 14px 17px; border-right: 1px solid #edf0f4; }
                            .jd-traffic-dashboard__metrics > div:last-child { border-right: 0; }
                            .jd-traffic-dashboard__metrics span { display: block; color: #7a8494; font-size: 12px; } .jd-traffic-dashboard__metrics strong { display: block; margin-top: 4px; color: #1d2939; font-size: 20px; }
                            .jd-traffic-dashboard__chart { min-height: 295px; }
                            .jd-traffic-dashboard__bottom { padding-top: 18px; display: grid; grid-template-columns: 1.35fr .65fr; gap: 28px; border-top: 1px solid #edf0f4; }
                            .jd-traffic-dashboard__bottom h6 { margin: 0 0 11px; color: #1d2939; font-size: 14px; }
                            .jd-traffic-dashboard__pages { padding: 0; margin: 0; list-style: none; } .jd-traffic-dashboard__pages li { display: flex; justify-content: space-between; gap: 12px; padding: 8px 0; color: #5c6675; border-bottom: 1px solid #f1f3f6; font-size: 12px; } .jd-traffic-dashboard__pages li:last-child { border-bottom: 0; } .jd-traffic-dashboard__pages span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; } .jd-traffic-dashboard__pages strong { color: #2377fc; }
                            .jd-traffic-dashboard__devices { display: flex; flex-wrap: wrap; gap: 8px; } .jd-traffic-dashboard__devices span { padding: 7px 9px; color: #516071; background: #f5f8fc; border-radius: 7px; font-size: 12px; } .jd-traffic-dashboard__devices strong { color: #1d2939; }
                            .jd-traffic-dashboard__periods { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 10px; margin-top: 20px; } .jd-traffic-dashboard__periods > div, .jd-traffic-dashboard__breakdowns > section, .jd-traffic-dashboard__recent { border: 1px solid #edf0f4; border-radius: 10px; background: #fff; } .jd-traffic-dashboard__periods > div { padding: 13px; } .jd-traffic-dashboard__periods span { display: block; color: #7a8494; font-size: 11px; text-transform: uppercase; letter-spacing: .04em; } .jd-traffic-dashboard__periods strong { display: block; margin-top: 6px; color: #1d2939; font-size: 19px; } .jd-traffic-dashboard__periods small { display: block; margin-top: 4px; color: #7a8494; font-size: 11px; }
                            .jd-traffic-dashboard__trend-wrap { margin-top: 20px; padding: 17px; border: 1px solid #edf0f4; border-radius: 10px; } .jd-traffic-dashboard__section-heading { display: flex; align-items: baseline; justify-content: space-between; gap: 12px; } .jd-traffic-dashboard__section-heading h6, .jd-traffic-dashboard__breakdowns h6 { margin: 0; color: #1d2939; font-size: 14px; } .jd-traffic-dashboard__section-heading span { color: #7a8494; font-size: 11px; } .jd-traffic-dashboard__chart--compact { min-height: 230px; }
                            .jd-traffic-dashboard__products { margin-top: 20px; padding: 17px; border: 1px solid #edf0f4; border-radius: 10px; background: #fff; } .jd-traffic-dashboard__chart--products { min-height: 270px; } .jd-traffic-dashboard__products table { width: 100%; min-width: 620px; margin-top: 12px; border-collapse: collapse; color: #5c6675; font-size: 12px; } .jd-traffic-dashboard__products th { padding: 0 8px 9px; color: #7a8494; font-size: 10px; text-align: left; text-transform: uppercase; letter-spacing: .05em; } .jd-traffic-dashboard__products td { padding: 10px 8px; border-top: 1px solid #f0f3f7; vertical-align: middle; } .jd-traffic-dashboard__products td:first-child { color: #26354b; font-weight: 600; } .jd-product-traffic__product { min-width: 0; display: flex; align-items: center; gap: 11px; } .jd-product-traffic__thumb { width: 46px; height: 46px; flex: 0 0 46px; overflow: hidden; display: grid; place-items: center; background: #f4f7fb; border: 1px solid #e4eaf2; border-radius: 7px; } .jd-product-traffic__thumb img { width: 100%; height: 100%; object-fit: contain; } .jd-product-traffic__thumb i { color: #98a2b3; font-size: 18px; } .jd-product-traffic__product a { min-width: 0; overflow: hidden; color: #26354b; text-overflow: ellipsis; white-space: nowrap; }
                            .jd-traffic-dashboard__breakdowns { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 14px; margin-top: 20px; } .jd-traffic-dashboard__breakdowns > section { padding: 16px; } .jd-traffic-dashboard__dimension { margin-top: 12px; } .jd-traffic-dashboard__dimension-row { display: grid; grid-template-columns: minmax(0, 1fr) auto; gap: 9px; align-items: center; margin-top: 8px; color: #5c6675; font-size: 12px; } .jd-traffic-dashboard__dimension-row span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; } .jd-traffic-dashboard__dimension-row strong { color: #1d2939; } .jd-traffic-dashboard__dimension-bar { grid-column: 1 / -1; height: 5px; overflow: hidden; background: #edf2f7; border-radius: 999px; } .jd-traffic-dashboard__dimension-bar i { display: block; height: 100%; background: linear-gradient(90deg, #2377fc, #45b7ee); border-radius: inherit; }
                            .jd-traffic-dashboard__map-card { margin-top: 20px; padding: 17px; border: 1px solid #edf0f4; border-radius: 10px; background: #fff; } .jd-traffic-dashboard__map { height: 360px; margin-top: 14px; overflow: hidden; border-radius: 9px; background: #eef6ff; } .jd-traffic-dashboard__map .leaflet-control-attribution { font-size: 9px; }
                            .jd-traffic-dashboard__recent { margin-top: 20px; padding: 16px; } .jd-traffic-dashboard__recent table { width: 100%; min-width: 760px; margin-top: 13px; border-collapse: collapse; color: #5c6675; font-size: 12px; } .jd-traffic-dashboard__recent th { padding: 0 8px 9px; color: #7a8494; font-size: 10px; text-align: left; text-transform: uppercase; letter-spacing: .05em; } .jd-traffic-dashboard__recent td { padding: 10px 8px; border-top: 1px solid #f0f3f7; vertical-align: top; } .jd-traffic-dashboard__recent td:nth-child(2) { max-width: 220px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: #26354b; }
                            @media (max-width: 991px) { .jd-traffic-dashboard__periods { grid-template-columns: repeat(2, minmax(0, 1fr)); } .jd-traffic-dashboard__breakdowns { grid-template-columns: repeat(2, minmax(0, 1fr)); } } @media (max-width: 767px) { .jd-traffic-dashboard__metrics, .jd-traffic-dashboard__bottom, .jd-traffic-dashboard__periods, .jd-traffic-dashboard__breakdowns { grid-template-columns: 1fr; } .jd-traffic-dashboard__metrics > div { border-right: 0; border-bottom: 1px solid #edf0f4; } .jd-traffic-dashboard__metrics > div:last-child { border-bottom: 0; } .jd-traffic-dashboard__chart { min-height: 240px; } }
                        </style>
                        <script>
                            window.jdAdminChartData = <?php echo json_encode($dashboardChartData, JSON_NUMERIC_CHECK | JSON_UNESCAPED_SLASHES); ?>;
                            window.jdDashboardPanelData = <?php echo json_encode($dashboardPanelData, JSON_NUMERIC_CHECK | JSON_UNESCAPED_SLASHES); ?>;
                            (function () {
                                const panelData = window.jdDashboardPanelData || {};
                                const escapeHtml = (value) => String(value ?? '').replace(/[&<>'"]/g, (character) => ({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#039;'}[character]));
                                const currency = (value) => 'KSh ' + Number(value || 0).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});

                                const countryList = document.getElementById('dashboard-country-list');
                                if (countryList) {
                                    countryList.innerHTML = '<li class="country-item"><div class="image"><i class="icon-map-pin"></i></div><div class="flex-grow flex items-center justify-between"><span class="body-text name">No recorded country sales</span><div class="box-icon-trending"><i class="icon-minus"></i></div><div class="body-text number">0</div></div></li>';
                                }

                                const sellerList = document.getElementById('dashboard-seller-list');
                                if (sellerList) {
                                    sellerList.innerHTML = '<li class="shop-item"><div class="image"><i class="icon-store"></i></div><div class="flex-grow flex items-center justify-between gap20"><div><span class="body-text name">No seller data recorded</span><div class="text-tiny mt-4">0 Purchases</div></div><div class="body-text">—</div><div class="body-text">KSh 0.00</div><div class="text-tiny">0.00%</div></div></li>';
                                }

                                const commentList = document.getElementById('dashboard-comment-list');
                                if (commentList && !panelData.hasComments) {
                                    commentList.innerHTML = '<li class="comment-item"><div class="image"><i class="icon-message-square"></i></div><div><div class="mb-4 name"><span class="body-title-2">No comments yet</span></div><div class="text-tiny">0 recorded comments</div></div></li>';
                                }

                                const overviewList = document.getElementById('dashboard-product-overview-list');
                                if (overviewList) {
                                    const products = Array.isArray(panelData.products) ? panelData.products : [];
                                    overviewList.innerHTML = products.length ? products.map((product) => {
                                        const sale = Number(product.wasPrice || 0) > Number(product.price || 0) ? Math.round(((Number(product.wasPrice) - Number(product.price)) / Number(product.wasPrice)) * 100) + '% off' : '—';
                                        const status = Number(product.quantity || 0) > 0 ? '<div class="block-available">In stock</div>' : '<div class="block-not-available">Out of stock</div>';
                                        const image = window.jdAdminImageUrl(product.image);
                                        return '<li class="product-item gap14"><div class="image">' + (image ? '<img data-product-image src="' + escapeHtml(image) + '" alt="' + escapeHtml(product.name) + '">' : '<i class="icon-image"></i>') + '</div><div class="flex items-center justify-between flex-grow"><div class="name"><a href="product-edit.php?id=' + Number(product.id || 0) + '" class="body-text">' + escapeHtml(product.name) + '</a></div><div class="body-text">#' + Number(product.id || 0) + '</div><div class="body-text">' + currency(product.price) + '</div><div class="body-text">' + Number(product.quantity || 0).toLocaleString() + '</div><div class="body-text">' + sale + '</div><div class="body-text">' + currency(product.revenue) + '</div><div>' + status + '</div></div></li>';
                                    }).join('') : '<li class="product-item gap14"><div class="flex items-center justify-between flex-grow"><div class="body-text">No products recorded</div><div class="body-text">#0</div><div class="body-text">KSh 0.00</div><div class="body-text">0</div><div class="body-text">—</div><div class="body-text">KSh 0.00</div><div class="block-not-available">Out of stock</div></div></li>';
                                }
                            })();

                            document.addEventListener('DOMContentLoaded', function () {
                                var chartElement = document.getElementById('jd-live-traffic-chart');
                                if (!chartElement) return;
                                var trafficChart = null;
                                if (typeof ApexCharts !== 'undefined') trafficChart = new ApexCharts(chartElement, {
                                    chart: { type: 'area', height: 290, toolbar: { show: false }, animations: { easing: 'easeinout', speed: 450 } },
                                    series: [{ name: 'Page views', data: [] }, { name: 'Unique visitors', data: [] }],
                                    colors: ['#2377FC', '#18A96B'],
                                    stroke: { curve: 'smooth', width: 3 },
                                    fill: { type: 'gradient', gradient: { opacityFrom: .28, opacityTo: .02, stops: [0, 100] } },
                                    dataLabels: { enabled: false },
                                    grid: { borderColor: '#edf0f4', strokeDashArray: 3 },
                                    xaxis: { categories: [], labels: { style: { colors: '#8d98a8', fontSize: '11px' } } },
                                    yaxis: { labels: { style: { colors: '#8d98a8', fontSize: '11px' } }, min: 0, forceNiceScale: true },
                                    legend: { position: 'top', horizontalAlign: 'right', fontSize: '12px' },
                                    tooltip: { shared: true, y: { formatter: function (value) { return Number(value || 0).toLocaleString(); } } }
                                });
                                if (trafficChart) trafficChart.render();
                                else chartElement.innerHTML = '<div style="display:grid;min-height:290px;place-items:center;color:#667085;font-size:12px">Traffic chart library is unavailable.</div>';

                                var dailyElement = document.getElementById('jd-traffic-14-day-chart');
                                var dailyChart = dailyElement && typeof ApexCharts !== 'undefined' ? new ApexCharts(dailyElement, {
                                    chart: { type: 'line', height: 230, toolbar: { show: false }, animations: { easing: 'easeinout', speed: 450 } },
                                    series: [{ name: 'Page views', data: [] }, { name: 'Unique visitors', data: [] }],
                                    colors: ['#5b74e8', '#f59e0b'], stroke: { curve: 'smooth', width: 3 }, dataLabels: { enabled: false },
                                    grid: { borderColor: '#edf0f4', strokeDashArray: 3 }, xaxis: { categories: [], labels: { style: { colors: '#8d98a8', fontSize: '10px' } } },
                                    yaxis: { min: 0, forceNiceScale: true, labels: { style: { colors: '#8d98a8', fontSize: '10px' } } }, legend: { position: 'top', horizontalAlign: 'right', fontSize: '11px' }, tooltip: { shared: true }
                                }) : null;
                                if (dailyChart) dailyChart.render();
                                var productChartElement = document.getElementById('jd-product-traffic-chart');
                                var productTrafficChart = productChartElement && typeof ApexCharts !== 'undefined' ? new ApexCharts(productChartElement, {
                                    chart: { type: 'bar', height: 270, toolbar: { show: false }, animations: { easing: 'easeinout', speed: 450 } },
                                    series: [{ name: 'Product views', data: [] }], colors: ['#7c3aed'], plotOptions: { bar: { horizontal: true, borderRadius: 4, barHeight: '55%' } },
                                    dataLabels: { enabled: false }, grid: { borderColor: '#edf0f4', strokeDashArray: 3 }, xaxis: { categories: [], min: 0, labels: { style: { colors: '#8d98a8', fontSize: '10px' } } },
                                    yaxis: { labels: { maxWidth: 210, style: { colors: '#5c6675', fontSize: '11px' } } }, legend: { show: false }, tooltip: { y: { formatter: function (value) { return Number(value || 0).toLocaleString() + ' views'; } } }
                                }) : null;
                                if (productTrafficChart) productTrafficChart.render();
                                var trafficMap, trafficMarkers;
                                var leafletLoader = null;
                                var ensureLeaflet = function () {
                                    if (window.L) return Promise.resolve(window.L);
                                    if (leafletLoader) return leafletLoader;
                                    var cssId = 'jd-leaflet-css';
                                    if (!document.getElementById(cssId)) {
                                        var stylesheet = document.createElement('link');
                                        stylesheet.id = cssId;
                                        stylesheet.rel = 'stylesheet';
                                        stylesheet.href = 'https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.css';
                                        document.head.appendChild(stylesheet);
                                    }
                                    var sources = [
                                        'https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.js',
                                        'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'
                                    ];
                                    leafletLoader = new Promise(function (resolve, reject) {
                                        var loadSource = function (index) {
                                            if (window.L) { resolve(window.L); return; }
                                            if (index >= sources.length) { reject(new Error('Leaflet unavailable')); return; }
                                            var script = document.createElement('script');
                                            var settled = false;
                                            var timer = window.setTimeout(function () {
                                                if (settled) return;
                                                settled = true;
                                                script.remove();
                                                loadSource(index + 1);
                                            }, 4500);
                                            script.async = true;
                                            script.src = sources[index];
                                            script.onload = function () {
                                                if (settled) return;
                                                settled = true;
                                                window.clearTimeout(timer);
                                                window.L ? resolve(window.L) : loadSource(index + 1);
                                            };
                                            script.onerror = function () {
                                                if (settled) return;
                                                settled = true;
                                                window.clearTimeout(timer);
                                                script.remove();
                                                loadSource(index + 1);
                                            };
                                            document.head.appendChild(script);
                                        };
                                        loadSource(0);
                                    });
                                    return leafletLoader;
                                };
                                var countryLocations = { KE:[-0.0236,37.9062], UG:[1.3733,32.2903], TZ:[-6.3690,34.8888], RW:[-1.9403,29.8739], ET:[9.1450,40.4897], SO:[5.1521,46.1996], ZA:[-30.5595,22.9375], NG:[9.0820,8.6753], GH:[7.9465,-1.0232], EG:[26.8206,30.8025], US:[39.8283,-98.5795], CA:[56.1304,-106.3468], GB:[55.3781,-3.4360], IE:[53.1424,-7.6921], DE:[51.1657,10.4515], FR:[46.2276,2.2137], ES:[40.4637,-3.7492], IT:[41.8719,12.5674], NL:[52.1326,5.2913], BE:[50.5039,4.4699], SE:[60.1282,18.6435], NO:[60.4720,8.4689], DK:[56.2639,9.5018], FI:[61.9241,25.7482], PL:[51.9194,19.1451], TR:[38.9637,35.2433], SA:[23.8859,45.0792], AE:[23.4241,53.8478], IN:[20.5937,78.9629], PK:[30.3753,69.3451], BD:[23.6850,90.3563], CN:[35.8617,104.1954], JP:[36.2048,138.2529], KR:[35.9078,127.7669], SG:[1.3521,103.8198], MY:[4.2105,101.9758], ID:[-0.7893,113.9213], PH:[12.8797,121.7740], AU:[-25.2744,133.7751], NZ:[-40.9006,174.8860], BR:[-14.2350,-51.9253], MX:[23.6345,-102.5528] };
                                var renderTrafficMap = function (countries) {
                                    var target = document.getElementById('jd-traffic-country-map');
                                    if (!target) return;
                                    var points = (Array.isArray(countries) ? countries : []).map(function (country) { var code = String(country.label || '').toUpperCase(); return countryLocations[code] ? { code: code, views: Number(country.views || 0), point: countryLocations[code] } : null; }).filter(Boolean);
                                    if (!window.L) {
                                        target.innerHTML = '<div style="display:grid;height:100%;place-items:center;color:#667085;font-size:12px">Loading traffic map…</div>';
                                        ensureLeaflet().then(function () { renderTrafficMap(countries); }).catch(function () {
                                            leafletLoader = null;
                                            target.innerHTML = '<div style="display:grid;height:100%;place-items:center;color:#667085;font-size:12px">Traffic data is available; the map service could not be reached.</div>';
                                        });
                                        return;
                                    }
                                    if (!trafficMap) { trafficMap = L.map(target, { zoomControl: true, scrollWheelZoom: false, attributionControl: true }).setView([8, 20], 2); L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 18, attribution: '&copy; OpenStreetMap contributors' }).addTo(trafficMap); trafficMarkers = L.layerGroup().addTo(trafficMap); }
                                    trafficMarkers.clearLayers();
                                    if (!points.length) { trafficMap.setView([8, 20], 2); return; }
                                    var bounds = [];
                                    points.forEach(function (item) { var radius = Math.max(7, Math.min(26, Math.round(item.views * 2))); L.circleMarker(item.point, { radius: radius, color: '#0f766e', weight: 2, fillColor: '#22d3ee', fillOpacity: .45 }).bindPopup('<strong>' + escapeHtml(item.code) + '</strong><br>Visits: ' + item.views.toLocaleString()).addTo(trafficMarkers); bounds.push(item.point); });
                                    trafficMap.fitBounds(bounds, { padding: [24, 24], maxZoom: 4 });
                                };

                                var setText = function (id, value) {
                                    var element = document.getElementById(id);
                                    if (element) element.textContent = value;
                                };
                                var escapeHtml = function (value) {
                                    return String(value || '').replace(/[&<>"']/g, function (character) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' })[character]; });
                                };
                                var renderTraffic = function (payload) {
                                    var summary = payload.summary || {};
                                    var monthly = payload.monthly || {};
                                    var selection = payload.selection || {};
                                    var selectedLabel = selection.label || 'selected month';
                                    setText('live-traffic-title', 'Website traffic — ' + selectedLabel);
                                    setText('jd-traffic-subtitle', selection.monthly_label || 'Daily page views and unique visitors across the selected month');
                                    setText('jd-traffic-status-label', selection.is_current ? 'live now' : 'historical period');
                                    setText('jd-traffic-views-label', 'Views ' + (selection.day_label || 'for selected day'));
                                    setText('jd-traffic-visitors-label', 'Unique visitors ' + (selection.day_label || 'for selected day'));
                                    setText('jd-traffic-returning-label', 'Returning visitors ' + (selection.day_label || 'for selected day'));
                                    setText('jd-traffic-top-pages-heading', 'Top pages in ' + selectedLabel);
                                    setText('jd-traffic-trend-heading', selection.daily_label || '14-day traffic trend');
                                    setText('jd-traffic-map-subtitle', 'Top countries for ' + selectedLabel + '.');
                                    setText('jd-traffic-live-count', Number(summary.live_visitors || 0).toLocaleString());
                                    setText('jd-traffic-views-today', Number(summary.views_today || 0).toLocaleString());
                                    setText('jd-traffic-unique-today', Number(summary.unique_today || 0).toLocaleString());
                                    setText('jd-traffic-returning-today', Number(summary.returning_today || 0).toLocaleString());
                                    if (trafficChart) {
                                        trafficChart.updateOptions({ xaxis: { categories: monthly.labels || [] } }, false, true);
                                        trafficChart.updateSeries([{ name: 'Page views', data: monthly.views || [] }, { name: 'Unique visitors', data: monthly.visitors || [] }], true);
                                    }

                                    var pages = Array.isArray(payload.top_pages) ? payload.top_pages : [];
                                    var pagesElement = document.getElementById('jd-traffic-top-pages');
                                    if (pagesElement) pagesElement.innerHTML = pages.length ? pages.map(function (page) { return '<li><span title="' + escapeHtml(page.path) + '">' + escapeHtml(page.title || page.path) + '</span><strong>' + Number(page.views || 0).toLocaleString() + '</strong></li>'; }).join('') : '<li><span>No page views recorded yet.</span></li>';

                                    var products = Array.isArray(payload.product_traffic) ? payload.product_traffic : [];
                                    if (productTrafficChart) productTrafficChart.updateOptions({ xaxis: { categories: products.map(function (product) { return String(product.name || 'Product'); }) } }, false, true);
                                    if (productTrafficChart) productTrafficChart.updateSeries([{ name: 'Product views', data: products.map(function (product) { return Number(product.views || 0); }) }], true);
                                    var productsTable = document.getElementById('jd-product-traffic-table');
                                    if (productsTable) productsTable.innerHTML = products.length ? products.map(function (product) { var productImage = window.jdAdminImageUrl(product.image); var thumbnail = productImage ? '<span class="jd-product-traffic__thumb"><img data-product-image src="' + escapeHtml(productImage) + '" alt=""></span>' : '<span class="jd-product-traffic__thumb"><i class="icon-image"></i></span>'; return '<tr><td><div class="jd-product-traffic__product">' + thumbnail + '<a href="product-edit.php?id=' + Number(product.id || 0) + '" title="' + escapeHtml(product.name || 'Product') + '">' + escapeHtml(product.name || 'Product') + '</a></div></td><td>' + Number(product.views || 0).toLocaleString() + '</td><td>' + Number(product.visitors || 0).toLocaleString() + '</td><td>' + escapeHtml(product.top_country || 'Unknown') + '</td></tr>'; }).join('') : '<tr><td colspan="4">No product traffic recorded for this month yet.</td></tr>';

                                    var dimensions = payload.dimensions || {};
                                    var devices = dimensions.devices || [];
                                    var devicesElement = document.getElementById('jd-traffic-devices');
                                    if (devicesElement) devicesElement.innerHTML = devices.length ? devices.map(function (device) { return '<span>' + escapeHtml(device.label) + ' <strong>' + Number(device.views || 0).toLocaleString() + '</strong></span>'; }).join('') : '<span>No visits yet</span>';

                                    var periods = payload.periods || {};
                                    var periodsElement = document.getElementById('jd-traffic-periods');
                                    var periodLabels = selection.period_labels || {};
                                    if (periodsElement) periodsElement.innerHTML = [['today', periodLabels.today || 'Selected day'], ['week', periodLabels.week || 'Last 7 days'], ['month', periodLabels.month || selectedLabel], ['year', periodLabels.year || 'Previous 12 months']].map(function (definition) { var stat = periods[definition[0]] || {}; return '<div><span>' + definition[1] + '</span><strong>' + Number(stat.views || 0).toLocaleString() + '</strong><small>' + Number(stat.visitors || 0).toLocaleString() + ' unique · ' + Number(stat.returning || 0).toLocaleString() + ' returning</small></div>'; }).join('');

                                    var daily = payload.daily || {};
                                    if (dailyChart) { dailyChart.updateOptions({ xaxis: { categories: daily.labels || [] } }, false, true); dailyChart.updateSeries([{ name: 'Page views', data: daily.views || [] }, { name: 'Unique visitors', data: daily.visitors || [] }], true); }

                                    var renderDimension = function (id, items) { var target = document.getElementById(id); if (!target) return; items = Array.isArray(items) ? items : []; var maximum = Math.max.apply(null, items.map(function (item) { return Number(item.views || 0); }).concat([1])); target.innerHTML = items.length ? '<div class="jd-traffic-dashboard__dimension">' + items.map(function (item) { var value = Number(item.views || 0); return '<div class="jd-traffic-dashboard__dimension-row"><span title="' + escapeHtml(item.label) + '">' + escapeHtml(item.label) + '</span><strong>' + value.toLocaleString() + '</strong><div class="jd-traffic-dashboard__dimension-bar"><i style="width:' + Math.max(4, Math.round((value / maximum) * 100)) + '%"></i></div></div>'; }).join('') + '</div>' : '<div class="text-tiny mt-4">No data recorded yet.</div>'; };
                                    renderDimension('jd-traffic-channels', dimensions.channels); renderDimension('jd-traffic-sources', dimensions.sources); renderDimension('jd-traffic-browsers', dimensions.browsers); renderDimension('jd-traffic-systems', dimensions.systems); renderDimension('jd-traffic-campaigns', dimensions.campaigns); renderDimension('jd-traffic-countries', dimensions.countries); renderTrafficMap(dimensions.countries);

                                    var recent = Array.isArray(payload.recent) ? payload.recent : [];
                                    var recentElement = document.getElementById('jd-traffic-recent');
                                    if (recentElement) recentElement.innerHTML = recent.length ? recent.map(function (visit) { var visited = visit.viewed_at ? new Date(String(visit.viewed_at).replace(' ', 'T')).toLocaleString() : '—'; return '<tr><td>' + escapeHtml(visited) + '</td><td title="' + escapeHtml(visit.page_path) + '">' + escapeHtml(visit.page_title || visit.page_path || '—') + '</td><td>' + escapeHtml(visit.source || 'Direct') + '</td><td>' + escapeHtml(visit.traffic_channel || 'Direct') + '</td><td>' + escapeHtml(visit.device_type || 'Unknown') + '</td><td>' + escapeHtml((visit.browser_name || 'Unknown') + ' / ' + (visit.os_name || 'Unknown')) + '</td><td>' + escapeHtml(visit.country_code || 'Unknown') + '</td></tr>'; }).join('') : '<tr><td colspan="7">No visits recorded yet.</td></tr>';
                                };
                                var loadTraffic = function () {
                                    fetch('../traffic-live.php?month=<?php echo rawurlencode($selectedMonthKey); ?>', { credentials: 'same-origin', cache: 'no-store' })
                                        .then(function (response) { if (!response.ok) throw new Error('Traffic request failed'); return response.json(); })
                                        .then(function (payload) { if (payload && payload.status === 'success') renderTraffic(payload); })
                                        .catch(function () { setText('jd-traffic-live-count', '—'); });
                                };
                                loadTraffic();
                                window.setInterval(loadTraffic, 30000);
                            });
                        </script>
                        <?php include __DIR__ . '/includes/footer.php'; ?>
