<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' || $_SERVER['REQUEST_METHOD'] === 'GET') {
    $submittedToken = (string)($_POST['csrf_token'] ?? ($_GET['token'] ?? ''));
    $sessionToken = (string)($_SESSION['admin_csrf_token'] ?? '');
    if ($submittedToken !== '' && $sessionToken !== '' && hash_equals($sessionToken, $submittedToken)) {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
        }
        session_destroy();
    }
}

header('Location: login.php');
exit;
