<?php
require_once __DIR__ . '/includes/bootstrap.php';
header('Location: all-roles.php');
exit;
