<?php
require_once __DIR__ . '/../control/core/init.php';
if (jd_is_active_admin($conn)) { header('Location: index.php'); exit; }
$loginError = '';
$loginAccount = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $loginAccount = trim((string)($_POST['account'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    if ($loginAccount !== '' && $password !== '') {
        $statement = mysqli_prepare($conn, "SELECT user_id, username, user_level FROM webaccounts WHERE (email = ? OR username = ? OR phone = ?) AND is_active = 1 AND AES_DECRYPT(user_password, ?) = ? LIMIT 1");
        if ($statement) {
            mysqli_stmt_bind_param($statement, 'sssss', $loginAccount, $loginAccount, $loginAccount, $password, $password);
            mysqli_stmt_execute($statement); $result = mysqli_stmt_get_result($statement); $user = $result ? mysqli_fetch_assoc($result) : null; mysqli_stmt_close($statement);
            if ($user && ($user['user_level'] ?? '') === 'admin') {
                session_regenerate_id(true); $_SESSION['programUser'] = (string)$user['username']; $_SESSION['programUserLevel'] = 'admin'; $_SESSION['user_id'] = (int)$user['user_id']; $_SESSION['admin_csrf_token'] = bin2hex(random_bytes(32));
                header('Location: index.php'); exit;
            }
        }
    }
    $loginError = 'The supplied admin credentials are not valid.';
}
?>
<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie" xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<!--<![endif]-->


<!-- Mirrored from themesflat.co/html/remos/login.php by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 21 May 2026 05:34:50 GMT -->
<head>
    <!-- Basic Page Needs -->
    <meta charset="utf-8">
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <title>Jullies Develops Administration</title>

    <meta name="author" content="themesflat.com">

    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- Theme Style -->
    <link rel="stylesheet" type="text/css" href="css/animate.min.css">
    <link rel="stylesheet" type="text/css" href="css/animation.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-select.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/jd-premium.css">



    <!-- Font -->
    <link rel="stylesheet" href="font/fonts.css">

    <!-- Icon -->
    <link rel="stylesheet" href="icon/style.css">

    <!-- Favicon and Touch Icons  -->
    <link rel="icon" type="image/png" href="../assets/images/logo.png">
    <link rel="apple-touch-icon" href="../assets/images/logo.png">

</head>

<body class="body jd-login-premium">

    <!-- #wrapper -->
    <div id="wrapper">
        <!-- #page -->
        <div id="page" class="">
            <div class="wrap-login-page">
                <div class="flex-grow flex flex-column justify-center gap30">
                    <a href="../index.php" id="site-logo-inner" class="login-brand">
                        <img src="../assets/images/logo.png" alt="Jullies Develops" width="81" height="81">
                    </a>
                    <div class="login-box">
                        <div>
                            <h3>Login to account</h3>
                            <div class="body-text">Enter your email & password to login</div>
                        </div>
                        <form class="form-login flex flex-column gap24" method="post" action="login.php">
                            <?php if ($loginError !== ''): ?><div class="alert alert-danger" role="alert"><?php echo htmlspecialchars($loginError, ENT_QUOTES, 'UTF-8'); ?></div><?php endif; ?>
                            <fieldset class="email">
                                <div class="body-title mb-10">Email address <span class="tf-color-1">*</span></div>
                                <input class="flex-grow" type="text" placeholder="Email, username or phone" name="account" tabindex="0" value="<?php echo htmlspecialchars($loginAccount, ENT_QUOTES, 'UTF-8'); ?>" autocomplete="username" aria-required="true" required>
                            </fieldset>
                            <fieldset class="password">
                                <div class="body-title mb-10">Password <span class="tf-color-1">*</span></div>
                                <input class="password-input" type="password" placeholder="Enter your password" name="password" tabindex="0" autocomplete="current-password" aria-required="true" required>
                                <span class="show-pass">
                                    <i class="icon-eye view"></i>
                                    <i class="icon-eye-off hide"></i>
                                </span>
                            </fieldset>
                            <div class="flex justify-between items-center">
                                <div class="flex gap10">
                                    <input class="" type="checkbox" id="signed">
                                    <label class="body-text" for="signed">Keep me signed in</label>
                                </div>
                            </div>
                            <button type="submit" class="tf-button w-full">Login</button>
                        </form>
                    </div>
                </div>
                <div class="text-tiny">© <?php echo date('Y'); ?> Jullies Develops. All rights reserved.</div>
            </div>
        </div>
        <!-- /#page -->
    </div>
    <!-- /#wrapper -->

    <!-- Javascript -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/bootstrap-select.min.js"></script>
    <script src="js/main.js"></script>

</body>


<!-- Mirrored from themesflat.co/html/remos/login.php by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 21 May 2026 05:34:50 GMT -->
</html>
