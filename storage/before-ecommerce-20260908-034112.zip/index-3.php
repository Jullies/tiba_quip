<?php
require_once __DIR__ . '/overall/bootstrap.php';
$bodyClass = 'home-3';
$pageScripts = [];
require __DIR__ . '/overall/head.php';
require __DIR__ . '/overall/header.php';
?>
<main class="main">

        <!-- hero slider -->
        <div class="hero-section hs-2">
            <div class="hero-slider owl-carousel owl-theme">
                <div class="hero-single">
                    <div class="hero-single-bg" style="background-image: url(assets/img/hero/slider-1.jpg)"></div>
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col-lg-6">
                                <div class="hero-content">
                                    <h6 class="hero-sub-title" data-animation="fadeInUp" data-delay=".25s">Easy Health Care</h6>
                                    <h1 class="hero-title" data-animation="fadeInRight" data-delay=".50s">
                                        Medicine & <span>Health Care</span> For Your Family in city
                                    </h1>
                                    <p data-animation="fadeInLeft" data-delay=".75s">
                                        There are many variations of passages orem psum available but the majority
                                        have suffered alteration in some form by injected humour.
                                    </p>
                                    <div class="hero-btn" data-animation="fadeInUp" data-delay="1s">
                                        <a href="shop-grid.php" class="theme-btn">Shop Now<i
                                                class="fas fa-arrow-right"></i></a>
                                        <a href="about.php" class="theme-btn theme-btn2">Learn More<i
                                                class="fas fa-arrow-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="hero-single">
                    <div class="hero-single-bg" style="background-image: url(assets/img/hero/slider-2.jpg)"></div>
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col-lg-6">
                                <div class="hero-content">
                                    <h6 class="hero-sub-title" data-animation="fadeInUp" data-delay=".25s">Easy Health Care</h6>
                                    <h1 class="hero-title" data-animation="fadeInRight" data-delay=".50s">
                                        Medicine & <span>Health Care</span> For Your Family in city
                                    </h1>
                                    <p data-animation="fadeInLeft" data-delay=".75s">
                                        There are many variations of passages orem psum available but the majority
                                        have suffered alteration in some form by injected humour.
                                    </p>
                                    <div class="hero-btn" data-animation="fadeInUp" data-delay="1s">
                                        <a href="shop-grid.php" class="theme-btn">Shop Now<i
                                                class="fas fa-arrow-right"></i></a>
                                        <a href="about.php" class="theme-btn theme-btn2">Learn More<i
                                                class="fas fa-arrow-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="hero-single">
                    <div class="hero-single-bg" style="background-image: url(assets/img/hero/slider-3.jpg)"></div>
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col-lg-6">
                                <div class="hero-content">
                                    <h6 class="hero-sub-title" data-animation="fadeInUp" data-delay=".25s">Easy Health Care</h6>
                                    <h1 class="hero-title" data-animation="fadeInRight" data-delay=".50s">
                                        Medicine & <span>Health Care</span> For Your Family in city
                                    </h1>
                                    <p data-animation="fadeInLeft" data-delay=".75s">
                                        There are many variations of passages orem psum available but the majority
                                        have suffered alteration in some form by injected humour.
                                    </p>
                                    <div class="hero-btn" data-animation="fadeInUp" data-delay="1s">
                                        <a href="shop-grid.php" class="theme-btn">Shop Now<i
                                                class="fas fa-arrow-right"></i></a>
                                        <a href="about.php" class="theme-btn theme-btn2">Learn More<i
                                                class="fas fa-arrow-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- hero slider end -->


        <!-- category area -->
        <div class="category-area2 pt-80 pb-100">
            <div class="container">
                <div class="category-slider owl-carousel owl-theme wow fadeInUp" data-wow-delay=".25s">
                    <div class="category-item">
                        <a href="#">
                            <div class="category-info">
                                <div class="icon">
                                    <img src="assets/img/icon/medicine.svg" alt="">
                                </div>
                                <div class="content">
                                    <h4>Medicine</h4>
                                    <p>30 Items</p>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="category-item">
                        <a href="#">
                            <div class="category-info">
                                <div class="icon">
                                    <img src="assets/img/icon/health-care.svg" alt="">
                                </div>
                                <div class="content">
                                    <h4>Healthcare</h4>
                                    <p>25 Items</p>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="category-item">
                        <a href="#">
                            <div class="category-info">
                                <div class="icon">
                                    <img src="assets/img/icon/beauty-care.svg" alt="">
                                </div>
                                <div class="content">
                                    <h4>Beauty Care</h4>
                                    <p>15 Items</p>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="category-item">
                        <a href="#">
                            <div class="category-info">
                                <div class="icon">
                                    <img src="assets/img/icon/sexual.svg" alt="">
                                </div>
                                <div class="content">
                                    <h4>Sexual Wellness</h4>
                                    <p>05 Items</p>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="category-item">
                        <a href="#">
                            <div class="category-info">
                                <div class="icon">
                                    <img src="assets/img/icon/fitness.svg" alt="">
                                </div>
                                <div class="content">
                                    <h4>Fitness</h4>
                                    <p>30 Items</p>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="category-item">
                        <a href="#">
                            <div class="category-info">
                                <div class="icon">
                                    <img src="assets/img/icon/lab-test.svg" alt="">
                                </div>
                                <div class="content">
                                    <h4>Lab Test</h4>
                                    <p>12 Items</p>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="category-item">
                        <a href="#">
                            <div class="category-info">
                                <div class="icon">
                                    <img src="assets/img/icon/baby-mom-care.svg" alt="">
                                </div>
                                <div class="content">
                                    <h4>Baby & Mom Care</h4>
                                    <p>08 Items</p>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="category-item">
                        <a href="#">
                            <div class="category-info">
                                <div class="icon">
                                    <img src="assets/img/icon/supplements.svg" alt="">
                                </div>
                                <div class="content">
                                    <h4>Supplement</h4>
                                    <p>14 Items</p>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="category-item">
                        <a href="#">
                            <div class="category-info">
                                <div class="icon">
                                    <img src="assets/img/icon/food-nutrition.svg" alt="">
                                </div>
                                <div class="content">
                                    <h4>Food & Nutrition</h4>
                                    <p>19 Items</p>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="category-item">
                        <a href="#">
                            <div class="category-info">
                                <div class="icon">
                                    <img src="assets/img/icon/medical-equipements.svg" alt="">
                                </div>
                                <div class="content">
                                    <h4>Equipments</h4>
                                    <p>24 Items</p>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="category-item">
                        <a href="#">
                            <div class="category-info">
                                <div class="icon">
                                    <img src="assets/img/icon/medical-supplies.svg" alt="">
                                </div>
                                <div class="content">
                                    <h4>Medical Supplies</h4>
                                    <p>09 Items</p>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="category-item">
                        <a href="#">
                            <div class="category-info">
                                <div class="icon">
                                    <img src="assets/img/icon/pet-care.svg" alt="">
                                </div>
                                <div class="content">
                                    <h4>Pet Care</h4>
                                    <p>16 Items</p>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <!-- category area end-->


        <!-- small banner -->
        <div class="small-banner pb-100">
            <div class="container wow fadeInUp" data-wow-delay=".25s">
                <div class="row g-4">
                    <div class="col-12 col-md-6 col-lg-4">
                        <div class="banner-item">
                            <img src="assets/img/banner/mini-banner-1.jpg" alt="">
                            <div class="banner-content">
                                <p>Sanitizer</p>
                                <h3>Hand Sanitizer <br> Collectons</h3>
                                <a href="#">Shop Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-4">
                        <div class="banner-item">
                            <img src="assets/img/banner/mini-banner-2.jpg" alt="">
                            <div class="banner-content">
                                <p>Hot Sale</p>
                                <h3>Face Wash Sale <br> Collections</h3>
                                <a href="#">Discover Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-4">
                        <div class="banner-item">
                            <img src="assets/img/banner/mini-banner-3.jpg" alt="">
                            <div class="banner-content">
                                <p>Facial Mask</p>
                                <h3>Facial Mask Sale <br> Up To <span>50%</span> Off</h3>
                                <a href="#">Discover Now</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- small banner end -->


        <!-- feature area -->
        <div class="feature-area pb-100">
            <div class="container wow fadeInUp" data-wow-delay=".25s">
                <div class="feature-wrap">
                    <div class="row g-0">
                        <div class="col-12 col-md-6 col-lg-3">
                            <div class="feature-item">
                                <div class="feature-icon">
                                    <i class="fal fa-truck"></i>
                                </div>
                                <div class="feature-content">
                                    <h4>Free Delivery</h4>
                                    <p>Orders Over $120</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-lg-3">
                            <div class="feature-item">
                                <div class="feature-icon">
                                    <i class="fal fa-sync"></i>
                                </div>
                                <div class="feature-content">
                                    <h4>Get Refund</h4>
                                    <p>Within 30 Days Returns</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-lg-3">
                            <div class="feature-item">
                                <div class="feature-icon">
                                    <i class="fal fa-wallet"></i>
                                </div>
                                <div class="feature-content">
                                    <h4>Safe Payment</h4>
                                    <p>100% Secure Payment</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-lg-3">
                            <div class="feature-item">
                                <div class="feature-icon">
                                    <i class="fal fa-headset"></i>
                                </div>
                                <div class="feature-content">
                                    <h4>24/7 Support</h4>
                                    <p>Feel Free To Call Us</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- feature area end -->


        <!-- popular item -->
        <div class="product-area pb-100">
            <div class="container">
                <div class="row g-4">
                    <div class="col-lg-3">
                        <div class="product-banner wow fadeInRight" data-wow-delay=".25s">
                            <a href="#">
                                <img src="assets/img/banner/product-banner.jpg" alt="">
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-9">
                        <div class="row">
                            <div class="col-12 wow fadeInDown" data-wow-delay=".25s">
                                <div class="site-heading-inline">
                                    <h2 class="site-title">Popular Items</h2>
                                    <a href="#">All Products <i class="fas fa-angle-double-right"></i></a>
                                </div>
                                <div class="item-tab">
                                    <ul class="nav nav-pills mt-40 mb-50" id="item-tab" role="tablist">
                                        <li class="nav-item" role="presentation">
                                            <button class="nav-link active" id="item-tab1" data-bs-toggle="pill"
                                                data-bs-target="#pill-item-tab1" type="button" role="tab"
                                                aria-controls="pill-item-tab1" aria-selected="true">Medicine</button>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                            <button class="nav-link" id="item-tab2" data-bs-toggle="pill"
                                                data-bs-target="#pill-item-tab2" type="button" role="tab"
                                                aria-controls="pill-item-tab2" aria-selected="false">Beauty Care</button>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                            <button class="nav-link" id="item-tab3" data-bs-toggle="pill"
                                                data-bs-target="#pill-item-tab3" type="button" role="tab"
                                                aria-controls="pill-item-tab3" aria-selected="false">Healthcare</button>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                            <button class="nav-link" id="item-tab4" data-bs-toggle="pill"
                                                data-bs-target="#pill-item-tab4" type="button" role="tab"
                                                aria-controls="pill-item-tab4" aria-selected="false">Baby & Mom Care</button>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                            <button class="nav-link" id="item-tab5" data-bs-toggle="pill"
                                                data-bs-target="#pill-item-tab5" type="button" role="tab"
                                                aria-controls="pill-item-tab5" aria-selected="false">Food & Nutrition</button>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                            <button class="nav-link" id="item-tab6" data-bs-toggle="pill"
                                                data-bs-target="#pill-item-tab6" type="button" role="tab"
                                                aria-controls="pill-item-tab6" aria-selected="false">Medical Equipments</button>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="tab-content wow fadeInUp" data-wow-delay=".25s" id="item-tabContent">
                            <div class="tab-pane show active" id="pill-item-tab1" role="tabpanel" aria-labelledby="item-tab1"
                                tabindex="0">
                                <div class="row g-3 item-3">
                                    <div class="col-md-6 col-lg-4 col-xl-3">
                                        <div class="product-item">
                                            <div class="product-img">
                                                <span class="type new">New</span>
                                                <a href="shop-single.php"><img src="assets/img/product/14.png" alt=""></a>
                                                <div class="product-action-wrap">
                                                    <div class="product-action">
                                                        <a href="#" data-bs-toggle="modal" data-bs-target="#quickview"
                                                            data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Quick View"><i class="far fa-eye"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Wishlist"><i class="far fa-heart"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Compare"><i class="far fa-arrows-repeat"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-content">
                                                <h3 class="product-title"><a href="shop-single.php">Surgical Face Mask</a></h3>
                                                <div class="product-rate">
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="far fa-star"></i>
                                                </div>
                                                <div class="product-bottom">
                                                    <div class="product-price">
                                                        <span>$250.00</span>
                                                    </div>
                                                    <button type="button" class="product-cart-btn" data-bs-placement="left"
                                                        data-tooltip="tooltip" title="Add To Cart">
                                                        <i class="far fa-shopping-bag"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-lg-4 col-xl-3">
                                        <div class="product-item">
                                            <div class="product-img">
                                                <span class="type hot">Hot</span>
                                                <a href="shop-single.php"><img src="assets/img/product/07.png" alt=""></a>
                                                <div class="product-action-wrap">
                                                    <div class="product-action">
                                                        <a href="#" data-bs-toggle="modal" data-bs-target="#quickview"
                                                            data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Quick View"><i class="far fa-eye"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Wishlist"><i class="far fa-heart"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Compare"><i class="far fa-arrows-repeat"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-content">
                                                <h3 class="product-title"><a href="shop-single.php">Surgical Face Mask</a></h3>
                                                <div class="product-rate">
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="far fa-star"></i>
                                                </div>
                                                <div class="product-bottom">
                                                    <div class="product-price">
                                                        <span>$250.00</span>
                                                    </div>
                                                    <button type="button" class="product-cart-btn" data-bs-placement="left"
                                                        data-tooltip="tooltip" title="Add To Cart">
                                                        <i class="far fa-shopping-bag"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-lg-4 col-xl-3">
                                        <div class="product-item">
                                            <div class="product-img">
                                                <span class="type oos">Out Of Stock</span>
                                                <a href="shop-single.php"><img src="assets/img/product/24.png" alt=""></a>
                                                <div class="product-action-wrap">
                                                    <div class="product-action">
                                                        <a href="#" data-bs-toggle="modal" data-bs-target="#quickview"
                                                            data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Quick View"><i class="far fa-eye"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Wishlist"><i class="far fa-heart"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Compare"><i class="far fa-arrows-repeat"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-content">
                                                <h3 class="product-title"><a href="shop-single.php">Surgical Face Mask</a></h3>
                                                <div class="product-rate">
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="far fa-star"></i>
                                                </div>
                                                <div class="product-bottom">
                                                    <div class="product-price">
                                                        <span>$250.00</span>
                                                    </div>
                                                    <button type="button" class="product-cart-btn" data-bs-placement="left"
                                                        data-tooltip="tooltip" title="Add To Cart">
                                                        <i class="far fa-shopping-bag"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-lg-4 col-xl-3">
                                        <div class="product-item">
                                            <div class="product-img">
                                                <span class="type discount">10% Off</span>
                                                <a href="shop-single.php"><img src="assets/img/product/15.png" alt=""></a>
                                                <div class="product-action-wrap">
                                                    <div class="product-action">
                                                        <a href="#" data-bs-toggle="modal" data-bs-target="#quickview"
                                                            data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Quick View"><i class="far fa-eye"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Wishlist"><i class="far fa-heart"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Compare"><i class="far fa-arrows-repeat"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-content">
                                                <h3 class="product-title"><a href="shop-single.php">Surgical Face Mask</a></h3>
                                                <div class="product-rate">
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="far fa-star"></i>
                                                </div>
                                                <div class="product-bottom">
                                                    <div class="product-price">
                                                        <del>$250.00</del>
                                                        <span>$190.00</span>
                                                    </div>
                                                    <button type="button" class="product-cart-btn" data-bs-placement="left"
                                                        data-tooltip="tooltip" title="Add To Cart">
                                                        <i class="far fa-shopping-bag"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="pill-item-tab2" role="tabpanel" aria-labelledby="item-tab2" tabindex="0">
                                <div class="row g-3 item-3">
                                    <div class="col-md-6 col-lg-4 col-xl-3">
                                        <div class="product-item">
                                            <div class="product-img">
                                                <span class="type new">New</span>
                                                <a href="shop-single.php"><img src="assets/img/product/10.png" alt=""></a>
                                                <div class="product-action-wrap">
                                                    <div class="product-action">
                                                        <a href="#" data-bs-toggle="modal" data-bs-target="#quickview"
                                                            data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Quick View"><i class="far fa-eye"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Wishlist"><i class="far fa-heart"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Compare"><i class="far fa-arrows-repeat"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-content">
                                                <h3 class="product-title"><a href="shop-single.php">Surgical Face Mask</a></h3>
                                                <div class="product-rate">
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="far fa-star"></i>
                                                </div>
                                                <div class="product-bottom">
                                                    <div class="product-price">
                                                        <span>$250.00</span>
                                                    </div>
                                                    <button type="button" class="product-cart-btn" data-bs-placement="left"
                                                        data-tooltip="tooltip" title="Add To Cart">
                                                        <i class="far fa-shopping-bag"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-lg-4 col-xl-3">
                                        <div class="product-item">
                                            <div class="product-img">
                                                <span class="type hot">Hot</span>
                                                <a href="shop-single.php"><img src="assets/img/product/11.png" alt=""></a>
                                                <div class="product-action-wrap">
                                                    <div class="product-action">
                                                        <a href="#" data-bs-toggle="modal" data-bs-target="#quickview"
                                                            data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Quick View"><i class="far fa-eye"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Wishlist"><i class="far fa-heart"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Compare"><i class="far fa-arrows-repeat"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-content">
                                                <h3 class="product-title"><a href="shop-single.php">Surgical Face Mask</a></h3>
                                                <div class="product-rate">
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="far fa-star"></i>
                                                </div>
                                                <div class="product-bottom">
                                                    <div class="product-price">
                                                        <span>$250.00</span>
                                                    </div>
                                                    <button type="button" class="product-cart-btn" data-bs-placement="left"
                                                        data-tooltip="tooltip" title="Add To Cart">
                                                        <i class="far fa-shopping-bag"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-lg-4 col-xl-3">
                                        <div class="product-item">
                                            <div class="product-img">
                                                <span class="type oos">Out Of Stock</span>
                                                <a href="shop-single.php"><img src="assets/img/product/12.png" alt=""></a>
                                                <div class="product-action-wrap">
                                                    <div class="product-action">
                                                        <a href="#" data-bs-toggle="modal" data-bs-target="#quickview"
                                                            data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Quick View"><i class="far fa-eye"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Wishlist"><i class="far fa-heart"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Compare"><i class="far fa-arrows-repeat"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-content">
                                                <h3 class="product-title"><a href="shop-single.php">Surgical Face Mask</a></h3>
                                                <div class="product-rate">
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="far fa-star"></i>
                                                </div>
                                                <div class="product-bottom">
                                                    <div class="product-price">
                                                        <span>$250.00</span>
                                                    </div>
                                                    <button type="button" class="product-cart-btn" data-bs-placement="left"
                                                        data-tooltip="tooltip" title="Add To Cart">
                                                        <i class="far fa-shopping-bag"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-lg-4 col-xl-3">
                                        <div class="product-item">
                                            <div class="product-img">
                                                <span class="type discount">10% Off</span>
                                                <a href="shop-single.php"><img src="assets/img/product/13.png" alt=""></a>
                                                <div class="product-action-wrap">
                                                    <div class="product-action">
                                                        <a href="#" data-bs-toggle="modal" data-bs-target="#quickview"
                                                            data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Quick View"><i class="far fa-eye"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Wishlist"><i class="far fa-heart"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Compare"><i class="far fa-arrows-repeat"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-content">
                                                <h3 class="product-title"><a href="shop-single.php">Surgical Face Mask</a></h3>
                                                <div class="product-rate">
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="far fa-star"></i>
                                                </div>
                                                <div class="product-bottom">
                                                    <div class="product-price">
                                                        <del>$250.00</del>
                                                        <span>$190.00</span>
                                                    </div>
                                                    <button type="button" class="product-cart-btn" data-bs-placement="left"
                                                        data-tooltip="tooltip" title="Add To Cart">
                                                        <i class="far fa-shopping-bag"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="pill-item-tab3" role="tabpanel" aria-labelledby="item-tab3" tabindex="0">
                                <div class="row g-3 item-3">
                                    <div class="col-md-6 col-lg-4 col-xl-3">
                                        <div class="product-item">
                                            <div class="product-img">
                                                <span class="type new">New</span>
                                                <a href="shop-single.php"><img src="assets/img/product/17.png" alt=""></a>
                                                <div class="product-action-wrap">
                                                    <div class="product-action">
                                                        <a href="#" data-bs-toggle="modal" data-bs-target="#quickview"
                                                            data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Quick View"><i class="far fa-eye"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Wishlist"><i class="far fa-heart"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Compare"><i class="far fa-arrows-repeat"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-content">
                                                <h3 class="product-title"><a href="shop-single.php">Surgical Face Mask</a></h3>
                                                <div class="product-rate">
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="far fa-star"></i>
                                                </div>
                                                <div class="product-bottom">
                                                    <div class="product-price">
                                                        <span>$250.00</span>
                                                    </div>
                                                    <button type="button" class="product-cart-btn" data-bs-placement="left"
                                                        data-tooltip="tooltip" title="Add To Cart">
                                                        <i class="far fa-shopping-bag"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-lg-4 col-xl-3">
                                        <div class="product-item">
                                            <div class="product-img">
                                                <span class="type hot">Hot</span>
                                                <a href="shop-single.php"><img src="assets/img/product/18.png" alt=""></a>
                                                <div class="product-action-wrap">
                                                    <div class="product-action">
                                                        <a href="#" data-bs-toggle="modal" data-bs-target="#quickview"
                                                            data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Quick View"><i class="far fa-eye"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Wishlist"><i class="far fa-heart"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Compare"><i class="far fa-arrows-repeat"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-content">
                                                <h3 class="product-title"><a href="shop-single.php">Surgical Face Mask</a></h3>
                                                <div class="product-rate">
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="far fa-star"></i>
                                                </div>
                                                <div class="product-bottom">
                                                    <div class="product-price">
                                                        <span>$250.00</span>
                                                    </div>
                                                    <button type="button" class="product-cart-btn" data-bs-placement="left"
                                                        data-tooltip="tooltip" title="Add To Cart">
                                                        <i class="far fa-shopping-bag"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-lg-4 col-xl-3">
                                        <div class="product-item">
                                            <div class="product-img">
                                                <span class="type oos">Out Of Stock</span>
                                                <a href="shop-single.php"><img src="assets/img/product/19.png" alt=""></a>
                                                <div class="product-action-wrap">
                                                    <div class="product-action">
                                                        <a href="#" data-bs-toggle="modal" data-bs-target="#quickview"
                                                            data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Quick View"><i class="far fa-eye"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Wishlist"><i class="far fa-heart"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Compare"><i class="far fa-arrows-repeat"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-content">
                                                <h3 class="product-title"><a href="shop-single.php">Surgical Face Mask</a></h3>
                                                <div class="product-rate">
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="far fa-star"></i>
                                                </div>
                                                <div class="product-bottom">
                                                    <div class="product-price">
                                                        <span>$250.00</span>
                                                    </div>
                                                    <button type="button" class="product-cart-btn" data-bs-placement="left"
                                                        data-tooltip="tooltip" title="Add To Cart">
                                                        <i class="far fa-shopping-bag"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-lg-4 col-xl-3">
                                        <div class="product-item">
                                            <div class="product-img">
                                                <span class="type discount">10% Off</span>
                                                <a href="shop-single.php"><img src="assets/img/product/20.png" alt=""></a>
                                                <div class="product-action-wrap">
                                                    <div class="product-action">
                                                        <a href="#" data-bs-toggle="modal" data-bs-target="#quickview"
                                                            data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Quick View"><i class="far fa-eye"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Wishlist"><i class="far fa-heart"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Compare"><i class="far fa-arrows-repeat"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-content">
                                                <h3 class="product-title"><a href="shop-single.php">Surgical Face Mask</a></h3>
                                                <div class="product-rate">
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="far fa-star"></i>
                                                </div>
                                                <div class="product-bottom">
                                                    <div class="product-price">
                                                        <del>$250.00</del>
                                                        <span>$190.00</span>
                                                    </div>
                                                    <button type="button" class="product-cart-btn" data-bs-placement="left"
                                                        data-tooltip="tooltip" title="Add To Cart">
                                                        <i class="far fa-shopping-bag"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="pill-item-tab4" role="tabpanel" aria-labelledby="item-tab4" tabindex="0">
                                <div class="row g-3 item-3">
                                    <div class="col-md-6 col-lg-4 col-xl-3">
                                        <div class="product-item">
                                            <div class="product-img">
                                                <span class="type new">New</span>
                                                <a href="shop-single.php"><img src="assets/img/product/22.png" alt=""></a>
                                                <div class="product-action-wrap">
                                                    <div class="product-action">
                                                        <a href="#" data-bs-toggle="modal" data-bs-target="#quickview"
                                                            data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Quick View"><i class="far fa-eye"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Wishlist"><i class="far fa-heart"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Compare"><i class="far fa-arrows-repeat"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-content">
                                                <h3 class="product-title"><a href="shop-single.php">Surgical Face Mask</a></h3>
                                                <div class="product-rate">
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="far fa-star"></i>
                                                </div>
                                                <div class="product-bottom">
                                                    <div class="product-price">
                                                        <span>$250.00</span>
                                                    </div>
                                                    <button type="button" class="product-cart-btn" data-bs-placement="left"
                                                        data-tooltip="tooltip" title="Add To Cart">
                                                        <i class="far fa-shopping-bag"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-lg-4 col-xl-3">
                                        <div class="product-item">
                                            <div class="product-img">
                                                <span class="type hot">Hot</span>
                                                <a href="shop-single.php"><img src="assets/img/product/23.png" alt=""></a>
                                                <div class="product-action-wrap">
                                                    <div class="product-action">
                                                        <a href="#" data-bs-toggle="modal" data-bs-target="#quickview"
                                                            data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Quick View"><i class="far fa-eye"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Wishlist"><i class="far fa-heart"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Compare"><i class="far fa-arrows-repeat"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-content">
                                                <h3 class="product-title"><a href="shop-single.php">Surgical Face Mask</a></h3>
                                                <div class="product-rate">
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="far fa-star"></i>
                                                </div>
                                                <div class="product-bottom">
                                                    <div class="product-price">
                                                        <span>$250.00</span>
                                                    </div>
                                                    <button type="button" class="product-cart-btn" data-bs-placement="left"
                                                        data-tooltip="tooltip" title="Add To Cart">
                                                        <i class="far fa-shopping-bag"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-lg-4 col-xl-3">
                                        <div class="product-item">
                                            <div class="product-img">
                                                <span class="type oos">Out Of Stock</span>
                                                <a href="shop-single.php"><img src="assets/img/product/24.png" alt=""></a>
                                                <div class="product-action-wrap">
                                                    <div class="product-action">
                                                        <a href="#" data-bs-toggle="modal" data-bs-target="#quickview"
                                                            data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Quick View"><i class="far fa-eye"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Wishlist"><i class="far fa-heart"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Compare"><i class="far fa-arrows-repeat"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-content">
                                                <h3 class="product-title"><a href="shop-single.php">Surgical Face Mask</a></h3>
                                                <div class="product-rate">
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="far fa-star"></i>
                                                </div>
                                                <div class="product-bottom">
                                                    <div class="product-price">
                                                        <span>$250.00</span>
                                                    </div>
                                                    <button type="button" class="product-cart-btn" data-bs-placement="left"
                                                        data-tooltip="tooltip" title="Add To Cart">
                                                        <i class="far fa-shopping-bag"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-lg-4 col-xl-3">
                                        <div class="product-item">
                                            <div class="product-img">
                                                <span class="type discount">10% Off</span>
                                                <a href="shop-single.php"><img src="assets/img/product/25.png" alt=""></a>
                                                <div class="product-action-wrap">
                                                    <div class="product-action">
                                                        <a href="#" data-bs-toggle="modal" data-bs-target="#quickview"
                                                            data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Quick View"><i class="far fa-eye"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Wishlist"><i class="far fa-heart"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Compare"><i class="far fa-arrows-repeat"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-content">
                                                <h3 class="product-title"><a href="shop-single.php">Surgical Face Mask</a></h3>
                                                <div class="product-rate">
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="far fa-star"></i>
                                                </div>
                                                <div class="product-bottom">
                                                    <div class="product-price">
                                                        <del>$250.00</del>
                                                        <span>$190.00</span>
                                                    </div>
                                                    <button type="button" class="product-cart-btn" data-bs-placement="left"
                                                        data-tooltip="tooltip" title="Add To Cart">
                                                        <i class="far fa-shopping-bag"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="pill-item-tab5" role="tabpanel" aria-labelledby="item-tab5" tabindex="0">
                                <div class="row g-3 item-3">
                                    <div class="col-md-6 col-lg-4 col-xl-3">
                                        <div class="product-item">
                                            <div class="product-img">
                                                <span class="type new">New</span>
                                                <a href="shop-single.php"><img src="assets/img/product/30.png" alt=""></a>
                                                <div class="product-action-wrap">
                                                    <div class="product-action">
                                                        <a href="#" data-bs-toggle="modal" data-bs-target="#quickview"
                                                            data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Quick View"><i class="far fa-eye"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Wishlist"><i class="far fa-heart"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Compare"><i class="far fa-arrows-repeat"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-content">
                                                <h3 class="product-title"><a href="shop-single.php">Surgical Face Mask</a></h3>
                                                <div class="product-rate">
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="far fa-star"></i>
                                                </div>
                                                <div class="product-bottom">
                                                    <div class="product-price">
                                                        <span>$250.00</span>
                                                    </div>
                                                    <button type="button" class="product-cart-btn" data-bs-placement="left"
                                                        data-tooltip="tooltip" title="Add To Cart">
                                                        <i class="far fa-shopping-bag"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-lg-4 col-xl-3">
                                        <div class="product-item">
                                            <div class="product-img">
                                                <span class="type hot">Hot</span>
                                                <a href="shop-single.php"><img src="assets/img/product/31.png" alt=""></a>
                                                <div class="product-action-wrap">
                                                    <div class="product-action">
                                                        <a href="#" data-bs-toggle="modal" data-bs-target="#quickview"
                                                            data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Quick View"><i class="far fa-eye"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Wishlist"><i class="far fa-heart"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Compare"><i class="far fa-arrows-repeat"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-content">
                                                <h3 class="product-title"><a href="shop-single.php">Surgical Face Mask</a></h3>
                                                <div class="product-rate">
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="far fa-star"></i>
                                                </div>
                                                <div class="product-bottom">
                                                    <div class="product-price">
                                                        <span>$250.00</span>
                                                    </div>
                                                    <button type="button" class="product-cart-btn" data-bs-placement="left"
                                                        data-tooltip="tooltip" title="Add To Cart">
                                                        <i class="far fa-shopping-bag"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-lg-4 col-xl-3">
                                        <div class="product-item">
                                            <div class="product-img">
                                                <span class="type oos">Out Of Stock</span>
                                                <a href="shop-single.php"><img src="assets/img/product/32.png" alt=""></a>
                                                <div class="product-action-wrap">
                                                    <div class="product-action">
                                                        <a href="#" data-bs-toggle="modal" data-bs-target="#quickview"
                                                            data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Quick View"><i class="far fa-eye"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Wishlist"><i class="far fa-heart"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Compare"><i class="far fa-arrows-repeat"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-content">
                                                <h3 class="product-title"><a href="shop-single.php">Surgical Face Mask</a></h3>
                                                <div class="product-rate">
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="far fa-star"></i>
                                                </div>
                                                <div class="product-bottom">
                                                    <div class="product-price">
                                                        <span>$250.00</span>
                                                    </div>
                                                    <button type="button" class="product-cart-btn" data-bs-placement="left"
                                                        data-tooltip="tooltip" title="Add To Cart">
                                                        <i class="far fa-shopping-bag"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-lg-4 col-xl-3">
                                        <div class="product-item">
                                            <div class="product-img">
                                                <span class="type discount">10% Off</span>
                                                <a href="shop-single.php"><img src="assets/img/product/33.png" alt=""></a>
                                                <div class="product-action-wrap">
                                                    <div class="product-action">
                                                        <a href="#" data-bs-toggle="modal" data-bs-target="#quickview"
                                                            data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Quick View"><i class="far fa-eye"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Wishlist"><i class="far fa-heart"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Compare"><i class="far fa-arrows-repeat"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-content">
                                                <h3 class="product-title"><a href="shop-single.php">Surgical Face Mask</a></h3>
                                                <div class="product-rate">
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="far fa-star"></i>
                                                </div>
                                                <div class="product-bottom">
                                                    <div class="product-price">
                                                        <del>$250.00</del>
                                                        <span>$190.00</span>
                                                    </div>
                                                    <button type="button" class="product-cart-btn" data-bs-placement="left"
                                                        data-tooltip="tooltip" title="Add To Cart">
                                                        <i class="far fa-shopping-bag"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="pill-item-tab6" role="tabpanel" aria-labelledby="item-tab6" tabindex="0">
                                <div class="row g-3 item-3">
                                    <div class="col-md-6 col-lg-4 col-xl-3">
                                        <div class="product-item">
                                            <div class="product-img">
                                                <span class="type new">New</span>
                                                <a href="shop-single.php"><img src="assets/img/product/34.png" alt=""></a>
                                                <div class="product-action-wrap">
                                                    <div class="product-action">
                                                        <a href="#" data-bs-toggle="modal" data-bs-target="#quickview"
                                                            data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Quick View"><i class="far fa-eye"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Wishlist"><i class="far fa-heart"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Compare"><i class="far fa-arrows-repeat"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-content">
                                                <h3 class="product-title"><a href="shop-single.php">Surgical Face Mask</a></h3>
                                                <div class="product-rate">
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="far fa-star"></i>
                                                </div>
                                                <div class="product-bottom">
                                                    <div class="product-price">
                                                        <span>$250.00</span>
                                                    </div>
                                                    <button type="button" class="product-cart-btn" data-bs-placement="left"
                                                        data-tooltip="tooltip" title="Add To Cart">
                                                        <i class="far fa-shopping-bag"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-lg-4 col-xl-3">
                                        <div class="product-item">
                                            <div class="product-img">
                                                <span class="type hot">Hot</span>
                                                <a href="shop-single.php"><img src="assets/img/product/35.png" alt=""></a>
                                                <div class="product-action-wrap">
                                                    <div class="product-action">
                                                        <a href="#" data-bs-toggle="modal" data-bs-target="#quickview"
                                                            data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Quick View"><i class="far fa-eye"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Wishlist"><i class="far fa-heart"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Compare"><i class="far fa-arrows-repeat"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-content">
                                                <h3 class="product-title"><a href="shop-single.php">Surgical Face Mask</a></h3>
                                                <div class="product-rate">
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="far fa-star"></i>
                                                </div>
                                                <div class="product-bottom">
                                                    <div class="product-price">
                                                        <span>$250.00</span>
                                                    </div>
                                                    <button type="button" class="product-cart-btn" data-bs-placement="left"
                                                        data-tooltip="tooltip" title="Add To Cart">
                                                        <i class="far fa-shopping-bag"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-lg-4 col-xl-3">
                                        <div class="product-item">
                                            <div class="product-img">
                                                <span class="type oos">Out Of Stock</span>
                                                <a href="shop-single.php"><img src="assets/img/product/36.png" alt=""></a>
                                                <div class="product-action-wrap">
                                                    <div class="product-action">
                                                        <a href="#" data-bs-toggle="modal" data-bs-target="#quickview"
                                                            data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Quick View"><i class="far fa-eye"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Wishlist"><i class="far fa-heart"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Compare"><i class="far fa-arrows-repeat"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-content">
                                                <h3 class="product-title"><a href="shop-single.php">Surgical Face Mask</a></h3>
                                                <div class="product-rate">
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="far fa-star"></i>
                                                </div>
                                                <div class="product-bottom">
                                                    <div class="product-price">
                                                        <span>$250.00</span>
                                                    </div>
                                                    <button type="button" class="product-cart-btn" data-bs-placement="left"
                                                        data-tooltip="tooltip" title="Add To Cart">
                                                        <i class="far fa-shopping-bag"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-lg-4 col-xl-3">
                                        <div class="product-item">
                                            <div class="product-img">
                                                <span class="type discount">10% Off</span>
                                                <a href="shop-single.php"><img src="assets/img/product/37.png" alt=""></a>
                                                <div class="product-action-wrap">
                                                    <div class="product-action">
                                                        <a href="#" data-bs-toggle="modal" data-bs-target="#quickview"
                                                            data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Quick View"><i class="far fa-eye"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Wishlist"><i class="far fa-heart"></i></a>
                                                        <a href="#" data-bs-placement="top" data-tooltip="tooltip"
                                                            title="Add To Compare"><i class="far fa-arrows-repeat"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-content">
                                                <h3 class="product-title"><a href="shop-single.php">Surgical Face Mask</a></h3>
                                                <div class="product-rate">
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="far fa-star"></i>
                                                </div>
                                                <div class="product-bottom">
                                                    <div class="product-price">
                                                        <del>$250.00</del>
                                                        <span>$190.00</span>
                                                    </div>
                                                    <button type="button" class="product-cart-btn" data-bs-placement="left"
                                                        data-tooltip="tooltip" title="Add To Cart">
                                                        <i class="far fa-shopping-bag"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- popular item end -->


        <!-- trending item -->
        <div class="product-area pb-100">
            <div class="container">
                <div class="row">
                    <div class="col-12 wow fadeInDown" data-wow-delay=".25s">
                        <div class="site-heading-inline">
                            <h2 class="site-title">Trending Items</h2>
                            <a href="#">View More <i class="fas fa-angle-double-right"></i></a>
                        </div>
                    </div>
                </div>
                <div class="product-wrap item-3 wow fadeInUp" data-wow-delay=".25s">
                    <div class="product-slider owl-carousel owl-theme">
                        <div class="product-item">
                            <div class="product-img">
                                <span class="type new">New</span>
                                <a href="shop-single.php"><img src="assets/img/product/01.png" alt=""></a>
                                <div class="product-action-wrap">
                                    <div class="product-action">
                                        <a href="#" data-bs-toggle="modal" data-bs-target="#quickview"
                                            data-tooltip="tooltip" title="Quick View"><i class="far fa-eye"></i></a>
                                        <a href="#" data-tooltip="tooltip" title="Add To Wishlist"><i
                                                class="far fa-heart"></i></a>
                                        <a href="#" data-tooltip="tooltip" title="Add To Compare"><i
                                                class="far fa-arrows-repeat"></i></a>
                                    </div>
                                </div>
                            </div>
                            <div class="product-content">
                                <h3 class="product-title"><a href="shop-single.php">Surgical Face Mask</a></h3>
                                <div class="product-rate">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="far fa-star"></i>
                                </div>
                                <div class="product-bottom">
                                    <div class="product-price">
                                        <span>$250.00</span>
                                    </div>
                                    <button type="button" class="product-cart-btn" data-bs-placement="left"
                                        data-tooltip="tooltip" title="Add To Cart">
                                        <i class="far fa-shopping-bag"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="product-item">
                            <div class="product-img">
                                <span class="type hot">Hot</span>
                                <a href="shop-single.php"><img src="assets/img/product/02.png" alt=""></a>
                                <div class="product-action-wrap">
                                    <div class="product-action">
                                        <a href="#" data-bs-toggle="modal" data-bs-target="#quickview"
                                            data-tooltip="tooltip" title="Quick View"><i class="far fa-eye"></i></a>
                                        <a href="#" data-tooltip="tooltip" title="Add To Wishlist"><i
                                                class="far fa-heart"></i></a>
                                        <a href="#" data-tooltip="tooltip" title="Add To Compare"><i
                                                class="far fa-arrows-repeat"></i></a>
                                    </div>
                                </div>
                            </div>
                            <div class="product-content">
                                <h3 class="product-title"><a href="shop-single.php">Surgical Face Mask</a></h3>
                                <div class="product-rate">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="far fa-star"></i>
                                </div>
                                <div class="product-bottom">
                                    <div class="product-price">
                                        <span>$250.00</span>
                                    </div>
                                    <button type="button" class="product-cart-btn" data-bs-placement="left"
                                        data-tooltip="tooltip" title="Add To Cart">
                                        <i class="far fa-shopping-bag"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="product-item">
                            <div class="product-img">
                                <span class="type oos">Out Of Stock</span>
                                <a href="shop-single.php"><img src="assets/img/product/03.png" alt=""></a>
                                <div class="product-action-wrap">
                                    <div class="product-action">
                                        <a href="#" data-bs-toggle="modal" data-bs-target="#quickview"
                                            data-tooltip="tooltip" title="Quick View"><i class="far fa-eye"></i></a>
                                        <a href="#" data-tooltip="tooltip" title="Add To Wishlist"><i
                                                class="far fa-heart"></i></a>
                                        <a href="#" data-tooltip="tooltip" title="Add To Compare"><i
                                                class="far fa-arrows-repeat"></i></a>
                                    </div>
                                </div>
                            </div>
                            <div class="product-content">
                                <h3 class="product-title"><a href="shop-single.php">Surgical Face Mask</a></h3>
                                <div class="product-rate">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="far fa-star"></i>
                                </div>
                                <div class="product-bottom">
                                    <div class="product-price">
                                        <span>$250.00</span>
                                    </div>
                                    <button type="button" class="product-cart-btn" data-bs-placement="left"
                                        data-tooltip="tooltip" title="Add To Cart">
                                        <i class="far fa-shopping-bag"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="product-item">
                            <div class="product-img">
                                <span class="type discount">10% Off</span>
                                <a href="shop-single.php"><img src="assets/img/product/04.png" alt=""></a>
                                <div class="product-action-wrap">
                                    <div class="product-action">
                                        <a href="#" data-bs-toggle="modal" data-bs-target="#quickview"
                                            data-tooltip="tooltip" title="Quick View"><i class="far fa-eye"></i></a>
                                        <a href="#" data-tooltip="tooltip" title="Add To Wishlist"><i
                                                class="far fa-heart"></i></a>
                                        <a href="#" data-tooltip="tooltip" title="Add To Compare"><i
                                                class="far fa-arrows-repeat"></i></a>
                                    </div>
                                </div>
                            </div>
                            <div class="product-content">
                                <h3 class="product-title"><a href="shop-single.php">Surgical Face Mask</a></h3>
                                <div class="product-rate">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="far fa-star"></i>
                                </div>
                                <div class="product-bottom">
                                    <div class="product-price">
                                        <del>$250.00</del>
                                        <span>$190.00</span>
                                    </div>
                                    <button type="button" class="product-cart-btn" data-bs-placement="left"
                                        data-tooltip="tooltip" title="Add To Cart">
                                        <i class="far fa-shopping-bag"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="product-item">
                            <div class="product-img">
                                <a href="shop-single.php"><img src="assets/img/product/05.png" alt=""></a>
                                <div class="product-action-wrap">
                                    <div class="product-action">
                                        <a href="#" data-bs-toggle="modal" data-bs-target="#quickview"
                                            data-tooltip="tooltip" title="Quick View"><i class="far fa-eye"></i></a>
                                        <a href="#" data-tooltip="tooltip" title="Add To Wishlist"><i
                                                class="far fa-heart"></i></a>
                                        <a href="#" data-tooltip="tooltip" title="Add To Compare"><i
                                                class="far fa-arrows-repeat"></i></a>
                                    </div>
                                </div>
                            </div>
                            <div class="product-content">
                                <h3 class="product-title"><a href="shop-single.php">Surgical Face Mask</a></h3>
                                <div class="product-rate">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="far fa-star"></i>
                                </div>
                                <div class="product-bottom">
                                    <div class="product-price">
                                        <span>$250.00</span>
                                    </div>
                                    <button type="button" class="product-cart-btn" data-bs-placement="left"
                                        data-tooltip="tooltip" title="Add To Cart">
                                        <i class="far fa-shopping-bag"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="product-item">
                            <div class="product-img">
                                <a href="shop-single.php"><img src="assets/img/product/06.png" alt=""></a>
                                <div class="product-action-wrap">
                                    <div class="product-action">
                                        <a href="#" data-bs-toggle="modal" data-bs-target="#quickview"
                                            data-tooltip="tooltip" title="Quick View"><i class="far fa-eye"></i></a>
                                        <a href="#" data-tooltip="tooltip" title="Add To Wishlist"><i
                                                class="far fa-heart"></i></a>
                                        <a href="#" data-tooltip="tooltip" title="Add To Compare"><i
                                                class="far fa-arrows-repeat"></i></a>
                                    </div>
                                </div>
                            </div>
                            <div class="product-content">
                                <h3 class="product-title"><a href="shop-single.php">Surgical Face Mask</a></h3>
                                <div class="product-rate">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="far fa-star"></i>
                                </div>
                                <div class="product-bottom">
                                    <div class="product-price">
                                        <span>$250.00</span>
                                    </div>
                                    <button type="button" class="product-cart-btn" data-bs-placement="left"
                                        data-tooltip="tooltip" title="Add To Cart">
                                        <i class="far fa-shopping-bag"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- trending item end -->


        <!-- big banner -->
        <div class="big-banner">
            <div class="container wow fadeInUp" data-wow-delay=".25s">
                <div class="banner-wrap" style="background-image: url(assets/img/banner/big-banner.jpg);">
                    <div class="row">
                        <div class="col-lg-8 mx-auto">
                            <div class="banner-content">
                                <div class="banner-info">
                                    <h6>Mega Collections</h6>
                                    <h2>Huge Sale Up To <span>40%</span> Off</h2>
                                    <p>at our outlet stores</p>
                                </div>
                                <a href="#" class="theme-btn">Shop Now<i class="fas fa-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- big banner end -->


        <!-- brand area -->
        <div class="brand-area pt-80">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="site-heading-inline">
                            <h2 class="site-title">Popular Brands</h2>
                            <a href="#">All Brands <i class="fas fa-angle-double-right"></i></a>
                        </div>
                    </div>
                </div>
                <div class="brand-slider owl-carousel owl-theme">
                    <div class="brand-item">
                        <a href="#">
                            <img src="assets/img/brand/01.png" alt="">
                        </a>
                    </div>
                    <div class="brand-item">
                        <a href="#">
                            <img src="assets/img/brand/02.png" alt="">
                        </a>
                    </div>
                    <div class="brand-item">
                        <a href="#">
                            <img src="assets/img/brand/03.png" alt="">
                        </a>
                    </div>
                    <div class="brand-item">
                        <a href="#">
                            <img src="assets/img/brand/04.png" alt="">
                        </a>
                    </div>
                    <div class="brand-item">
                        <a href="#">
                            <img src="assets/img/brand/05.png" alt="">
                        </a>
                    </div>
                    <div class="brand-item">
                        <a href="#">
                            <img src="assets/img/brand/06.png" alt="">
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <!-- brand area end -->


        <!-- product list -->
        <div class="product-list py-100">
            <div class="container wow fadeInUp" data-wow-delay=".25s">
                <div class="row g-4">
                    <div class="col-12 col-md-6 col-lg-6 col-xl-4">
                        <div class="product-list-box border">
                            <h2 class="product-list-title">On sale</h2>
                            <div class="product-list-item">
                                <div class="product-list-img">
                                    <a href="shop-single.php"><img src="assets/img/product/01.png" alt="#"></a>
                                </div>
                                <div class="product-list-content">
                                    <h4><a href="shop-single.php">Surgical Face Mask</a></h4>
                                    <div class="product-list-rate">
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="far fa-star"></i>
                                    </div>
                                    <div class="product-list-price">
                                        <del>60.00</del><span>$40.00</span>
                                    </div>
                                </div>
                                <a href="#" class="product-list-btn" data-bs-placement="left" data-tooltip="tooltip"
                                    title="Add To Cart"><i class="far fa-shopping-bag"></i></a>
                            </div>
                            <div class="product-list-item">
                                <div class="product-list-img">
                                    <a href="shop-single.php"><img src="assets/img/product/02.png" alt="#"></a>
                                </div>
                                <div class="product-list-content">
                                    <h4><a href="shop-single.php">Surgical Face Mask</a></h4>
                                    <div class="product-list-rate">
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="far fa-star"></i>
                                    </div>
                                    <div class="product-list-price">
                                        <del>60.00</del><span>$40.00</span>
                                    </div>
                                </div>
                                <a href="#" class="product-list-btn" data-bs-placement="left" data-tooltip="tooltip"
                                    title="Add To Cart"><i class="far fa-shopping-bag"></i></a>
                            </div>
                            <div class="product-list-item">
                                <div class="product-list-img">
                                    <a href="shop-single.php"><img src="assets/img/product/03.png" alt="#"></a>
                                </div>
                                <div class="product-list-content">
                                    <h4><a href="shop-single.php">Surgical Face Mask</a></h4>
                                    <div class="product-list-rate">
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="far fa-star"></i>
                                    </div>
                                    <div class="product-list-price">
                                        <del>60.00</del><span>$40.00</span>
                                    </div>
                                </div>
                                <a href="#" class="product-list-btn" data-bs-placement="left" data-tooltip="tooltip"
                                    title="Add To Cart"><i class="far fa-shopping-bag"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-6 col-xl-4">
                        <div class="product-list-box border">
                            <h2 class="product-list-title">Best Seller</h2>
                            <div class="product-list-item">
                                <div class="product-list-img">
                                    <a href="shop-single.php"><img src="assets/img/product/04.png" alt="#"></a>
                                </div>
                                <div class="product-list-content">
                                    <h4><a href="shop-single.php">Surgical Face Mask</a></h4>
                                    <div class="product-list-rate">
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="far fa-star"></i>
                                    </div>
                                    <div class="product-list-price">
                                        <del>60.00</del><span>$40.00</span>
                                    </div>
                                </div>
                                <a href="#" class="product-list-btn" data-bs-placement="left" data-tooltip="tooltip"
                                    title="Add To Cart"><i class="far fa-shopping-bag"></i></a>
                            </div>
                            <div class="product-list-item">
                                <div class="product-list-img">
                                    <a href="shop-single.php"><img src="assets/img/product/05.png" alt="#"></a>
                                </div>
                                <div class="product-list-content">
                                    <h4><a href="shop-single.php">Surgical Face Mask</a></h4>
                                    <div class="product-list-rate">
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="far fa-star"></i>
                                    </div>
                                    <div class="product-list-price">
                                        <del>60.00</del><span>$40.00</span>
                                    </div>
                                </div>
                                <a href="#" class="product-list-btn" data-bs-placement="left" data-tooltip="tooltip"
                                    title="Add To Cart"><i class="far fa-shopping-bag"></i></a>
                            </div>
                            <div class="product-list-item">
                                <div class="product-list-img">
                                    <a href="shop-single.php"><img src="assets/img/product/06.png" alt="#"></a>
                                </div>
                                <div class="product-list-content">
                                    <h4><a href="shop-single.php">Surgical Face Mask</a></h4>
                                    <div class="product-list-rate">
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="far fa-star"></i>
                                    </div>
                                    <div class="product-list-price">
                                        <del>60.00</del><span>$40.00</span>
                                    </div>
                                </div>
                                <a href="#" class="product-list-btn" data-bs-placement="left" data-tooltip="tooltip"
                                    title="Add To Cart"><i class="far fa-shopping-bag"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-6 col-xl-4">
                        <div class="product-list-box border">
                            <h2 class="product-list-title">Top Rated</h2>
                            <div class="product-list-item">
                                <div class="product-list-img">
                                    <a href="shop-single.php"><img src="assets/img/product/07.png" alt="#"></a>
                                </div>
                                <div class="product-list-content">
                                    <h4><a href="shop-single.php">Surgical Face Mask</a></h4>
                                    <div class="product-list-rate">
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="far fa-star"></i>
                                    </div>
                                    <div class="product-list-price">
                                        <del>60.00</del><span>$40.00</span>
                                    </div>
                                </div>
                                <a href="#" class="product-list-btn" data-bs-placement="left" data-tooltip="tooltip"
                                    title="Add To Cart"><i class="far fa-shopping-bag"></i></a>
                            </div>
                            <div class="product-list-item">
                                <div class="product-list-img">
                                    <a href="shop-single.php"><img src="assets/img/product/08.png" alt="#"></a>
                                </div>
                                <div class="product-list-content">
                                    <h4><a href="shop-single.php">Surgical Face Mask</a></h4>
                                    <div class="product-list-rate">
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="far fa-star"></i>
                                    </div>
                                    <div class="product-list-price">
                                        <del>60.00</del><span>$40.00</span>
                                    </div>
                                </div>
                                <a href="#" class="product-list-btn" data-bs-placement="left" data-tooltip="tooltip"
                                    title="Add To Cart"><i class="far fa-shopping-bag"></i></a>
                            </div>
                            <div class="product-list-item">
                                <div class="product-list-img">
                                    <a href="shop-single.php"><img src="assets/img/product/09.png" alt="#"></a>
                                </div>
                                <div class="product-list-content">
                                    <h4><a href="shop-single.php">Surgical Face Mask</a></h4>
                                    <div class="product-list-rate">
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="far fa-star"></i>
                                    </div>
                                    <div class="product-list-price">
                                        <del>60.00</del><span>$40.00</span>
                                    </div>
                                </div>
                                <a href="#" class="product-list-btn" data-bs-placement="left" data-tooltip="tooltip"
                                    title="Add To Cart"><i class="far fa-shopping-bag"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- product list end -->


        <!-- deal area -->
        <div class="deal-area pt-50 pb-50">
            <div class="deal-text-shape">Deal</div>
            <div class="container">
                <div class="deal-wrap wow fadeInUp" data-wow-delay=".25s">
                    <div class="deal-slider owl-carousel owl-theme">
                        <div class="deal-item">
                            <div class="row align-items-center">
                                <div class="col-lg-6">
                                    <div class="deal-content">
                                        <div class="deal-info">
                                            <span>Weekly Deal</span>
                                            <h1>Best Deal For This Week</h1>
                                            <p>There are many variations of passages available but the majority have
                                                suffered alteration in some form
                                                by injected humour, or randomised words which don't look even slightly
                                                believable.</p>
                                        </div>
                                        <div class="deal-countdown">
                                            <div class="countdown" data-countdown="2025/12/30"></div>
                                        </div>
                                        <a href="#" class="theme-btn theme-btn2">Shop Now <i
                                                class="fas fa-arrow-right"></i></a>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="deal-img">
                                        <img src="assets/img/deal/01.png" alt="">
                                        <div class="deal-discount">
                                            <span>35%</span>
                                            <span>off</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="deal-item">
                            <div class="row align-items-center">
                                <div class="col-lg-6">
                                    <div class="deal-content">
                                        <div class="deal-info">
                                            <span>Weekly Deal</span>
                                            <h1>Best Deal For This Week</h1>
                                            <p>There are many variations of passages available but the majority have
                                                suffered alteration in some form
                                                by injected humour, or randomised words which don't look even slightly
                                                believable.</p>
                                        </div>
                                        <div class="deal-countdown">
                                            <div class="countdown" data-countdown="2025/12/30"></div>
                                        </div>
                                        <a href="#" class="theme-btn theme-btn2">Shop Now <i
                                                class="fas fa-arrow-right"></i></a>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="deal-img">
                                        <img src="assets/img/deal/02.png" alt="">
                                        <div class="deal-discount">
                                            <span>35%</span>
                                            <span>off</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="deal-item">
                            <div class="row align-items-center">
                                <div class="col-lg-6">
                                    <div class="deal-content">
                                        <div class="deal-info">
                                            <span>Weekly Deal</span>
                                            <h1>Best Deal For This Week</h1>
                                            <p>There are many variations of passages available but the majority have
                                                suffered alteration in some form
                                                by injected humour, or randomised words which don't look even slightly
                                                believable.</p>
                                        </div>
                                        <div class="deal-countdown">
                                            <div class="countdown" data-countdown="2025/12/30"></div>
                                        </div>
                                        <a href="#" class="theme-btn theme-btn2">Shop Now <i
                                                class="fas fa-arrow-right"></i></a>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="deal-img">
                                        <img src="assets/img/deal/03.png" alt="">
                                        <div class="deal-discount">
                                            <span>35%</span>
                                            <span>off</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- deal area end -->


        <!-- gallery-area -->
        <div class="gallery-area py-100">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 mx-auto">
                        <div class="site-heading text-center">
                            <span class="site-title-tagline">Our Gallery</span>
                            <h2 class="site-title">Let's Check Our Photo <span>Gallery</span></h2>
                        </div>
                    </div>
                </div>
                <div class="row g-4 popup-gallery">
                    <div class="col-md-12 col-lg-6">
                        <div class="gallery-item gallery-btn-active wow fadeInUp" data-wow-delay=".25s">
                            <div class="gallery-img">
                                <img src="assets/img/gallery/01.jpg" alt="">
                                <a class="popup-img gallery-link" href="assets/img/gallery/01.jpg"><i
                                    class="fal fa-plus"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-lg-3">
                        <div class="gallery-item wow fadeInDown" data-wow-delay=".25s">
                            <div class="gallery-img">
                                <img src="assets/img/gallery/02.jpg" alt="">
                                <a class="popup-img gallery-link" href="assets/img/gallery/02.jpg"><i
                                        class="fal fa-plus"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-lg-3">
                        <div class="gallery-item wow fadeInUp" data-wow-delay=".25s">
                            <div class="gallery-img">
                                <img src="assets/img/gallery/03.jpg" alt="">
                                <a class="popup-img gallery-link" href="assets/img/gallery/03.jpg"><i
                                        class="fal fa-plus"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-lg-3">
                        <div class="gallery-item wow fadeInDown" data-wow-delay=".25s">
                            <div class="gallery-img">
                                <img src="assets/img/gallery/04.jpg" alt="">
                                <a class="popup-img gallery-link" href="assets/img/gallery/04.jpg"><i
                                        class="fal fa-plus"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-lg-3">
                        <div class="gallery-item wow fadeInUp" data-wow-delay=".25s">
                            <div class="gallery-img">
                                <img src="assets/img/gallery/05.jpg" alt="">
                                <a class="popup-img gallery-link" href="assets/img/gallery/05.jpg"><i
                                        class="fal fa-plus"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8 col-lg-6">
                        <div class="gallery-item wow fadeInDown" data-wow-delay=".25s">
                            <div class="gallery-img">
                                <img src="assets/img/gallery/06.jpg" alt="">
                                <a class="popup-img gallery-link" href="assets/img/gallery/06.jpg"><i
                                        class="fal fa-plus"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- gallery-area end -->


        <!-- testimonial area -->
        <div class="testimonial-area ts-bg py-80">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 mx-auto wow fadeInDown" data-wow-delay=".25s">
                        <div class="site-heading text-center">
                            <span class="site-title-tagline">Testimonials</span>
                            <h2 class="site-title text-white">What Our Client Say's <span>About Us</span></h2>
                        </div>
                    </div>
                </div>
                <div class="testimonial-slider owl-carousel owl-theme wow fadeInUp" data-wow-delay=".25s">
                    <div class="testimonial-item">
                        <div class="testimonial-author">
                            <div class="testimonial-author-img">
                                <img src="assets/img/testimonial/01.jpg" alt="">
                            </div>
                            <div class="testimonial-author-info">
                                <h4>Sylvia H Green</h4>
                                <p>Customer</p>
                            </div>
                        </div>
                        <div class="testimonial-quote">
                            <p>
                                There are many variations of long passages available but the content majority have
                                suffered to the editor page when looking at its layout alteration in some injected.
                            </p>
                        </div>
                        <div class="testimonial-rate">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <div class="testimonial-quote-icon"><img src="assets/img/icon/quote.svg" alt=""></div>
                    </div>
                    <div class="testimonial-item">
                        <div class="testimonial-author">
                            <div class="testimonial-author-img">
                                <img src="assets/img/testimonial/02.jpg" alt="">
                            </div>
                            <div class="testimonial-author-info">
                                <h4>Gordo Novak</h4>
                                <p>Customer</p>
                            </div>
                        </div>
                        <div class="testimonial-quote">
                            <p>
                                There are many variations of long passages available but the content majority have
                                suffered to the editor page when looking at its layout alteration in some injected.
                            </p>
                        </div>
                        <div class="testimonial-rate">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <div class="testimonial-quote-icon"><img src="assets/img/icon/quote.svg" alt=""></div>
                    </div>
                    <div class="testimonial-item">
                        <div class="testimonial-author">
                            <div class="testimonial-author-img">
                                <img src="assets/img/testimonial/03.jpg" alt="">
                            </div>
                            <div class="testimonial-author-info">
                                <h4>Reid E Butt</h4>
                                <p>Customer</p>
                            </div>
                        </div>
                        <div class="testimonial-quote">
                            <p>
                                There are many variations of long passages available but the content majority have
                                suffered to the editor page when looking at its layout alteration in some injected.
                            </p>
                        </div>
                        <div class="testimonial-rate">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <div class="testimonial-quote-icon"><img src="assets/img/icon/quote.svg" alt=""></div>
                    </div>
                    <div class="testimonial-item">
                        <div class="testimonial-author">
                            <div class="testimonial-author-img">
                                <img src="assets/img/testimonial/04.jpg" alt="">
                            </div>
                            <div class="testimonial-author-info">
                                <h4>Parker Jimenez</h4>
                                <p>Customer</p>
                            </div>
                        </div>
                        <div class="testimonial-quote">
                            <p>
                                There are many variations of long passages available but the content majority have
                                suffered to the editor page when looking at its layout alteration in some injected.
                            </p>
                        </div>
                        <div class="testimonial-rate">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <div class="testimonial-quote-icon"><img src="assets/img/icon/quote.svg" alt=""></div>
                    </div>
                    <div class="testimonial-item">
                        <div class="testimonial-author">
                            <div class="testimonial-author-img">
                                <img src="assets/img/testimonial/05.jpg" alt="">
                            </div>
                            <div class="testimonial-author-info">
                                <h4>Heruli Nez</h4>
                                <p>Customer</p>
                            </div>
                        </div>
                        <div class="testimonial-quote">
                            <p>
                                There are many variations of long passages available but the content majority have
                                suffered to the editor page when looking at its layout alteration in some injected.
                            </p>
                        </div>
                        <div class="testimonial-rate">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <div class="testimonial-quote-icon"><img src="assets/img/icon/quote.svg" alt=""></div>
                    </div>
                </div>
            </div>
        </div>
        <!-- testimonial area end -->


        <!-- blog area -->
        <div class="blog-area py-100">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 mx-auto">
                        <div class="site-heading text-center">
                            <span class="site-title-tagline">Our Blog</span>
                            <h2 class="site-title">Our Latest News & <span>Blog</span></h2>
                        </div>
                    </div>
                </div>
                <div class="row g-4">
                    <div class="col-md-6 col-lg-4">
                        <div class="blog-item wow fadeInUp" data-wow-delay=".25s">
                            <div class="blog-item-img">
                                <img src="assets/img/blog/01.jpg" alt="Thumb">
                                <span class="blog-date"><i class="far fa-calendar-alt"></i> Aug 12, 2024</span>
                            </div>
                            <div class="blog-item-info">
                                <div class="blog-item-meta">
                                    <ul>
                                        <li><a href="#"><i class="far fa-user-circle"></i> By Alicia Davis</a></li>
                                        <li><a href="#"><i class="far fa-comments"></i> 2.5k Comments</a></li>
                                    </ul>
                                </div>
                                <h4 class="blog-title">
                                    <a href="#">There are many variations of passage available majority suffered.</a>
                                </h4>
                                <p>There are many variations available the majority have suffered alteration randomised
                                    words.</p>
                                <a class="theme-btn" href="#">Read More<i class="fas fa-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4">
                        <div class="blog-item wow fadeInDown" data-wow-delay=".25s">
                            <div class="blog-item-img">
                                <img src="assets/img/blog/02.jpg" alt="Thumb">
                                <span class="blog-date"><i class="far fa-calendar-alt"></i> Aug 15, 2024</span>
                            </div>
                            <div class="blog-item-info">
                                <div class="blog-item-meta">
                                    <ul>
                                        <li><a href="#"><i class="far fa-user-circle"></i> By Alicia Davis</a></li>
                                        <li><a href="#"><i class="far fa-comments"></i> 3.1k Comments</a></li>
                                    </ul>
                                </div>
                                <h4 class="blog-title">
                                    <a href="#">Contrary to popular belief making simply random text latin.</a>
                                </h4>
                                <p>There are many variations available the majority have suffered alteration randomised
                                    words.</p>
                                <a class="theme-btn" href="#">Read More<i class="fas fa-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4">
                        <div class="blog-item wow fadeInUp" data-wow-delay=".25s">
                            <div class="blog-item-img">
                                <img src="assets/img/blog/03.jpg" alt="Thumb">
                                <span class="blog-date"><i class="far fa-calendar-alt"></i> Aug 18, 2024</span>
                            </div>
                            <div class="blog-item-info">
                                <div class="blog-item-meta">
                                    <ul>
                                        <li><a href="#"><i class="far fa-user-circle"></i> By Alicia Davis</a></li>
                                        <li><a href="#"><i class="far fa-comments"></i> 1.6k Comments</a></li>
                                    </ul>
                                </div>
                                <h4 class="blog-title">
                                    <a href="#"> If you are going use passage you need sure there middle
                                        text.</a>
                                </h4>
                                <p>There are many variations available the majority have suffered alteration randomised
                                    words.</p>
                                <a class="theme-btn" href="#">Read More<i class="fas fa-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- blog area end -->

    </main>


    <?php require __DIR__ . '/overall/footer.php'; ?>


    


    <!-- modal quick shop-->
    <div class="modal quickview fade" id="quickview" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="quickview" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i
                        class="far fa-xmark"></i></button>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                            <div class="quickview-img">
                                <img src="assets/img/product/04.png" alt="#">
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                            <div class="quickview-content">
                                <h4 class="quickview-title">Surgical Face Mask</h4>
                                <div class="quickview-rating">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star-half-alt"></i>
                                    <i class="far fa-star"></i>
                                    <span class="rating-count"> (4 Customer Reviews)</span>
                                </div>
                                <div class="quickview-price">
                                    <h5><del>$860</del><span>$740</span></h5>
                                </div>
                                <ul class="quickview-list">
                                    <li>Brand:<span>Medica</span></li>
                                    <li>Category:<span>Healthcare</span></li>
                                    <li>Stock:<span class="stock">Available</span></li>
                                    <li>Code:<span>789FGDF</span></li>
                                </ul>
                                <div class="quickview-cart">
                                    <a href="#" class="theme-btn">Add to cart</a>
                                </div>
                                <div class="quickview-social">
                                    <span>Share:</span>
                                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                                    <a href="#"><i class="fab fa-x-twitter"></i></a>
                                    <a href="#"><i class="fab fa-pinterest-p"></i></a>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                    <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- modal quick shop end -->


    <!-- modal popup banner  -->
	<div class="modal popup-banner fade" id="popup-banner" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <button type="button" class="btn-close" data-bs-dismiss="modal"><i class="far fa-xmark"></i></button>
                <div class="modal-body">
                    <div class="popup-banner-content">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="popup-banner-img">
                                    <img src="assets/img/banner/popup-banner.jpg" alt="">
                                </div>
                            </div>
                            <div class="col-lg-6 align-self-center">
                                <div class="popup-banner-info">
                                    <h6>7 Days Super Sale !</h6>
                                    <h2>Hurry Up! Get Up To <span>50%</span> Discount</h2>
                                    <p>There are many variations the majority have suffered alteration in some form injected words look even slightly believable.</p>
                                    <a href="#" class="theme-btn">Start Shop Now</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- modal popup banner end -->
<?php require __DIR__ . '/overall/scripts.php'; ?>
