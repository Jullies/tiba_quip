<?php
require_once __DIR__ . '/overall/bootstrap.php';
$bodyClass = '';
$pageScripts = [];
require __DIR__ . '/overall/head.php';
require __DIR__ . '/overall/header.php';
?>
<main class="main">

        <!-- breadcrumb -->
        <div class="site-breadcrumb">
            <div class="site-breadcrumb-bg" style="background: url(assets/img/breadcrumb/01.jpg)"></div>
            <div class="container">
                <div class="site-breadcrumb-wrap">
                    <h4 class="breadcrumb-title">Settings</h4>
                    <ul class="breadcrumb-menu">
                        <li><a href="index.php"><i class="far fa-home"></i> Home</a></li>
                        <li class="active">Settings</li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- breadcrumb end -->


        <!-- user dashboard -->
        <div class="user-area bg pt-100 pb-80">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3">
                        <?php require __DIR__ . '/overall/sidenav.php'; ?>
                    </div>
                    <div class="col-lg-9">
                        <div class="user-wrapper">
                            <div class="user-card user-setting">
                                <h4 class="user-card-title">Settings</h4>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <h6 class="mb-3">Privacy Setting</h6>
                                        <div class="privacy-setting">
                                            <form action="#">
                                                <div class="form-check form-switch">
                                                    <input class="form-check-input" name="privacy-setting" value="1" type="checkbox" role="switch" id="privacy-setting-1" checked>
                                                    <label class="form-check-label" for="privacy-setting-1">Enable Messages</label>
                                                </div>
                                                <div class="form-check form-switch">
                                                    <input class="form-check-input" name="privacy-setting" value="2" type="checkbox" role="switch" id="privacy-setting-2">
                                                    <label class="form-check-label" for="privacy-setting-2">I Want To Receive Email Notify</label>
                                                </div>
                                                <div class="form-check form-switch">
                                                    <input class="form-check-input" name="privacy-setting" value="3" type="checkbox" role="switch" id="privacy-setting-3" checked>
                                                    <label class="form-check-label" for="privacy-setting-3">Hide My Phone Number From Public</label>
                                                </div>
                                                <div class="form-check form-switch">
                                                    <input class="form-check-input" name="privacy-setting" value="4" type="checkbox" role="switch" id="privacy-setting-4">
                                                    <label class="form-check-label" for="privacy-setting-4">I Want To Receive Message</label>
                                                </div>
                                                <div class="form-check form-switch">
                                                    <input class="form-check-input" name="privacy-setting" value="5" type="checkbox" role="switch" id="privacy-setting-5" checked>
                                                    <label class="form-check-label" for="privacy-setting-5">Make My Profile Private</label>
                                                </div>
                                                <div class="my-4">
                                                    <button type="submit" class="theme-btn"><span class="far fa-gear"></span>Update Settings</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <h6 class="mb-3">Delete Account</h6>
                                        <div class="user-form">
                                            <form action="#">
                                                <div class="form-group">
                                                    <select class="select mb-4">
                                                        <option value="">Choose Reason</option>
                                                        <option value="1">Reason One</option>
                                                        <option value="2">Reason Two</option>
                                                        <option value="3">Reason Three</option>
                                                    </select>
                                                </div>
                                                <div class="form-group">
                                                    <textarea class="form-control" cols="30" rows="4" placeholder="Describe Your Reason"></textarea>
                                                </div>
                                                <button type="submit" class="theme-btn"><span class="far fa-trash-can"></span>Delete Account</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- user dashboard end -->

    </main>


    <?php require __DIR__ . '/overall/footer.php'; ?>
<?php require __DIR__ . '/overall/scripts.php'; ?>
