<?php
require_once __DIR__ . '/overall/bootstrap.php';
$bodyClass = '';
$pageScripts = [];
require __DIR__ . '/overall/head.php';
require __DIR__ . '/overall/header.php';
?>
<main class="main">

        <!-- breadcrumb -->
        <div class="site-breadcrumb">
            <div class="site-breadcrumb-bg" style="background: url(assets/img/breadcrumb/01.jpg)"></div>
            <div class="container">
                <div class="site-breadcrumb-wrap">
                    <h4 class="breadcrumb-title">Forgot Password</h4>
                    <ul class="breadcrumb-menu">
                        <li><a href="index.php"><i class="far fa-home"></i> Home</a></li>
                        <li class="active">Forgot Password</li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- breadcrumb end -->


        <!-- forgot password -->
        <div class="login-area py-100">
            <div class="container">
                <div class="col-md-5 mx-auto">
                    <div class="login-form">
                        <div class="login-header">
                            <img src="assets/img/logo/logo.png" alt="">
                            <p>Reset your medica account password</p>
                        </div>
                        <form action="#">
                            <div class="form-group">
                                <label>Email Address</label>
                                <input type="email" class="form-control" placeholder="Your Email">
                            </div>
                            <div class="d-flex align-items-center">
                                <button type="submit" class="theme-btn"><i class="far fa-key"></i> Send Reset
                                    Link</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- forgot password end -->

    </main>


    <?php require __DIR__ . '/overall/footer.php'; ?>
<?php require __DIR__ . '/overall/scripts.php'; ?>
